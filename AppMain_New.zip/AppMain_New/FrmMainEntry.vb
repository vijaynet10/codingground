﻿Public Class FrmMainEntry
    Private Logic As New DataLogic


    Sub New()
        InitializeComponent()
        Init_Me()
    End Sub
    Function Init_Me() As Int32

        Try

            clearAll()

            With Me
                .KeyPreview = True
                .DoubleBuffered = True
            End With

            With Cbo_RelationShip
                .DataSource = Application_Main.RelationShip.Data
                .DisplayMember = Master.RelationShip.Columns.Name
                .ValueMember = Master.RelationShip.Columns.Name
            End With
            With DGV_FamilymembersData
                .DataSource = Me.Logic.Relation.Data
                .Columns(DataModel.Relation.Columns.Sno).Visible = False
                .Columns(DataModel.Relation.Columns.Name).DisplayIndex = 0
                .Columns(DataModel.Relation.Columns.Age).DisplayIndex = 1
                .Columns(DataModel.Relation.Columns.DateOfBirth).DisplayIndex = 2
                .Columns(DataModel.Relation.Columns.Relationship).DisplayIndex = 3
                .Columns(DataModel.Relation.Columns.AadharNumber).DisplayIndex = 4

                .Columns(DataModel.Relation.Columns.Name).HeaderText = "குடும்பத்தினர்"
                .Columns(DataModel.Relation.Columns.Age).HeaderText = " வயது"
                .Columns(DataModel.Relation.Columns.DateOfBirth).HeaderText = " பிறந்த தேதி"
                .Columns(DataModel.Relation.Columns.Relationship).HeaderText = "உறவு"
                .Columns(DataModel.Relation.Columns.AadharNumber).HeaderText = "ஆதார் எண்"
                .Columns(DataModel.Relation.Columns.DateOfBirth).DefaultCellStyle.Format = "dd-MMM-yyyy"

                .Columns(DataModel.Relation.Columns.Name).AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells
                .Columns(DataModel.Relation.Columns.AadharNumber).AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells



            End With

            Init_Me = 0


        Catch ex As Exception
            Throw
        End Try
    End Function

    Function ClearrelationEntry() As Int32
        Try
            Txt_FamilyName.Clear()
            txt_FamilyAge.Clear()
            Txt_AhaarNo.Clear()
            ClearrelationEntry = 0
        Catch ex As Exception
            Throw
        End Try
    End Function
    Private Sub AddFamilyMemberData(sender As Object, e As EventArgs) Handles Btn_AddFamilyMember.Click
        Dim iRc As Int32 = 0, ErrMsg As String = String.Empty
        Try
            With Me.Logic.Relation
                .Name = Me.Txt_FamilyName.Text.Trim
                .Age = Val(Me.txt_FamilyAge.Text.Trim)
                .Relationship = Me.Cbo_RelationShip.Text
                .AdhaarID = Me.Txt_AhaarNo.Text.Trim
                .DOB = Me.Dtp_FamilyDOB.Value
                iRc = .Add(ErrMsg)
                If iRc <> 0 Then Throw New Exception(ErrMsg)
            End With
            ClearrelationEntry()
            Txt_FamilyName.Focus()
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub

    Private Sub FrmMainEntry_KeyDown(sender As Object, e As KeyEventArgs) Handles Me.KeyDown
        Try
            If e.KeyCode = Keys.Enter Then
                ProcessTabKey(True)
            ElseIf e.KeyCode = Keys.N AndAlso e.Control = True Then
                clearAll()
            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub

    Private Sub txt_FamilyAg_KeyDown(sender As Object, e As KeyEventArgs) Handles txt_FamilyAge.KeyDown

    End Sub

    Private Sub txt_FamilyAge_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txt_FamilyAge.KeyPress
        Try
            If IsNumeric((e.KeyChar)) = True OrElse AscW(e.KeyChar) = Keys.Back OrElse AscW(e.KeyChar) = Keys.Delete OrElse AscW(e.KeyChar) = Keys.Left OrElse AscW(e.KeyChar) = Keys.Right Then
                e.Handled = False
            Else
                e.Handled = True
            End If

        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub

    Private Sub Btn_AddFamilyMember_Click(sender As Object, e As EventArgs) Handles Btn_AddFamilyMember.Click
        Try



        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub

    Private Sub Btn_FamilyImage_Click(sender As Object, e As EventArgs) Handles Btn_FamilyImage.Click
        Try
            Dim MyImageFullName As String = String.Empty
            GetImage(MyImageFullName)
            If IO.File.Exists(MyImageFullName) Then
                Pic_FamilyImage.Image = Image.FromFile(MyImageFullName)
                Pic_FamilyImage.Tag = MyImageFullName
            Else
                Pic_FamilyImage.Image = Nothing
                Pic_FamilyImage.Tag = ""
            End If


        Catch ex As Exception
            MessageBox.Show(ex.Message)
        Finally
            Txt_ResAreaName.Focus()
        End Try
    End Sub
    Function GetImage(ByRef ImageFullName As String) As Int32
        Try

            Dim OpenFileDialg As New OpenFileDialog

            With OpenFileDialg
                .Filter = "Image Files|*.jpg;*.jpeg;*.png"
            End With
            Dim diaresult As DialogResult = OpenFileDialg.ShowDialog()
            If diaresult = Windows.Forms.DialogResult.OK Then
                ImageFullName = OpenFileDialg.FileName
            Else
                ImageFullName = String.Empty
            End If
            GetImage = 0
        Catch ex As Exception
            Throw
        End Try
    End Function
    Private Sub Btn_Submit_Click(sender As Object, e As EventArgs) Handles Btn_Submit.Click
        Try
            If IO.File.Exists(IO.Path.Combine(Application.StartupPath, "Report_PrintPDF.rdlc")) = False Then Throw New Exception("Report File not   found")
            With Logic
                .ReservationDate = Me.DTP_ResDate.Value
                .ReservationNo = Me.Txt_ResNo.Text
            End With
            With Logic.FamilyLeader
                .FatherOrHusbandName = Txt_HusbandFatherName.Text
                .ReservationArea = Txt_ResAreaName.Text
                .ReservationAreaNumber = Txt_ResAreaNo.Text
                .ReservationPerson = Txt_ResPerName.Text
            End With

            With Logic.FamilyLeader.NewFoodCard
                .ID = Trim(Txt_NewFoodNo.Text)
                .IssuedDate = Dtp_NewFoodDate.Value
            End With

            With Logic.FamilyLeader.OldFoodCard
                .ID = Trim(Txt_OldFoodNo.Text)
                .IssuedDate = Dtp_OldFoodDate.Value
            End With

            With Logic.FamilyLeader.NewVoterData
                .Constituency = Trim(Txt_NewVoterCont.Text)
                .VoterIDIssuedDate = Dtp_NewVoterIDDate.Value
                .VoterIdNo = Txt_NewVoterIdNo.Text
            End With


            With Logic.FamilyLeader.OldVoterData
                .Constituency = Trim(Txt_OldVoterCont.Text)
                .VoterIDIssuedDate = Dtp_OldVoterIDDate.Value
                .VoterIdNo = Txt_OldVoterIdNo.Text
            End With

            With Logic.Address
                .Address1 = Txt_OutAddress.Text
                .DoorNo = Txt_OutDoorNo.Text
                .Area = Txt_OutArea.Text
                .Street = Txt_OutStreet.Text
                .District = Txt_OutDistrict.Text
            End With

            Logic.Relation.AddNullData()


            ToReport()
            TabControl_Main.SelectedIndex = 1







        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub
    Private Function ToReport() As Int32
        Try


            Dim NewFoodCardID As New Microsoft.Reporting.WinForms.ReportParameter("NewFoodCardID", Logic.FamilyLeader.NewFoodCard.ID)
            Dim OldFoodCardID As New Microsoft.Reporting.WinForms.ReportParameter("OldFoodCardID", Logic.FamilyLeader.OldFoodCard.ID)



            Dim OldFoodCardDate As New Microsoft.Reporting.WinForms.ReportParameter("OldFoodCardDate", Logic.FamilyLeader.OldFoodCard.IssuedDate.ToString("dd-MMM-yyyy"))
            Dim NewFoodCardDate As New Microsoft.Reporting.WinForms.ReportParameter("NewFoodCardDate", Logic.FamilyLeader.NewFoodCard.IssuedDate.ToString("dd-MMM-yyyy"))



            Dim NewVoterIDNO As New Microsoft.Reporting.WinForms.ReportParameter("NewVoterIDNO", Logic.FamilyLeader.NewVoterData.VoterIdNo)
            Dim OldVoterIDNO As New Microsoft.Reporting.WinForms.ReportParameter("OldVoterIDNO", Logic.FamilyLeader.OldVoterData.VoterIdNo)

            Dim NewVoterIDDate As New Microsoft.Reporting.WinForms.ReportParameter("NewVoterIDDate", Logic.FamilyLeader.NewVoterData.VoterIDIssuedDate.ToString("dd-MMM-yyyy"))
            Dim OldVoterIDDate As New Microsoft.Reporting.WinForms.ReportParameter("OldVoterIDDate", Logic.FamilyLeader.OldVoterData.VoterIDIssuedDate.ToString("dd-MMM-yyyy"))

            Dim NewVoterIDCons As New Microsoft.Reporting.WinForms.ReportParameter("NewVoterIDCons", Logic.FamilyLeader.NewVoterData.Constituency)
            Dim OldVoterIDCons As New Microsoft.Reporting.WinForms.ReportParameter("OldVoterIDCons", Logic.FamilyLeader.OldVoterData.Constituency)

        
            
            Dim ResDate As New Microsoft.Reporting.WinForms.ReportParameter("ResDate", Logic.ReservationDate.ToString("dd-MMM-yyyy"))
            Dim ResNo As New Microsoft.Reporting.WinForms.ReportParameter("ResNo", Logic.ReservationNo)


            Dim OutAddress As New Microsoft.Reporting.WinForms.ReportParameter("OutAddress", Logic.Address.Address1)
            Dim OutDoorNo As New Microsoft.Reporting.WinForms.ReportParameter("OutDoorNo", Logic.Address.DoorNo)
            Dim OutArea As New Microsoft.Reporting.WinForms.ReportParameter("OutArea", Logic.Address.Area)
            Dim OutStreet As New Microsoft.Reporting.WinForms.ReportParameter("OutStreet", Logic.Address.Street)
            Dim OutDistrict As New Microsoft.Reporting.WinForms.ReportParameter("OutDistrict", Logic.Address.District)


            Dim ResArea As New Microsoft.Reporting.WinForms.ReportParameter("ResArea", Logic.FamilyLeader.ReservationArea)
            Dim ResAreaNo As New Microsoft.Reporting.WinForms.ReportParameter("ResAreaNo", Logic.FamilyLeader.ReservationAreaNumber)
            Dim ResPerson As New Microsoft.Reporting.WinForms.ReportParameter("ResPerson", Logic.FamilyLeader.ReservationPerson)
            Dim HusbandOrFatherName As New Microsoft.Reporting.WinForms.ReportParameter("HusbandOrFatherName", Logic.FamilyLeader.FatherOrHusbandName)






            Dim FamilyImage As New Microsoft.Reporting.WinForms.ReportParameter("FamilyImage")
            If Convert.ToString(Pic_FamilyImage.Tag) <> "" Then
                Dim uriAddress As New Uri(Convert.ToString(Pic_FamilyImage.Tag))
                FamilyImage.Values.Add(uriAddress.ToString)
            Else
                FamilyImage.Values.Add("")

            End If









            Dim ReportDataSource As New Microsoft.Reporting.WinForms.ReportDataSource("DS_Data", Logic.Relation.Data.CopyToDataTable)


            With ReportView.LocalReport
                .EnableExternalImages = True


                .ReportEmbeddedResource = "Report_PrintPDF.rdlc"
                .ReportPath = IO.Path.Combine(Application.StartupPath, "Report_PrintPDF.rdlc")


                .DataSources.Clear()
                .DataSources.Add(ReportDataSource)

                .SetParameters(NewVoterIDNO)
                .SetParameters(OldVoterIDNO)

                .SetParameters(NewVoterIDDate)
                .SetParameters(OldVoterIDDate)

                .SetParameters(NewVoterIDCons)
                .SetParameters(OldVoterIDCons)


                .SetParameters(OldFoodCardID)
                .SetParameters(NewFoodCardID)

                .SetParameters(OldFoodCardDate)
                .SetParameters(NewFoodCardDate)


                .SetParameters(FamilyImage)
                .SetParameters(ResDate)
                .SetParameters(ResNo)
                .SetParameters(OutAddress)
                .SetParameters(OutDoorNo)
                .SetParameters(OutArea)
                .SetParameters(OutStreet)
                .SetParameters(OutDistrict)

                .SetParameters(ResArea)
                .SetParameters(ResAreaNo)
                .SetParameters(ResPerson)
                .SetParameters(HusbandOrFatherName)



            End With


            ReportView.RefreshReport()
            ToReport = 0
        Catch ex As Exception
            Throw
        End Try
    End Function

    Private Sub TabControl_Main_SelectedIndexChanged(sender As Object, e As EventArgs) Handles TabControl_Main.SelectedIndexChanged
        Try
            If TabControl_Main.SelectedIndex = 0 Then
                Logic.Relation.RemoveNullData()
            End If


        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub

    Private Sub DGV_FamilymembersData_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DGV_FamilymembersData.CellContentClick

    End Sub

    Private Sub DGV_FamilymembersData_KeyDown(sender As Object, e As KeyEventArgs) Handles DGV_FamilymembersData.KeyDown
        Try

            If e.KeyCode = Keys.Delete Then
                If DGV_FamilymembersData.CurrentRow Is Nothing Then Return
                Dim Sno As String = DGV_FamilymembersData.CurrentRow.Cells(DataModel.Relation.Columns.Sno).Value
                Logic.Relation.RemoveSelectedRow(Sno)



            End If


        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub
    Function clearAll()
        Try


            Logic.Relation.Data.Rows.Clear()
            ClearrelationEntry()

            Txt_NewFoodNo.Clear()
            Txt_OldFoodNo.Clear()

            Txt_NewVoterIdNo.Clear()
            Txt_OldVoterIdNo.Clear()
            Txt_NewVoterCont.Clear()
            Txt_OldVoterCont.Clear()
            Pic_FamilyImage.Image = Nothing
            Txt_ResAreaName.Clear()
            Txt_ResAreaNo.Clear()
            Txt_ResPerName.Clear()
            Txt_HusbandFatherName.Clear()
            Txt_OutAddress.Clear()
            Txt_OutArea.Clear()
            Txt_OutDoorNo.Clear()
            Txt_OutStreet.Clear()
            Txt_OutDistrict.Clear()
            TabControl_Main.SelectedIndex = 0
            Txt_FamilyName.Focus()

            clearAll = 0
        Catch ex As Exception
            Throw
        End Try
    End Function

    Private Sub FrmMainEntry_Shown(sender As Object, e As EventArgs) Handles Me.Shown
        Try
            Txt_FamilyName.Focus()
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try

    End Sub
End Class
