﻿Partial Class Data
    Partial Class MiscDataTable

        Private Sub MiscDataTable_MiscRowChanging(sender As Object, e As MiscRowChangeEvent) Handles Me.MiscRowChanging
        End Sub

    End Class

    Partial Class FamilyHeadDataTable
    End Class
End Class
