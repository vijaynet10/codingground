﻿Namespace DataModel
    Public Class Relation
        Private _Data As New Data.RelationsDataTable
        Friend ReadOnly Property Data As Data.RelationsDataTable
            Get
                Return _Data
            End Get
        End Property

        Private _Name As String
        Friend Property Name As String
            Get
                Return _Name
            End Get
            Set(value As String)
                _Name = value
            End Set
        End Property
        Private _Age As Integer
        Friend Property Age As Integer
            Get
                Return _Age
            End Get
            Set(value As Integer)
                _Age = value
            End Set
        End Property

        Private _DOB As Date
        Friend Property DOB As Date
            Get
                Return _DOB
            End Get
            Set(value As Date)
                _DOB = value
            End Set
        End Property

        Private _AdhaarID As String
        Friend Property AdhaarID As String
            Get
                Return _AdhaarID
            End Get
            Set(value As String)
                _AdhaarID = value
            End Set
        End Property
        Private _Relationship As String
        Friend Property Relationship As String
            Get
                Return _Relationship
            End Get
            Set(value As String)
                _Relationship = value
            End Set
        End Property
        Friend Function AddNullData() As Int32
            Try
                For IntI As Integer = Data.Rows.Count - 1 To 7
                    Data.Rows.Add()
                Next

                AddNullData = 0
            Catch ex As Exception
                Throw
            End Try
        End Function
        Friend Function RemoveNullData() As Int32
            Try
                For IntI As Integer = Data.Rows.Count - 1 To 0 Step -1

                    If Convert.ToString(Data.Rows(IntI)(Columns.Name)) = String.Empty Then
                        Data.Rows.RemoveAt(IntI)
                    End If
                Next
                RemoveNullData = 0
            Catch ex As Exception
                Throw
            End Try
        End Function

        Friend Function RemoveSelectedRow(Sno As String) As Int32
            Try
                Dim Strsql As String = "" & Columns.Sno & "=" & Sno & ""
                Dim rows() As DataRow = Data.Select(Strsql)
                If rows.Length <= 0 Then Return 0
                Data.Rows.Remove(rows(0))
                RemoveSelectedRow = 0
            Catch ex As Exception
                Throw
            End Try
        End Function



        Function Add(ByRef ErrMsg As String) As Int32
            Dim iRc As Integer = 0
            Try

                If Me.Name = String.Empty Then Throw New Exception("சரியான பெயர் கொடுக்கவும்...")
                If Me.Age <= 0 Then Throw New Exception("சரியான வயது கொடுக்கவும்....")
                Dim NewRow As DataRow = Data.NewRelationsRow
                NewRow(Data.NameColumn.ColumnName) = Me.Name
                NewRow(Data.RelationshipColumn.ColumnName) = Me.Relationship
                NewRow(Data.DateOfBirthColumn.ColumnName) = Me.DOB
                NewRow(Data.AadharNumberColumn.ColumnName) = Me.AdhaarID
                NewRow(Data.AgeColumn.ColumnName) = Me.Age
                Data.Rows.Add(NewRow)
                iRc = 0
                Clear()
            Catch ex As Exception
                iRc = 1
                ErrMsg = ex.Message
            Finally
                Add = iRc
            End Try
        End Function

        Public Structure Columns
            Public Shared ReadOnly Sno As String = "Sno"
            Public Shared ReadOnly Name As String = "Name"
            Public Shared ReadOnly Age As String = "Age"
            Public Shared ReadOnly DateOfBirth As String = "DateOfBirth"
            Public Shared ReadOnly AadharNumber As String = "AadharNumber"
            Public Shared ReadOnly Relationship As String = "Relationship"
        End Structure

        Friend Function Clear() As Int32
            Dim iRc As Int32 = 0
            Try

                With Me
                    .Name = String.Empty
                    .Age = 0
                    .AdhaarID = ""
                    .Relationship = ""
                End With

                Clear = 0
            Catch ex As Exception
                Throw
            End Try

        End Function
    End Class
End Namespace