﻿Namespace Master
    Public Class RelationShip
        Dim _Data As New DataTable
        Friend Property Data As DataTable
            Get
                Return _Data
            End Get
            Private Set(value As DataTable)
                _Data = value
            End Set
        End Property
        Structure Columns
            Public Shared ReadOnly Name As String = "Name"
            Public Shared ReadOnly Value As String = "Value"
        End Structure
        Function Init_Data() As Int32
            Try
                Data = New DataTable
                Data.Columns.Add(Columns.Name, GetType(String))
                Data.Columns.Add(Columns.Value, GetType(String))
                Data.Rows.Add({"மகன்", "மகன்"})
                Data.Rows.Add({"மகள்", "மகள்"})
                Data.Rows.Add({"கணவன்", "கணவன்"})
                Data.Rows.Add({"மனைவி", "மனைவி"})
                Data.Rows.Add({"தாய்", "தாய்"})
                Data.Rows.Add({"தந்தை", "தந்தை"})
                Init_Data = 0
            Catch ex As Exception
                Throw
            End Try
        End Function


        Public Sub New()
            Try
                Init_Data()
            Catch ex As Exception
                Throw
            End Try

        End Sub
    End Class
End Namespace