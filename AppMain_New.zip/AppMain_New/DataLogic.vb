﻿Public Class DataLogic


    Private _ReservationDate As Date
    Friend Property ReservationDate As Date
        Get
            Return _ReservationDate
        End Get
        Set(value As Date)
            _ReservationDate = value
        End Set
    End Property

    Private _ReservationNo As String
    Friend Property ReservationNo As String
        Get
            Return _ReservationNo
        End Get
        Set(value As String)
            _ReservationNo = value
        End Set
    End Property

    Private _Relation As New DataModel.Relation
    Friend Property Relation As DataModel.Relation
        Get
            Return _Relation
        End Get
        Private Set(value As DataModel.Relation)
            _Relation = value
        End Set
    End Property

    Private _FamilyLeader As New DataModel.FamilyLeader
    Friend Property FamilyLeader As DataModel.FamilyLeader
        Get
            Return _FamilyLeader
        End Get
        Private Set(value As DataModel.FamilyLeader)
            _FamilyLeader = value
        End Set
    End Property
    Private _Address As New DataModel.Address
    Friend Property Address As DataModel.Address
        Get
            Return _Address
        End Get
        Private Set(value As DataModel.Address)
            _Address = value
        End Set
    End Property



    Friend Function SubmitData(ByRef ErrMsg As String) As Int32
        Dim iRc As Integer = 0
        Try

            iRc = 0
        Catch ex As Exception
            iRc = 1
            ErrMsg = ex.Message
        Finally
            SubmitData = iRc
        End Try
    End Function

End Class
