﻿Public Class Application_Main
    Friend Shared RelationShip As New Master.RelationShip
    Friend Shared LoginForm_Admin As New LoginForm_Admin
    Friend Shared LoginForm_Emp As New LoginForm_Emp
    Friend Shared ApplicationSett As New ApplicationSett
    Friend Shared FrmApplicationSettings As New FrmApplicationSettings(ApplicationSett)
    Friend Shared FrmMainEntry As New FrmMainEntry

    Friend Shared Function Startup() As Int32
        Try
            ApplicationSett.ChangeData(DataEntry.ApplicationSett.ExpireType.Two_Days)
            Startup = 0
        Catch ex As Exception
            Throw
        End Try
    End Function


End Class

