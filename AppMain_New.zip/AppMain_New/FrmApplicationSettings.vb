﻿Public Class FrmApplicationSettings
    Private ApplicationSett As ApplicationSett
    Sub New(_ApplicationSett As ApplicationSett)
        InitializeComponent()
        CboValidUpto.DataSource = [Enum].GetValues(GetType(ApplicationSett.ExpireType))
        ApplicationSett = _ApplicationSett

        With Me
            .ShowInTaskbar = False
            .ShowIcon = False
            .WindowState = FormWindowState.Normal
            .ControlBox = False
            .StartPosition = FormStartPosition.CenterScreen
        End With
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Try

            ApplicationSett.ChangeData(CboValidUpto.SelectedValue)

        Catch ex As Exception
            MessageBox.Show(ex.Message)
        Finally
            Me.Close()
        End Try
    End Sub

    Private Sub FrmApplicationSettings_Shown(sender As Object, e As EventArgs) Handles Me.Shown
        Try
            CboValidUpto.SelectedValue = ApplicationSett.MyExpireType

        Catch ex As Exception

        End Try


    End Sub
End Class