﻿Public Class LoginForm_Admin

    Private Sub OK_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OK.Click
        Try

            If UsernameTextBox.Text.ToUpper = "Admin".ToUpper AndAlso PasswordTextBox.Text.ToUpper = "Cinavia".ToUpper Then
                Me.DialogResult = Windows.Forms.DialogResult.OK
                Me.Close()
            Else
                Throw New Exception("User name  or  password is invalid ")
            End If

        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try

    End Sub

    Private Sub Cancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cancel.Click
        Try
            Me.DialogResult = Windows.Forms.DialogResult.Cancel
            Me.Close()
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub

    Public Sub New()

        ' This call is required by the designer.
        InitializeComponent()

        With Me
            .ShowInTaskbar = False
            .ShowIcon = False
            .WindowState = FormWindowState.Normal
            .ControlBox = False
            .StartPosition = FormStartPosition.CenterScreen
        End With

    End Sub

    Private Sub LoginForm_Admin_Shown(sender As Object, e As EventArgs) Handles Me.Shown
        Try
            UsernameTextBox.Clear()
            PasswordTextBox.Clear()
            UsernameTextBox.Focus()
        Catch ex As Exception

        End Try
        
    End Sub
End Class
