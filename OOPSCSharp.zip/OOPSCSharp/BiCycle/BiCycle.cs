﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace OOPSCSharp.BiCycle
{
    class BiCycle
    {
        #region "Cunstructor"
        BiCycle(){}
        #endregion
        #region "Varialbles And properties"
        private int Cadence;
        private int Speed;
        private int Gear;
        #endregion
        #region "Change State of the cycle"
        internal void ChangeGear(int newvaue)
        {
            try
            {
                Gear = newvaue;   
            }
            catch (Exception ex){throw new Exception(ex.Message);}
        }
       internal void IncreaseSpeed(int IncrementValue )
        {
            try
            {
                this.Speed +=IncrementValue;

            }
            catch (Exception Ex) { throw new Exception(Ex.Message); }
        }
       internal void ApplyBreak(int DecreaseSpeed)
        {
            try
            {
                this.Speed -= DecreaseSpeed;

            }
            catch(Exception ex){throw new  Exception (ex.Message);}
        }
       internal void ChangeCadence(int NewValue)
        {
            try
            {
                this.Cadence= NewValue;
            }
            catch (Exception ex) { throw new Exception(ex.Message); }
            }

        #endregion

        #region "Status of the Cycle"
       internal string MyStatus()
        {
            try
            {
                string mystate=string.Empty;
                mystate ="Speed : "+ this.Speed +",  Cadence :"+ this.Cadence +" , Gear : "+ this.Gear +"";
                return mystate;
            }
            catch (Exception ex) { throw new Exception(ex.Message);}
            
        }
        #endregion






    }
}
