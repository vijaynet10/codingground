﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Data; /// Namespace of sql client used 
 

                    /// 
public  enum ConnStateAfterExecute
{
    Open,Close

}

namespace OOPSCSharp.Common
{
 public   class SqlAction
    {

        /// <summary>
        /// Data encapsulation with the help of private accersss modifier
        /// </summary>
        /// 
        private ReturnStatus ReturnState;
        private SqlConnectionStringBuilder StringBuilder;
        private SqlConnection Connection;
        private SqlCommand Command;
        private SqlDataAdapter Adapter;
       
        #region "Cunstructor"
        /// <summary>
        /// public  cunstructor
        /// </summary>
        /// <param name="_StringBuilder">have to give connection parameter </param>
        public SqlAction(SqlConnectionStringBuilder _StringBuilder)
        {
            StringBuilder = _StringBuilder;
            ReturnState = SetConnection();
            if (ReturnState.Status == enumReturnStatus.Failed) { throw new Exception(ReturnState.Description); }
        }
        #endregion
        
        #region "Connection Behavior function's"

        ///  function hidden from public access
        private ReturnStatus SetConnection()
        {
            try
            {
                Connection = new SqlConnection(StringBuilder.ToString());
                Connection.Open();
                Connection.Close();
                return new ReturnStatus(enumReturnStatus.Succedded);
            }
            catch (Exception ex) { return new ReturnStatus(ex); }
        }
        private ReturnStatus CloseConnection()
        {
            try
            {
                if (Connection.State == ConnectionState.Closed) { return new ReturnStatus(enumReturnStatus.Succedded); } 
                Connection.Close();
                return new ReturnStatus(enumReturnStatus.Succedded);
            }
            catch (Exception ex) { return new ReturnStatus(ex); }
        }

        private ReturnStatus OpenConnection()
        {
            try
            {
                if (Connection.State == ConnectionState.Open) { return new ReturnStatus(enumReturnStatus.Succedded); }
                Connection.Open();
                return new ReturnStatus(enumReturnStatus.Succedded);
            }
            catch (Exception ex) { return new ReturnStatus(ex); }
        }
                #endregion
        #region "Sql Action Functions"
        public ReturnStatus ExecuteDataTable(string Query, CommandType CommandType, List<SqlParameter> Parameter, ConnStateAfterExecute ConnectionState)
        {
            try
            {
                if (Query == string.Empty) { throw new ArgumentNullException("Query "); }
                if (CommandType == null) { throw new ArgumentNullException("CommandType"); }
                if (ConnectionState == null) { throw new ArgumentNullException("ConnectionState"); }

                DataTable Data=new DataTable();
                Command= new SqlCommand(Query,Connection);
                Command.CommandType = CommandType;
                if (Parameter != null){Command.Parameters.AddRange(Parameter.ToArray());}
                Adapter = new SqlDataAdapter(Command);
                Adapter.Fill(Data);
                return new ReturnStatus(enumReturnStatus.Succedded, Data);
            }
            catch (Exception ex) { return new ReturnStatus(ex); }
            finally
            {
                if  (ConnectionState==ConnStateAfterExecute.Close)
                {   
                 ReturnState=  CloseConnection();
                if (ReturnState.Status == enumReturnStatus.Failed) { throw new Exception(ReturnState.Description); }
               }

                if (Command == null){Command.Dispose();}
                if (Adapter == null){Adapter.Dispose();}
            }
        }
        #endregion
    }

}
