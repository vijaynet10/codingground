﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
public enum enumReturnStatus{Failed,Succedded}
namespace OOPSCSharp.Common
{
   public  class ReturnStatus
    {
        #region "Properties and variables"

        /// <summary>
        /// Exception of the class object, property set value  should be hide from  public  
        /// </summary>
        private Exception m_Ex;public Exception Ex { get { return m_Ex; } private set { this.m_Ex = value; } }
        /// <summary>
        /// Stattus of this class object  is it failed or Succedded the  set value  should be hide  from public  
        /// </summary>
        private enumReturnStatus m_Status;public enumReturnStatus Status { get { return this.m_Status; } private set { this.m_Status = value; } }
        /// <summary>
        /// value of the class object , it stores value , Set access is restricted from public  
        /// </summary>
        private dynamic m_Value; public dynamic Value { get { return this.m_Value; } private set { this.m_Value = value; } }
        /// <summary>
        /// it handles message for class object , set access is  restricted from public 
        /// </summary>
        public string m_Description; public string Description { get { return this.m_Description; } set { this.m_Description = value; } }

        /// <summary>
        /// it returns  exception messsage , no set property 
        /// </summary>
        public string ExceptionMessage
        {
            get {
            if (Ex== null) {return string.Empty;}
            else{return Ex.Message;}
            }
        }
        #endregion

        #region "constructor"
       public ReturnStatus(enumReturnStatus _Status) { this.Status = m_Status; }
       public ReturnStatus(enumReturnStatus _Status, string _Description) { this.Status = m_Status; this.Description = _Description; }
       public ReturnStatus(enumReturnStatus _Status, dynamic _value) { this.Status = m_Status; this.Value = _value; }
       public ReturnStatus(Exception _ex) { this.Status = enumReturnStatus.Failed; this.Ex = _ex; }
        #endregion
    }
}