﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms; /// Namespace of Forms for  form related controls, if u want web  it should be develop with  web controls
using System.Data;

namespace OOPSCSharp.Common
{
    public class Controls
    {
        private ReturnStatus oReturnStatus;
        public  ReturnStatus FillComboBox(ComboBox ComboBoxControl, DataTable Data, String DisplayMember, String ValueMember)
        {
            try
            {
                ComboBoxControl.DataSource = Data;
                ComboBoxControl.DisplayMember = DisplayMember;
                ComboBoxControl.ValueMember = ValueMember;
                oReturnStatus = new ReturnStatus(enumReturnStatus.Succedded);
                return oReturnStatus;
            }
            catch (Exception ex) { 
            oReturnStatus = new ReturnStatus(ex);
            return oReturnStatus;
            }
        }
    }
}
