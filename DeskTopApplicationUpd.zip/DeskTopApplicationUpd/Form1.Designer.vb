﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.TLP_Mian = New System.Windows.Forms.TableLayoutPanel()
        Me.LblHelloWorld = New System.Windows.Forms.Label()
        Me.TLP_Mian.SuspendLayout()
        Me.SuspendLayout()
        '
        'TLP_Mian
        '
        Me.TLP_Mian.ColumnCount = 1
        Me.TLP_Mian.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TLP_Mian.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 27.0!))
        Me.TLP_Mian.Controls.Add(Me.LblHelloWorld, 0, 0)
        Me.TLP_Mian.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TLP_Mian.Location = New System.Drawing.Point(0, 0)
        Me.TLP_Mian.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.TLP_Mian.Name = "TLP_Mian"
        Me.TLP_Mian.RowCount = 2
        Me.TLP_Mian.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10.75269!))
        Me.TLP_Mian.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 89.24731!))
        Me.TLP_Mian.Size = New System.Drawing.Size(1239, 837)
        Me.TLP_Mian.TabIndex = 0
        '
        'LblHelloWorld
        '
        Me.LblHelloWorld.AutoSize = True
        Me.LblHelloWorld.Dock = System.Windows.Forms.DockStyle.Fill
        Me.LblHelloWorld.Font = New System.Drawing.Font("Calibri", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblHelloWorld.Location = New System.Drawing.Point(4, 0)
        Me.LblHelloWorld.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.LblHelloWorld.Name = "LblHelloWorld"
        Me.LblHelloWorld.Size = New System.Drawing.Size(1231, 90)
        Me.LblHelloWorld.TabIndex = 0
        Me.LblHelloWorld.Text = "Label1"
        Me.LblHelloWorld.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 19.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1239, 837)
        Me.Controls.Add(Me.TLP_Mian)
        Me.Font = New System.Drawing.Font("Calibri", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.TLP_Mian.ResumeLayout(False)
        Me.TLP_Mian.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents TLP_Mian As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents LblHelloWorld As System.Windows.Forms.Label

End Class
