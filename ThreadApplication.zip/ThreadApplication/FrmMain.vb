﻿Public Class FrmMain
    Private Sub FrmMain_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
    Public Delegate Sub Del_Sub_AddLine(ByVal IntVlaue As Integer)

    Public Delegate Function Del_Function_AddLine(ByVal IntVlaue As Integer) As Boolean

    Sub Sub_AddLine(ByVal IntVlaue As Integer)
        If RichTextBox1.InvokeRequired Then
            RichTextBox1.Invoke(New Del_Sub_AddLine(AddressOf Sub_AddLine), {IntVlaue})
        Else
            RichTextBox1.Text &= vbNewLine & " Hai SUb" & Now & " With Count : " & IntVlaue
        End If
    End Sub
    Function Fun_AddLine(ByVal IntVlaue As Integer) As Boolean
        If RichTextBox1.InvokeRequired Then
            Dim oBJ As Boolean = RichTextBox1.Invoke(New Del_Function_AddLine(AddressOf Fun_AddLine), {IntVlaue})
            If oBJ = True Then
                IntVlaue = 43
            End If
        Else
            RichTextBox1.Text &= vbNewLine & "Function Call On " & Now & " With Count : " & IntVlaue
            If IntVlaue Mod 2 = 0 Then
                Return True
            Else
                Return False
            End If
        End If
        Return True
    End Function
    Dim thread1 As System.Threading.Thread
    Dim thread2 As System.Threading.Thread
    Dim Max As Integer = 50

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Try



            thread1 = New Threading.Thread(AddressOf FunctionCall)
            thread1.Name = "thread1"

            thread2 = New Threading.Thread(AddressOf SubCall)
            thread2.Name = "thread2"
            thread1.IsBackground = True : thread2.IsBackground = True
            thread1.SetApartmentState(Threading.ApartmentState.MTA)
            thread2.SetApartmentState(Threading.ApartmentState.MTA)

            ProgressBar1.Step = 1
            ProgressBar1.Value = 0
            ProgressBar1.Maximum = Max


            ProgressBar2.Step = 1
            ProgressBar2.Value = 0
            ProgressBar2.Maximum = Max



            thread1.Start() : thread2.Start()
            'thread1.Join() : thread2.Join()



        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub

    Sub FunctionCall()
        For Inti As Integer = 1 To Max
            Fun_AddLine(Inti)
            System.Threading.Thread.Sleep(10)
            ProgressPerformStep2()
        Next
        If thread1.IsAlive Then
            Dim i As Integer = 12

        End If
    End Sub
    Sub SubCall()
        For inti As Integer = 0 To Max
            Sub_AddLine(inti)
            System.Threading.Thread.Sleep(10)
            ProgressPerformStep1()
            DisplayprogressValue1("Processed " & inti & " of Max  ")
        Next
    End Sub
    Delegate Sub Del_ProgressPerformStep1()

    Sub ProgressPerformStep1()
        If ProgressBar1.InvokeRequired Then
            ProgressBar1.Invoke(New Del_ProgressPerformStep1(AddressOf ProgressPerformStep1))
        Else
            ProgressBar1.PerformStep()
        End If
    End Sub

    Delegate Sub Del_ProgressPerformStep2()

    Sub ProgressPerformStep2()
        If ProgressBar2.InvokeRequired Then
            ProgressBar2.Invoke(New Del_ProgressPerformStep2(AddressOf ProgressPerformStep2))
        Else
            ProgressBar2.PerformStep()
        End If
    End Sub

    Delegate Sub Del_DisplayprogressValue1(Message As String)
    Sub DisplayprogressValue1(Message As String)
        If lblPrgressValue.InvokeRequired Then
            lblPrgressValue.Invoke(New Del_DisplayprogressValue1(AddressOf DisplayprogressValue1), {Message})
        Else
            lblPrgressValue.Text = Message
            lblPrgressValue.Refresh()

        End If
    End Sub
 




End Class
