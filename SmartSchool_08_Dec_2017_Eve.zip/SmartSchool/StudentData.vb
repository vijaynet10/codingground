﻿Partial Class StudentData
    Partial Class StudentMarkDataTable

       

    End Class

End Class
