﻿Public Class Login
    Private Sub OK_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OK.Click
        Try
            If UsernameTextBox.Text.ToUpper <> "ADMIN" Then UsernameTextBox.Focus() : Throw New Exception("invalid user name")
            If PasswordTextBox.Text.ToUpper <> "ADMIN" Then PasswordTextBox.Focus() : Throw New Exception("invalid password")
            Me.DialogResult = System.Windows.Forms.DialogResult.OK
            Me.Close()
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub

    Private Sub Cancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cancel.Click
        Me.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.Close()
    End Sub

End Class
