﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FrmMarkAnalytical
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Btn_Process = New System.Windows.Forms.Button()
        Me.ReportView_SM = New Microsoft.Reporting.WinForms.ReportViewer()
        Me.TLP_Main = New System.Windows.Forms.TableLayoutPanel()
        Me.Btn_ExporttoPDF = New System.Windows.Forms.Button()
        Me.TLP_Main.SuspendLayout()
        Me.SuspendLayout()
        '
        'Btn_Process
        '
        Me.Btn_Process.Anchor = System.Windows.Forms.AnchorStyles.Right
        Me.Btn_Process.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Btn_Process.Location = New System.Drawing.Point(745, 3)
        Me.Btn_Process.Name = "Btn_Process"
        Me.Btn_Process.Size = New System.Drawing.Size(85, 26)
        Me.Btn_Process.TabIndex = 0
        Me.Btn_Process.Text = "&Process"
        Me.Btn_Process.UseVisualStyleBackColor = True
        '
        'ReportView_SM
        '
        Me.ReportView_SM.Dock = System.Windows.Forms.DockStyle.Fill
        Me.ReportView_SM.DocumentMapWidth = 92
        Me.ReportView_SM.Location = New System.Drawing.Point(3, 35)
        Me.ReportView_SM.Name = "ReportView_SM"
        Me.ReportView_SM.Size = New System.Drawing.Size(827, 429)
        Me.ReportView_SM.TabIndex = 1
        '
        'TLP_Main
        '
        Me.TLP_Main.ColumnCount = 1
        Me.TLP_Main.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TLP_Main.Controls.Add(Me.ReportView_SM, 0, 1)
        Me.TLP_Main.Controls.Add(Me.Btn_Process, 0, 0)
        Me.TLP_Main.Controls.Add(Me.Btn_ExporttoPDF, 0, 2)
        Me.TLP_Main.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TLP_Main.Location = New System.Drawing.Point(0, 0)
        Me.TLP_Main.Name = "TLP_Main"
        Me.TLP_Main.RowCount = 3
        Me.TLP_Main.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.565694!))
        Me.TLP_Main.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 86.86861!))
        Me.TLP_Main.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.565694!))
        Me.TLP_Main.Size = New System.Drawing.Size(833, 501)
        Me.TLP_Main.TabIndex = 2
        '
        'Btn_ExporttoPDF
        '
        Me.Btn_ExporttoPDF.Anchor = System.Windows.Forms.AnchorStyles.Right
        Me.Btn_ExporttoPDF.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Btn_ExporttoPDF.Location = New System.Drawing.Point(745, 471)
        Me.Btn_ExporttoPDF.Name = "Btn_ExporttoPDF"
        Me.Btn_ExporttoPDF.Size = New System.Drawing.Size(85, 26)
        Me.Btn_ExporttoPDF.TabIndex = 0
        Me.Btn_ExporttoPDF.Text = "&Export to PDF"
        Me.Btn_ExporttoPDF.UseVisualStyleBackColor = True
        '
        'FrmMarkAnalytical
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(833, 501)
        Me.Controls.Add(Me.TLP_Main)
        Me.ImeMode = System.Windows.Forms.ImeMode.[On]
        Me.Name = "FrmMarkAnalytical"
        Me.Text = "Students Mark Analytical System"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.TLP_Main.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Btn_Process As System.Windows.Forms.Button
    Friend WithEvents ReportView_SM As Microsoft.Reporting.WinForms.ReportViewer
    Friend WithEvents TLP_Main As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents Btn_ExporttoPDF As System.Windows.Forms.Button

End Class
