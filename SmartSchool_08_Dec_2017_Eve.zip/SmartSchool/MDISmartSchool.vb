﻿Imports System.Windows.Forms
Public Class MDISmartSchool
    Private WithEvents ActiveChild As Form
    Sub FormShow(_Frm As Form)
        Try
            If IsNothing(ActiveChild) = False Then ActiveChild.Close()
            With _Frm
                .FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
                .WindowState = FormWindowState.Maximized
                .ControlBox = False
                .MdiParent = Me
                .ShowInTaskbar = False
                .Parent = Me.Panel_Content
                .Dock = DockStyle.Fill
                .Show()
            End With
            ActiveChild = _Frm
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub
    Private Sub ExcelUploadToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ExcelUploadToolStripMenuItem.Click
        Try
            FormShow(FrmMarkAnalytical)
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub
    Public Sub New()
        InitializeComponent()
        Me.WindowState = FormWindowState.Maximized
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Btn_Close.Visible = False
    End Sub
    Private Sub Btn_Close_Click(sender As Object, e As EventArgs) Handles Btn_Close.Click
        Try
            If IsNothing(ActiveChild) = False Then ActiveChild.Close()
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub
    Private Sub ActiveChild_FormClosed(sender As Object, e As FormClosedEventArgs) Handles ActiveChild.FormClosed
        Try
            Btn_Close.Visible = False
            Menu_Main.Visible = True
            lblHeading.Text = ""
            lblHeading.Visible = False
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub
    Private Sub ActiveChild_Shown(sender As Object, e As EventArgs) Handles ActiveChild.Shown
        Try
            Btn_Close.Visible = True
            Menu_Main.Visible = False
            lblHeading.Text = ActiveChild.Text
            lblHeading.Visible = True
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub
    Private Sub ExitToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ExitToolStripMenuItem.Click
        Try
            exitme()
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub
    Private Sub MDISmartSchool_Shown(sender As Object, e As EventArgs) Handles Me.Shown
        Try
            Dim diaresult As DialogResult = Login.ShowDialog()
            If diaresult <> System.Windows.Forms.DialogResult.OK Then exitme()
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub
    Sub exitme()
        Application.ExitThread()
        Application.Exit()
        Environment.Exit(0)
    End Sub

    Private Sub QuestionStructureToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles QuestionStructureToolStripMenuItem.Click
        Try
            FormShow(FrmQuestionStructure)
        Catch ex As Exception
            MessageBox.Show(ex.Message)

        End Try
    End Sub
End Class
