﻿Public Class FrmQuestionStructure
    Private Logic As New Model.QuestionStructure
    Dim WithEvents CurrentQuestion As QuestionBase


    Sub New()
        InitializeComponent()
        Me.DoubleBuffered = True
        TLP_Questions.RowStyles.Clear()

        AddControl()


    End Sub
    Private Sub QuestionBase1_Load(sender As Object, e As EventArgs) Handles Me.Load
        
        
    End Sub
    Public Function RemoveControl(_QuestionBase As QuestionBase) As Int32
        Try



            Me.Logic.RemoveQuestion(_QuestionBase.Logic)
            Me.FLP_Questions.Controls.Remove(_QuestionBase)
            _QuestionBase.Dispose()
            Me.Logic.QuestionBase.Remove(_QuestionBase)
            Me.Logic.ReAlign(_QuestionBase.Logic)

            For Each QB In Me.Logic.QuestionBase
                QB.ReAligndata()
            Next

            Return 0
        Catch ex As Exception
            Throw
        End Try
    End Function
    Public Function AddControl(Optional _MyQB As QuestionBase = Nothing) As Int32
        Try

            If IsNothing(_MyQB) = False Then Me.Logic.AlterQB(_MyQB)


            Dim NewRowStyle As New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 133.0!)
            Dim MyQB As New QuestionBase(Me.Logic.AddNewQuestion, NewRowStyle)
            Dim RowPos As Integer = TLP_Questions.RowStyles.Add(NewRowStyle)

            MyQB.Name = "QuestionBase" & RowPos
            ''''TLP_Questions.Controls.Add(MyQB, 0, RowPos)

            FLP_Questions.Controls.Add(MyQB)

            MyQB.Dock = DockStyle.None
            MyQB.Anchor = AnchorStyles.None
            AddHandler MyQB.AddMore, AddressOf CurrentQuestion_AddMore
            AddHandler MyQB.RemoveMe, AddressOf CurrentQuestion_RemoveMe
            Me.Logic.AddQB(MyQB)
            MyQB.Focus()
            Return 0
        Catch ex As Exception
            Throw
        End Try
    End Function
    Private Sub CurrentQuestion_AddMore(sender As Object) Handles CurrentQuestion.AddMore
        Try
            If Val(Me.Txt_TotalMarks.Text) <= 0 Then
                Me.Txt_TotalMarks.Focus()
                Throw New Exception("Enter the total marks")
            End If

            AddControl(sender)
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub
    Private Sub CurrentQuestion_RemoveMe(sender As Object) Handles CurrentQuestion.RemoveMe
        Try
            RemoveControl(sender)
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub
End Class