﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class MDISmartSchool
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub


    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.ToolTip = New System.Windows.Forms.ToolTip(Me.components)
        Me.tlp_Main = New System.Windows.Forms.TableLayoutPanel()
        Me.Panel_Content = New System.Windows.Forms.Panel()
        Me.TLP_Top = New System.Windows.Forms.TableLayoutPanel()
        Me.TableLayoutPanel1 = New System.Windows.Forms.TableLayoutPanel()
        Me.Btn_Close = New System.Windows.Forms.Button()
        Me.Panel_Menu = New System.Windows.Forms.Panel()
        Me.Menu_Main = New System.Windows.Forms.MenuStrip()
        Me.MasterToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.UserToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.UserPolicyToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem2 = New System.Windows.Forms.ToolStripMenuItem()
        Me.UserToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.CourseOutcomesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.AnalyticsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ExcelUploadToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ExitToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.lblHeading = New System.Windows.Forms.Label()
        Me.QuestionStructureToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.tlp_Main.SuspendLayout()
        Me.TLP_Top.SuspendLayout()
        Me.TableLayoutPanel1.SuspendLayout()
        Me.Panel_Menu.SuspendLayout()
        Me.Menu_Main.SuspendLayout()
        Me.SuspendLayout()
        '
        'tlp_Main
        '
        Me.tlp_Main.ColumnCount = 1
        Me.tlp_Main.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.tlp_Main.Controls.Add(Me.Panel_Content, 0, 1)
        Me.tlp_Main.Controls.Add(Me.TLP_Top, 0, 0)
        Me.tlp_Main.Dock = System.Windows.Forms.DockStyle.Fill
        Me.tlp_Main.Location = New System.Drawing.Point(0, 0)
        Me.tlp_Main.Margin = New System.Windows.Forms.Padding(0)
        Me.tlp_Main.Name = "tlp_Main"
        Me.tlp_Main.RowCount = 2
        Me.tlp_Main.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.216433!))
        Me.tlp_Main.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 91.78357!))
        Me.tlp_Main.Size = New System.Drawing.Size(1155, 499)
        Me.tlp_Main.TabIndex = 9
        '
        'Panel_Content
        '
        Me.Panel_Content.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel_Content.Location = New System.Drawing.Point(0, 40)
        Me.Panel_Content.Margin = New System.Windows.Forms.Padding(0)
        Me.Panel_Content.Name = "Panel_Content"
        Me.Panel_Content.Size = New System.Drawing.Size(1155, 459)
        Me.Panel_Content.TabIndex = 0
        '
        'TLP_Top
        '
        Me.TLP_Top.ColumnCount = 2
        Me.TLP_Top.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 96.27705!))
        Me.TLP_Top.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 3.722944!))
        Me.TLP_Top.Controls.Add(Me.TableLayoutPanel1, 1, 0)
        Me.TLP_Top.Controls.Add(Me.Panel_Menu, 0, 0)
        Me.TLP_Top.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TLP_Top.Location = New System.Drawing.Point(0, 0)
        Me.TLP_Top.Margin = New System.Windows.Forms.Padding(0)
        Me.TLP_Top.Name = "TLP_Top"
        Me.TLP_Top.RowCount = 1
        Me.TLP_Top.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TLP_Top.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 46.0!))
        Me.TLP_Top.Size = New System.Drawing.Size(1155, 40)
        Me.TLP_Top.TabIndex = 1
        '
        'TableLayoutPanel1
        '
        Me.TableLayoutPanel1.ColumnCount = 1
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 95.77167!))
        Me.TableLayoutPanel1.Controls.Add(Me.Btn_Close, 0, 0)
        Me.TableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel1.Location = New System.Drawing.Point(1111, 0)
        Me.TableLayoutPanel1.Margin = New System.Windows.Forms.Padding(0)
        Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
        Me.TableLayoutPanel1.RowCount = 1
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel1.Size = New System.Drawing.Size(44, 40)
        Me.TableLayoutPanel1.TabIndex = 2
        '
        'Btn_Close
        '
        Me.Btn_Close.FlatAppearance.BorderColor = System.Drawing.Color.Red
        Me.Btn_Close.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Btn_Close.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.Btn_Close.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Btn_Close.ForeColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Btn_Close.Location = New System.Drawing.Point(4, 4)
        Me.Btn_Close.Margin = New System.Windows.Forms.Padding(4)
        Me.Btn_Close.Name = "Btn_Close"
        Me.Btn_Close.Size = New System.Drawing.Size(24, 23)
        Me.Btn_Close.TabIndex = 0
        Me.Btn_Close.Text = "X"
        Me.Btn_Close.UseVisualStyleBackColor = True
        '
        'Panel_Menu
        '
        Me.Panel_Menu.Controls.Add(Me.Menu_Main)
        Me.Panel_Menu.Controls.Add(Me.lblHeading)
        Me.Panel_Menu.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel_Menu.Location = New System.Drawing.Point(0, 0)
        Me.Panel_Menu.Margin = New System.Windows.Forms.Padding(0)
        Me.Panel_Menu.Name = "Panel_Menu"
        Me.Panel_Menu.Size = New System.Drawing.Size(1111, 40)
        Me.Panel_Menu.TabIndex = 3
        '
        'Menu_Main
        '
        Me.Menu_Main.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Menu_Main.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Menu_Main.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.MasterToolStripMenuItem, Me.AnalyticsToolStripMenuItem, Me.ExitToolStripMenuItem})
        Me.Menu_Main.Location = New System.Drawing.Point(0, 0)
        Me.Menu_Main.Name = "Menu_Main"
        Me.Menu_Main.Size = New System.Drawing.Size(1111, 40)
        Me.Menu_Main.TabIndex = 1
        Me.Menu_Main.Text = "MenuStrip1"
        '
        'MasterToolStripMenuItem
        '
        Me.MasterToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.UserToolStripMenuItem, Me.CourseOutcomesToolStripMenuItem, Me.ToolStripMenuItem1})
        Me.MasterToolStripMenuItem.Image = Global.SmartSchool.My.Resources.Resources.School_Building_32
        Me.MasterToolStripMenuItem.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.MasterToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.MasterToolStripMenuItem.Name = "MasterToolStripMenuItem"
        Me.MasterToolStripMenuItem.Size = New System.Drawing.Size(102, 36)
        Me.MasterToolStripMenuItem.Text = "Master"
        '
        'UserToolStripMenuItem
        '
        Me.UserToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.UserPolicyToolStripMenuItem, Me.ToolStripMenuItem2, Me.UserToolStripMenuItem1})
        Me.UserToolStripMenuItem.Name = "UserToolStripMenuItem"
        Me.UserToolStripMenuItem.Size = New System.Drawing.Size(216, 26)
        Me.UserToolStripMenuItem.Text = "User"
        '
        'UserPolicyToolStripMenuItem
        '
        Me.UserPolicyToolStripMenuItem.Name = "UserPolicyToolStripMenuItem"
        Me.UserPolicyToolStripMenuItem.Size = New System.Drawing.Size(124, 26)
        Me.UserPolicyToolStripMenuItem.Text = "Group"
        '
        'ToolStripMenuItem2
        '
        Me.ToolStripMenuItem2.Name = "ToolStripMenuItem2"
        Me.ToolStripMenuItem2.Size = New System.Drawing.Size(124, 26)
        Me.ToolStripMenuItem2.Text = "Policy"
        '
        'UserToolStripMenuItem1
        '
        Me.UserToolStripMenuItem1.Name = "UserToolStripMenuItem1"
        Me.UserToolStripMenuItem1.Size = New System.Drawing.Size(124, 26)
        Me.UserToolStripMenuItem1.Text = "User"
        '
        'CourseOutcomesToolStripMenuItem
        '
        Me.CourseOutcomesToolStripMenuItem.Name = "CourseOutcomesToolStripMenuItem"
        Me.CourseOutcomesToolStripMenuItem.Size = New System.Drawing.Size(216, 26)
        Me.CourseOutcomesToolStripMenuItem.Text = "Course Outcomes"
        '
        'ToolStripMenuItem1
        '
        Me.ToolStripMenuItem1.Name = "ToolStripMenuItem1"
        Me.ToolStripMenuItem1.Size = New System.Drawing.Size(216, 26)
        Me.ToolStripMenuItem1.Text = "Program Outcomes"
        '
        'AnalyticsToolStripMenuItem
        '
        Me.AnalyticsToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ExcelUploadToolStripMenuItem, Me.QuestionStructureToolStripMenuItem})
        Me.AnalyticsToolStripMenuItem.Image = Global.SmartSchool.My.Resources.Resources.university_school_32
        Me.AnalyticsToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.AnalyticsToolStripMenuItem.Name = "AnalyticsToolStripMenuItem"
        Me.AnalyticsToolStripMenuItem.Size = New System.Drawing.Size(116, 36)
        Me.AnalyticsToolStripMenuItem.Text = "Analytics"
        '
        'ExcelUploadToolStripMenuItem
        '
        Me.ExcelUploadToolStripMenuItem.Image = Global.SmartSchool.My.Resources.Resources._19_1user_32
        Me.ExcelUploadToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.ExcelUploadToolStripMenuItem.Name = "ExcelUploadToolStripMenuItem"
        Me.ExcelUploadToolStripMenuItem.Size = New System.Drawing.Size(227, 38)
        Me.ExcelUploadToolStripMenuItem.Text = "Excel Upload"
        '
        'ExitToolStripMenuItem
        '
        Me.ExitToolStripMenuItem.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ExitToolStripMenuItem.Image = Global.SmartSchool.My.Resources.Resources.school_32
        Me.ExitToolStripMenuItem.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.ExitToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.ExitToolStripMenuItem.Name = "ExitToolStripMenuItem"
        Me.ExitToolStripMenuItem.Size = New System.Drawing.Size(78, 36)
        Me.ExitToolStripMenuItem.Text = "E&xit"
        '
        'lblHeading
        '
        Me.lblHeading.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lblHeading.Font = New System.Drawing.Font("Calibri", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblHeading.Location = New System.Drawing.Point(0, 0)
        Me.lblHeading.Name = "lblHeading"
        Me.lblHeading.Size = New System.Drawing.Size(1111, 40)
        Me.lblHeading.TabIndex = 3
        Me.lblHeading.Text = "Heading...."
        Me.lblHeading.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'QuestionStructureToolStripMenuItem
        '
        Me.QuestionStructureToolStripMenuItem.Name = "QuestionStructureToolStripMenuItem"
        Me.QuestionStructureToolStripMenuItem.Size = New System.Drawing.Size(227, 38)
        Me.QuestionStructureToolStripMenuItem.Text = "Question Structure"
        '
        'MDISmartSchool
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1155, 499)
        Me.Controls.Add(Me.tlp_Main)
        Me.IsMdiContainer = True
        Me.Name = "MDISmartSchool"
        Me.Text = "MDISmartSchool"
        Me.tlp_Main.ResumeLayout(False)
        Me.TLP_Top.ResumeLayout(False)
        Me.TableLayoutPanel1.ResumeLayout(False)
        Me.Panel_Menu.ResumeLayout(False)
        Me.Panel_Menu.PerformLayout()
        Me.Menu_Main.ResumeLayout(False)
        Me.Menu_Main.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents ToolTip As System.Windows.Forms.ToolTip
    Friend WithEvents tlp_Main As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents Panel_Content As System.Windows.Forms.Panel
    Friend WithEvents Menu_Main As System.Windows.Forms.MenuStrip
    Friend WithEvents MasterToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents UserToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents UserPolicyToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem2 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents UserToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CourseOutcomesToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AnalyticsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ExcelUploadToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TLP_Top As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents ExitToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TableLayoutPanel1 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents Btn_Close As System.Windows.Forms.Button
    Friend WithEvents Panel_Menu As System.Windows.Forms.Panel
    Friend WithEvents lblHeading As System.Windows.Forms.Label
    Friend WithEvents QuestionStructureToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem

End Class
