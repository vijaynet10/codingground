﻿Namespace Model
    Public Class QuestionHeader
#Region "Properties"
        Private _Batch As String
        Public Property Batch As String
            Get
                Return _Batch
            End Get
            Set(value As String)
                _Batch = value
            End Set
        End Property
        Private _AcademicYear As String
        Public Property AcademicYear As String
            Get
                Return _AcademicYear
            End Get
            Set(value As String)
                _AcademicYear = value
            End Set
        End Property
        Private _Dept As String
        Public Property Dept As String
            Get
                Return _Dept
            End Get
            Set(value As String)
                _Dept = value
            End Set
        End Property
        Private _Year As String
        Public Property Year As String
            Get
                Return _Year
            End Get
            Set(value As String)
                _Year = value
            End Set
        End Property
        Private _Sem As String
        Public Property Sem As String
            Get
                Return _Sem
            End Get
            Set(value As String)
                _Sem = value
            End Set
        End Property
        Private _CourseCode As String
        Public Property CourseCode As String
            Get
                Return _CourseCode
            End Get
            Set(value As String)
                _CourseCode = value
            End Set
        End Property
        Private _Date As Date
        Public Property [Date] As Date
            Get
                Return _Date
            End Get
            Set(value As Date)
                _Date = value
            End Set
        End Property
        Public Property _TotalMarks As Integer = 0
        Public Property TotalMarks As Integer
            Get
                Return _TotalMarks
            End Get
            Set(value As Integer)
                _TotalMarks = value
            End Set
        End Property

        Public Property _Data As DataTable
        Public Property Data As DataTable
            Get
                Return _Data
            End Get
            Set(value As DataTable)
                _Data = value
            End Set
        End Property


#End Region

        Private Function InitData() As Int32
            Try

                Me.Data = New DataTable
                Me.Data.Columns.Add(TableStructure.QuestionHeader.Columns.Batch)
                Me.Data.Columns.Add(TableStructure.QuestionHeader.Columns.AcademicYear)
                Me.Data.Columns.Add(TableStructure.QuestionHeader.Columns.Department)
                Me.Data.Columns.Add(TableStructure.QuestionHeader.Columns.Sem)
                Me.Data.Columns.Add(TableStructure.QuestionHeader.Columns.Date)
                Me.Data.Columns.Add(TableStructure.QuestionHeader.Columns.Duration)
                Me.Data.Columns.Add(TableStructure.QuestionHeader.Columns.TotalMarks, GetType(Integer))

                Return 0
            Catch ex As Exception
                Throw
            End Try
        End Function
        Public Function AddData() As Int32
            Try
                Me.Data.Rows.Clear()
                Dim MyNewRow As DataRow = Me.Data.NewRow
                MyNewRow(TableStructure.QuestionHeader.Columns.Batch) = Me.Batch
                MyNewRow(TableStructure.QuestionHeader.Columns.AcademicYear) = Me.AcademicYear
                MyNewRow(TableStructure.QuestionHeader.Columns.Department) = Me.Dept
                MyNewRow(TableStructure.QuestionHeader.Columns.Sem) = Me.Sem
                MyNewRow(TableStructure.QuestionHeader.Columns.Date) = Me.Date
                MyNewRow(TableStructure.QuestionHeader.Columns.CourseCode) = Me.CourseCode
                MyNewRow(TableStructure.QuestionHeader.Columns.TotalMarks) = Me.TotalMarks
                Me.Data.Rows.Add(MyNewRow)
                Return 0
            Catch ex As Exception
                Throw
            End Try
        End Function
        Public Sub New()
            InitData()
        End Sub
    End Class
End Namespace