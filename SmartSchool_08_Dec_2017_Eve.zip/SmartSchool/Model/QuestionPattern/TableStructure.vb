﻿Namespace TableStructure
    Public Class Part
        Public Class Columns
            Public Shared ReadOnly Code As String = "Code"
            Public Shared ReadOnly Value As String = "Value"
        End Class
    End Class
    Public Class Cognizantlevels
        Public Class Columns
            Public Shared ReadOnly Code As String = "Code"
            Public Shared ReadOnly Value As String = "Value"
        End Class
    End Class
    Public Class CourseOutcomes
        Public Class Columns
            Public Shared ReadOnly Code As String = "Code"
            Public Shared ReadOnly Value As String = "Value"
        End Class
    End Class
    Public Class ProcessOutcomes
        Public Class Columns
            Public Shared ReadOnly Code As String = "Code"
            Public Shared ReadOnly Value As String = "Value"
        End Class
    End Class
    Public Class PSOS
        Public Class Columns
            Public Shared ReadOnly Code As String = "Code"
            Public Shared ReadOnly Value As String = "Value"
        End Class
    End Class
    Public Class QuestionHeader
        Public Class Columns
            Public Shared ReadOnly Batch As String = "Batch"
            Public Shared ReadOnly AcademicYear As String = "AcademicYear"
            Public Shared ReadOnly Department As String = "Department"
            Public Shared ReadOnly Year As String = "Year"
            Public Shared ReadOnly Sem As String = "Sem"
            Public Shared ReadOnly CourseCode As String = "CourseCode"
            Public Shared ReadOnly [Date] As String = "Date"
            Public Shared ReadOnly Duration As String = "Duration"
            Public Shared ReadOnly TotalMarks As String = "TotalMarks"
        End Class
    End Class
    Public Class Questions
        Public Class Columns
            Public Shared ReadOnly Sno As String = "Batch"
            Public Shared ReadOnly Qno As String = "Qno"
            Public Shared ReadOnly Part As String = "Part"
            Public Shared ReadOnly PartQNo As String = "PartQNo"
            Public Shared ReadOnly Mark As String = "Mark"
            Public Shared ReadOnly CL As String = "CL"
            Public Shared ReadOnly CO As String = "CO"
            Public Shared ReadOnly PO As String = "PO"
            Public Shared ReadOnly PSO As String = "PSO"
        End Class
    End Class
End Namespace
