﻿Public Interface IDBFunctions
    Property Data As DataTable
    Property SelectedData As DataTable
    Function GetData() As Boolean
    Function InitData() As DataTable
    Function SetSelectedData(_SelectedItems As Object) As Int32
End Interface
