﻿Namespace Master
    Public Class Part
        Implements IDBFunctions

        Public Property Data As DataTable Implements IDBFunctions.Data
        Public Function GetData() As Boolean Implements IDBFunctions.GetData
            Try
                Data = InitData()
            

                For Count = 1 To 3
                    Dim NewRow As DataRow = Data.NewRow
                    NewRow(TableStructure.Part.Columns.Code) = Count
                    NewRow(TableStructure.Part.Columns.Value) = ChrW(64 + Count)
                    Data.Rows.Add(NewRow)
                Next
                Return True
            Catch ex As Exception
                Throw
            End Try
        End Function

        Public Property SelectedData As DataTable Implements IDBFunctions.SelectedData

        Public Function InitData() As DataTable Implements IDBFunctions.InitData
            Dim MyData = New DataTable
            MyData.Columns.Add(TableStructure.Part.Columns.Code)
            MyData.Columns.Add(TableStructure.Part.Columns.Value)

            Return MyData
        End Function
        Public Function SetSelectedData(_SelectedItems As Object) As Integer Implements IDBFunctions.SetSelectedData
            Try
                SelectedData = InitData()
                For Each MyRow As DataRow In _SelectedItems
                    Dim NewRow = SelectedData.NewRow
                    NewRow(TableStructure.Part.Columns.Code) = MyRow(TableStructure.Part.Columns.Code)
                    NewRow(TableStructure.Part.Columns.Value) = MyRow(TableStructure.Part.Columns.Value)
                    SelectedData.Rows.Add(NewRow)
                Next
                Return 0
            Catch ex As Exception
                Throw
            End Try
        End Function

    End Class
End Namespace