﻿Namespace Master
    Public Class Cognizantlevels
        Implements IDBFunctions



        Public Property Data As DataTable Implements IDBFunctions.Data
        Public Function GetData() As Boolean Implements IDBFunctions.GetData
            Try

                Me.Data = InitData()
                For Count = 1 To 5
                    Dim NewRow As DataRow = Data.NewRow
                    NewRow(TableStructure.Cognizantlevels.Columns.Code) = Count
                    NewRow(TableStructure.Cognizantlevels.Columns.Value) = Count
                    Data.Rows.Add(NewRow)
                Next
                Return True
            Catch ex As Exception
                Throw
            End Try
        End Function

        Public Property SelectedData As DataTable Implements IDBFunctions.SelectedData

        Public Function InitData() As DataTable Implements IDBFunctions.InitData
            Dim MyData = New DataTable
            MyData.Columns.Add(TableStructure.Cognizantlevels.Columns.Code)
            MyData.Columns.Add(TableStructure.Cognizantlevels.Columns.Value)
            Return MyData
        End Function
        Public Function SetSelectedData(_SelectedItems As Object) As Integer Implements IDBFunctions.SetSelectedData
            Try
                SelectedData = InitData()
                For Each MyRow As DataRow In _SelectedItems
                    Dim NewRow = SelectedData.NewRow
                    NewRow(TableStructure.Cognizantlevels.Columns.Code) = MyRow(TableStructure.Cognizantlevels.Columns.Code)
                    NewRow(TableStructure.Cognizantlevels.Columns.Value) = MyRow(TableStructure.Cognizantlevels.Columns.Value)
                    SelectedData.Rows.Add(NewRow)
                Next
                Return 0
            Catch ex As Exception
                Throw
            End Try
        End Function
    End Class
End Namespace