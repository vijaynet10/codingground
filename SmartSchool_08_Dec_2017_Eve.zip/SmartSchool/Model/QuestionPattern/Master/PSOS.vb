﻿Namespace Master
    Public Class PSOS
        Implements IDBFunctions

        Public Property Data As DataTable Implements IDBFunctions.Data
        Public Function GetData() As Boolean Implements IDBFunctions.GetData
            Try
                Data = InitData()
           

                For Count = 1 To 3
                    Dim NewRow As DataRow = Data.NewRow
                    NewRow(TableStructure.PSOS.Columns.Code) = Count
                    NewRow(TableStructure.PSOS.Columns.Value) = Count
                    Data.Rows.Add(NewRow)
                Next
                Return True
            Catch ex As Exception
                Throw
            End Try
        End Function

        Public Property SelectedData As DataTable Implements IDBFunctions.SelectedData
        Public Function InitData() As DataTable Implements IDBFunctions.InitData
            Dim MyData = New DataTable

            MyData.Columns.Add(TableStructure.PSOS.Columns.Code)
            MyData.Columns.Add(TableStructure.PSOS.Columns.Value)

            Return MyData
        End Function

        Public Function SetSelectedData(_SelectedItems As Object) As Integer Implements IDBFunctions.SetSelectedData
            Try
                SelectedData = InitData()
                For Each MyRow As DataRow In _SelectedItems
                    Dim NewRow = SelectedData.NewRow
                    NewRow(TableStructure.PSOS.Columns.Code) = MyRow(TableStructure.PSOS.Columns.Code)
                    NewRow(TableStructure.PSOS.Columns.Value) = MyRow(TableStructure.PSOS.Columns.Value)
                    SelectedData.Rows.Add(NewRow)
                Next
                Return 0
            Catch ex As Exception
                Throw
            End Try
        End Function

    End Class
End Namespace