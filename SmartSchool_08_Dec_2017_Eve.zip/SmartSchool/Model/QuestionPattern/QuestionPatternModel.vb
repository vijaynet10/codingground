﻿Namespace QuestionStructure
    Public Class QuestionPatternModel
        Public Property Mark As Integer = 0
        Public Property Part As String = String.Empty
        Private _Sno As Integer
        Public Property Sno As Integer
            Get
                Return _Sno
            End Get
            Set(value As Integer)
                _Sno = value
            End Set
        End Property
        Private _PartQuestionNumber As Integer
        Public Property PartQuestionNumber As Integer
            Get
                Return _PartQuestionNumber
            End Get
            Set(value As Integer)
                _PartQuestionNumber = value
            End Set
        End Property

        Sub New(_QuestionNumber As Integer)
            Me.Sno = _QuestionNumber
            Cognizantlevels.GetData()
            CourseOutcomes.GetData()
            ProcessOutcomes.GetData()
            PSOS.GetData()
            Parts.GetData()
        End Sub

        Friend Property Cognizantlevels As New Master.Cognizantlevels
        Friend Property CourseOutcomes As New Master.CourseOutcomes
        Friend Property ProcessOutcomes As New Master.ProcessOutcomes
        Friend Property PSOS As New Master.PSOS
        Friend [Parts] As New Master.Part


    End Class
End Namespace
