﻿Imports SmartSchool.QuestionStructure
Namespace Model
    Public Class QuestionStructure
        Private _QuestionHeader As New QuestionHeader
        Public Property QuestionHeader As QuestionHeader
            Get
                Return _QuestionHeader
            End Get
            Set(value As QuestionHeader)
                _QuestionHeader = value
            End Set
        End Property

        Private _QuestionBase As New List(Of QuestionBase)
        Friend Property QuestionBase As List(Of QuestionBase)
            Get
                Return _QuestionBase
            End Get
            Set(value As List(Of QuestionBase))
                _QuestionBase = value
            End Set
        End Property
        Friend Function AlterQB(_QuestionBase As QuestionBase) As Int32
            Try
                GetPartQuestionNumber(_QuestionBase.Logic)
                _QuestionBase.ReAligndata()

                Return 0
            Catch ex As Exception
                Throw
            End Try
        End Function
        Friend Function AddQB(_QuestionBase As QuestionBase) As Int32
            Try
                GetPartQuestionNumber(_QuestionBase.Logic)
                _QuestionBase.ReAligndata()

                Return 0
            Catch ex As Exception
                Throw
            End Try
        End Function



        Private _Questions As New List(Of QuestionPatternModel)
        Public Property Questions As List(Of QuestionPatternModel)
            Get
                Return _Questions
            End Get
            Set(value As List(Of QuestionPatternModel))
                _Questions = value
            End Set
        End Property
        Public Function AddNewQuestion() As QuestionPatternModel
            Try

                Dim MyQuestionPatternModel As New QuestionPatternModel(Questions.Count + 1)
                Me.Questions.Add(MyQuestionPatternModel)
                Return MyQuestionPatternModel
            Catch ex As Exception
                Throw
            End Try
        End Function
        Public Function RemoveQuestion(_QuestionPatternModel As QuestionPatternModel) As Int32
            Try
                If Me.Questions.Count <= 1 Then Throw New Exception("Default one question required")
                Me.Questions.Remove(_QuestionPatternModel)
                Return 0
            Catch ex As Exception
                Throw
            End Try
        End Function

        Public Function ReAlign(_QuestionPatternModel As QuestionPatternModel) As Int32
            Try

                Dim Sequence As Integer = 0
                For Each QP In Questions
                    Sequence += 1
                    QP.Sno = Sequence
                Next

                Dim PartQuestions = (From QuestPattern In Me.Questions Where QuestPattern.Part = _QuestionPatternModel.Part Select QuestPattern).ToList
                Sequence = 0
                For Each PartQP In PartQuestions
                    Sequence += 1
                    PartQP.PartQuestionNumber = Sequence
                Next
                Return 0
            Catch ex As Exception
                Throw
            End Try
        End Function
        Public Function GetPartQuestionNumber(_QuestionPatternModel As QuestionPatternModel) As Int32
            Try

                Dim PartQuestions = (From QuestPattern In Me.Questions Where QuestPattern.Part = _QuestionPatternModel.Part And QuestPattern.Sno < _QuestionPatternModel.Sno Select QuestPattern).ToList
                If PartQuestions.Count = 1 Then
                    _QuestionPatternModel.PartQuestionNumber = 1
                Else
                    _QuestionPatternModel.PartQuestionNumber = PartQuestions.Count + 1
                End If

                Return 0
            Catch ex As Exception
                Throw
            End Try
        End Function
    End Class
End Namespace