﻿Imports SmartSchool.QuestionStructure

Namespace Model
    Partial Class QuestionStructure
        Public Class Question

        End Class
    End Class
End Namespace