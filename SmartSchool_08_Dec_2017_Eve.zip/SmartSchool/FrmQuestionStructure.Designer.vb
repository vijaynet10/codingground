﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FrmQuestionStructure
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.TLP_Main = New System.Windows.Forms.TableLayoutPanel()
        Me.TLP_Header = New System.Windows.Forms.TableLayoutPanel()
        Me.TLP_Header2 = New System.Windows.Forms.TableLayoutPanel()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.txtCourseTitle = New System.Windows.Forms.TextBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.TxtNoOfStudents = New System.Windows.Forms.TextBox()
        Me.TxtCourseCode = New System.Windows.Forms.TextBox()
        Me.TLP_Header1 = New System.Windows.Forms.TableLayoutPanel()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.TxtAcademicYear = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.TxtDept = New System.Windows.Forms.TextBox()
        Me.TxtYear = New System.Windows.Forms.TextBox()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.TxtSem = New System.Windows.Forms.TextBox()
        Me.TxtBatch = New System.Windows.Forms.TextBox()
        Me.TLP_Body = New System.Windows.Forms.TableLayoutPanel()
        Me.TableLayoutPanel1 = New System.Windows.Forms.TableLayoutPanel()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.DTP_AssignmentDate = New System.Windows.Forms.DateTimePicker()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Txt_Duration = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Txt_TotalMarks = New System.Windows.Forms.TextBox()
        Me.TLP_Questions = New System.Windows.Forms.TableLayoutPanel()
        Me.FLP_Questions = New System.Windows.Forms.FlowLayoutPanel()
        Me.TLP_Options = New System.Windows.Forms.TableLayoutPanel()
        Me.Btn_Preview = New System.Windows.Forms.Button()
        Me.Btn_Save = New System.Windows.Forms.Button()
        Me.Btn_Cancel = New System.Windows.Forms.Button()
        Me.TLP_Main.SuspendLayout()
        Me.TLP_Header.SuspendLayout()
        Me.TLP_Header2.SuspendLayout()
        Me.TLP_Header1.SuspendLayout()
        Me.TLP_Body.SuspendLayout()
        Me.TableLayoutPanel1.SuspendLayout()
        Me.TLP_Questions.SuspendLayout()
        Me.TLP_Options.SuspendLayout()
        Me.SuspendLayout()
        '
        'TLP_Main
        '
        Me.TLP_Main.ColumnCount = 1
        Me.TLP_Main.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TLP_Main.Controls.Add(Me.TLP_Header, 0, 0)
        Me.TLP_Main.Controls.Add(Me.TLP_Body, 0, 1)
        Me.TLP_Main.Controls.Add(Me.TLP_Options, 0, 2)
        Me.TLP_Main.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TLP_Main.Location = New System.Drawing.Point(0, 0)
        Me.TLP_Main.Margin = New System.Windows.Forms.Padding(0)
        Me.TLP_Main.Name = "TLP_Main"
        Me.TLP_Main.RowCount = 3
        Me.TLP_Main.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 15.17313!))
        Me.TLP_Main.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 78.74465!))
        Me.TLP_Main.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.134094!))
        Me.TLP_Main.Size = New System.Drawing.Size(899, 701)
        Me.TLP_Main.TabIndex = 0
        '
        'TLP_Header
        '
        Me.TLP_Header.BackColor = System.Drawing.Color.White
        Me.TLP_Header.ColumnCount = 1
        Me.TLP_Header.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TLP_Header.Controls.Add(Me.TLP_Header1, 0, 0)
        Me.TLP_Header.Controls.Add(Me.TLP_Header2, 0, 1)
        Me.TLP_Header.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TLP_Header.Location = New System.Drawing.Point(0, 0)
        Me.TLP_Header.Margin = New System.Windows.Forms.Padding(0)
        Me.TLP_Header.Name = "TLP_Header"
        Me.TLP_Header.RowCount = 2
        Me.TLP_Header.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TLP_Header.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TLP_Header.Size = New System.Drawing.Size(899, 106)
        Me.TLP_Header.TabIndex = 0
        '
        'TLP_Header2
        '
        Me.TLP_Header2.BackColor = System.Drawing.Color.White
        Me.TLP_Header2.ColumnCount = 6
        Me.TLP_Header2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10.14656!))
        Me.TLP_Header2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 13.19053!))
        Me.TLP_Header2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.28861!))
        Me.TLP_Header2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 37.99324!))
        Me.TLP_Header2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 8.342729!))
        Me.TLP_Header2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 17.81285!))
        Me.TLP_Header2.Controls.Add(Me.Label7, 0, 0)
        Me.TLP_Header2.Controls.Add(Me.Label8, 2, 0)
        Me.TLP_Header2.Controls.Add(Me.txtCourseTitle, 3, 0)
        Me.TLP_Header2.Controls.Add(Me.Label9, 4, 0)
        Me.TLP_Header2.Controls.Add(Me.TxtNoOfStudents, 5, 0)
        Me.TLP_Header2.Controls.Add(Me.TxtCourseCode, 1, 0)
        Me.TLP_Header2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TLP_Header2.Location = New System.Drawing.Point(0, 53)
        Me.TLP_Header2.Margin = New System.Windows.Forms.Padding(0)
        Me.TLP_Header2.Name = "TLP_Header2"
        Me.TLP_Header2.RowCount = 1
        Me.TLP_Header2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TLP_Header2.Size = New System.Drawing.Size(899, 53)
        Me.TLP_Header2.TabIndex = 1
        '
        'Label7
        '
        Me.Label7.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(3, 8)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(85, 36)
        Me.Label7.TabIndex = 0
        Me.Label7.Text = "Course Code"
        '
        'Label8
        '
        Me.Label8.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(212, 17)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(104, 18)
        Me.Label8.TabIndex = 0
        Me.Label8.Text = "Course Title"
        '
        'txtCourseTitle
        '
        Me.txtCourseTitle.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtCourseTitle.Location = New System.Drawing.Point(322, 13)
        Me.txtCourseTitle.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtCourseTitle.Name = "txtCourseTitle"
        Me.txtCourseTitle.Size = New System.Drawing.Size(336, 26)
        Me.txtCourseTitle.TabIndex = 1
        '
        'Label9
        '
        Me.Label9.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(664, 8)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(69, 36)
        Me.Label9.TabIndex = 0
        Me.Label9.Text = "No. of Students"
        '
        'TxtNoOfStudents
        '
        Me.TxtNoOfStudents.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TxtNoOfStudents.Location = New System.Drawing.Point(739, 13)
        Me.TxtNoOfStudents.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.TxtNoOfStudents.Name = "TxtNoOfStudents"
        Me.TxtNoOfStudents.Size = New System.Drawing.Size(157, 26)
        Me.TxtNoOfStudents.TabIndex = 2
        '
        'TxtCourseCode
        '
        Me.TxtCourseCode.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TxtCourseCode.Location = New System.Drawing.Point(94, 13)
        Me.TxtCourseCode.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.TxtCourseCode.Name = "TxtCourseCode"
        Me.TxtCourseCode.Size = New System.Drawing.Size(112, 26)
        Me.TxtCourseCode.TabIndex = 0
        '
        'TLP_Header1
        '
        Me.TLP_Header1.BackColor = System.Drawing.Color.White
        Me.TLP_Header1.ColumnCount = 10
        Me.TLP_Header1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 5.4505!))
        Me.TLP_Header1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 8.898776!))
        Me.TLP_Header1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10.01112!))
        Me.TLP_Header1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10.34483!))
        Me.TLP_Header1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 5.4505!))
        Me.TLP_Header1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 27.2525!))
        Me.TLP_Header1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 4.671858!))
        Me.TLP_Header1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10.901!))
        Me.TLP_Header1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 4.894327!))
        Me.TLP_Header1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.01335!))
        Me.TLP_Header1.Controls.Add(Me.Label4, 0, 0)
        Me.TLP_Header1.Controls.Add(Me.Label5, 2, 0)
        Me.TLP_Header1.Controls.Add(Me.TxtAcademicYear, 3, 0)
        Me.TLP_Header1.Controls.Add(Me.Label6, 4, 0)
        Me.TLP_Header1.Controls.Add(Me.TxtDept, 5, 0)
        Me.TLP_Header1.Controls.Add(Me.TxtYear, 7, 0)
        Me.TLP_Header1.Controls.Add(Me.Label10, 8, 0)
        Me.TLP_Header1.Controls.Add(Me.Label11, 6, 0)
        Me.TLP_Header1.Controls.Add(Me.TxtSem, 9, 0)
        Me.TLP_Header1.Controls.Add(Me.TxtBatch, 1, 0)
        Me.TLP_Header1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TLP_Header1.Location = New System.Drawing.Point(0, 0)
        Me.TLP_Header1.Margin = New System.Windows.Forms.Padding(0)
        Me.TLP_Header1.Name = "TLP_Header1"
        Me.TLP_Header1.RowCount = 1
        Me.TLP_Header1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TLP_Header1.Size = New System.Drawing.Size(899, 53)
        Me.TLP_Header1.TabIndex = 0
        '
        'Label4
        '
        Me.Label4.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(3, 17)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(43, 18)
        Me.Label4.TabIndex = 0
        Me.Label4.Text = "Batch"
        '
        'Label5
        '
        Me.Label5.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(132, 8)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(84, 36)
        Me.Label5.TabIndex = 0
        Me.Label5.Text = "Academic Year"
        '
        'TxtAcademicYear
        '
        Me.TxtAcademicYear.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TxtAcademicYear.Location = New System.Drawing.Point(222, 13)
        Me.TxtAcademicYear.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.TxtAcademicYear.Name = "TxtAcademicYear"
        Me.TxtAcademicYear.Size = New System.Drawing.Size(87, 26)
        Me.TxtAcademicYear.TabIndex = 1
        '
        'Label6
        '
        Me.Label6.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(315, 17)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(43, 18)
        Me.Label6.TabIndex = 0
        Me.Label6.Text = "Dept"
        '
        'TxtDept
        '
        Me.TxtDept.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TxtDept.Location = New System.Drawing.Point(364, 13)
        Me.TxtDept.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.TxtDept.Name = "TxtDept"
        Me.TxtDept.Size = New System.Drawing.Size(239, 26)
        Me.TxtDept.TabIndex = 2
        '
        'TxtYear
        '
        Me.TxtYear.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TxtYear.Location = New System.Drawing.Point(651, 13)
        Me.TxtYear.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.TxtYear.Name = "TxtYear"
        Me.TxtYear.Size = New System.Drawing.Size(92, 26)
        Me.TxtYear.TabIndex = 3
        '
        'Label10
        '
        Me.Label10.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(749, 17)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(38, 18)
        Me.Label10.TabIndex = 0
        Me.Label10.Text = "Sem"
        '
        'Label11
        '
        Me.Label11.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(609, 17)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(36, 18)
        Me.Label11.TabIndex = 0
        Me.Label11.Text = "Year"
        '
        'TxtSem
        '
        Me.TxtSem.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TxtSem.Location = New System.Drawing.Point(793, 13)
        Me.TxtSem.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.TxtSem.Name = "TxtSem"
        Me.TxtSem.Size = New System.Drawing.Size(103, 26)
        Me.TxtSem.TabIndex = 4
        '
        'TxtBatch
        '
        Me.TxtBatch.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TxtBatch.Location = New System.Drawing.Point(52, 13)
        Me.TxtBatch.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.TxtBatch.Name = "TxtBatch"
        Me.TxtBatch.Size = New System.Drawing.Size(74, 26)
        Me.TxtBatch.TabIndex = 0
        '
        'TLP_Body
        '
        Me.TLP_Body.ColumnCount = 1
        Me.TLP_Body.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TLP_Body.Controls.Add(Me.TableLayoutPanel1, 0, 0)
        Me.TLP_Body.Controls.Add(Me.TLP_Questions, 0, 1)
        Me.TLP_Body.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TLP_Body.Location = New System.Drawing.Point(3, 110)
        Me.TLP_Body.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.TLP_Body.Name = "TLP_Body"
        Me.TLP_Body.RowCount = 2
        Me.TLP_Body.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 11.02362!))
        Me.TLP_Body.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 88.97638!))
        Me.TLP_Body.Size = New System.Drawing.Size(893, 543)
        Me.TLP_Body.TabIndex = 2
        '
        'TableLayoutPanel1
        '
        Me.TableLayoutPanel1.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.TableLayoutPanel1.ColumnCount = 6
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10.83871!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 13.93548!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5!))
        Me.TableLayoutPanel1.Controls.Add(Me.Label2, 0, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.DTP_AssignmentDate, 1, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.Label1, 2, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.Txt_Duration, 3, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.Label3, 4, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.Txt_TotalMarks, 5, 0)
        Me.TableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel1.Location = New System.Drawing.Point(0, 0)
        Me.TableLayoutPanel1.Margin = New System.Windows.Forms.Padding(0)
        Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
        Me.TableLayoutPanel1.RowCount = 1
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel1.Size = New System.Drawing.Size(893, 59)
        Me.TableLayoutPanel1.TabIndex = 0
        '
        'Label2
        '
        Me.Label2.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(3, 20)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(143, 18)
        Me.Label2.TabIndex = 0
        Me.Label2.Text = "Date"
        '
        'DTP_AssignmentDate
        '
        Me.DTP_AssignmentDate.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.DTP_AssignmentDate.CustomFormat = "dd-MMM-yyyy"
        Me.DTP_AssignmentDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.DTP_AssignmentDate.Location = New System.Drawing.Point(152, 16)
        Me.DTP_AssignmentDate.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.DTP_AssignmentDate.Name = "DTP_AssignmentDate"
        Me.DTP_AssignmentDate.Size = New System.Drawing.Size(123, 26)
        Me.DTP_AssignmentDate.TabIndex = 0
        '
        'Label1
        '
        Me.Label1.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(281, 20)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(160, 18)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Duration (Mins)"
        '
        'Txt_Duration
        '
        Me.Txt_Duration.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Txt_Duration.Location = New System.Drawing.Point(447, 16)
        Me.Txt_Duration.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.Txt_Duration.Name = "Txt_Duration"
        Me.Txt_Duration.Size = New System.Drawing.Size(143, 26)
        Me.Txt_Duration.TabIndex = 1
        '
        'Label3
        '
        Me.Label3.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(596, 20)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(143, 18)
        Me.Label3.TabIndex = 0
        Me.Label3.Text = "Total Marks"
        '
        'Txt_TotalMarks
        '
        Me.Txt_TotalMarks.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Txt_TotalMarks.Location = New System.Drawing.Point(745, 16)
        Me.Txt_TotalMarks.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.Txt_TotalMarks.Name = "Txt_TotalMarks"
        Me.Txt_TotalMarks.Size = New System.Drawing.Size(145, 26)
        Me.Txt_TotalMarks.TabIndex = 2
        '
        'TLP_Questions
        '
        Me.TLP_Questions.AutoScroll = True
        Me.TLP_Questions.ColumnCount = 1
        Me.TLP_Questions.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TLP_Questions.Controls.Add(Me.FLP_Questions, 0, 0)
        Me.TLP_Questions.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TLP_Questions.Location = New System.Drawing.Point(3, 63)
        Me.TLP_Questions.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.TLP_Questions.Name = "TLP_Questions"
        Me.TLP_Questions.RowCount = 1
        Me.TLP_Questions.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 484.0!))
        Me.TLP_Questions.Size = New System.Drawing.Size(887, 476)
        Me.TLP_Questions.TabIndex = 1
        '
        'FLP_Questions
        '
        Me.FLP_Questions.AutoScroll = True
        Me.FLP_Questions.BackColor = System.Drawing.Color.WhiteSmoke
        Me.FLP_Questions.Dock = System.Windows.Forms.DockStyle.Fill
        Me.FLP_Questions.FlowDirection = System.Windows.Forms.FlowDirection.TopDown
        Me.FLP_Questions.Location = New System.Drawing.Point(0, 0)
        Me.FLP_Questions.Margin = New System.Windows.Forms.Padding(0)
        Me.FLP_Questions.Name = "FLP_Questions"
        Me.FLP_Questions.Size = New System.Drawing.Size(887, 484)
        Me.FLP_Questions.TabIndex = 0
        Me.FLP_Questions.WrapContents = False
        '
        'TLP_Options
        '
        Me.TLP_Options.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.TLP_Options.ColumnCount = 3
        Me.TLP_Options.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333!))
        Me.TLP_Options.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333!))
        Me.TLP_Options.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333!))
        Me.TLP_Options.Controls.Add(Me.Btn_Preview, 0, 0)
        Me.TLP_Options.Controls.Add(Me.Btn_Save, 1, 0)
        Me.TLP_Options.Controls.Add(Me.Btn_Cancel, 2, 0)
        Me.TLP_Options.Location = New System.Drawing.Point(222, 660)
        Me.TLP_Options.Name = "TLP_Options"
        Me.TLP_Options.RowCount = 1
        Me.TLP_Options.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TLP_Options.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        Me.TLP_Options.Size = New System.Drawing.Size(455, 38)
        Me.TLP_Options.TabIndex = 3
        '
        'Btn_Preview
        '
        Me.Btn_Preview.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Btn_Preview.BackColor = System.Drawing.Color.Green
        Me.Btn_Preview.FlatAppearance.BorderColor = System.Drawing.Color.White
        Me.Btn_Preview.FlatAppearance.BorderSize = 2
        Me.Btn_Preview.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Btn_Preview.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Btn_Preview.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Btn_Preview.ForeColor = System.Drawing.Color.White
        Me.Btn_Preview.Location = New System.Drawing.Point(25, 3)
        Me.Btn_Preview.Name = "Btn_Preview"
        Me.Btn_Preview.Size = New System.Drawing.Size(101, 32)
        Me.Btn_Preview.TabIndex = 0
        Me.Btn_Preview.Text = "Preview"
        Me.Btn_Preview.UseVisualStyleBackColor = False
        '
        'Btn_Save
        '
        Me.Btn_Save.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Btn_Save.BackColor = System.Drawing.Color.Green
        Me.Btn_Save.FlatAppearance.BorderColor = System.Drawing.Color.White
        Me.Btn_Save.FlatAppearance.BorderSize = 2
        Me.Btn_Save.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Btn_Save.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Btn_Save.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Btn_Save.ForeColor = System.Drawing.Color.White
        Me.Btn_Save.Location = New System.Drawing.Point(176, 3)
        Me.Btn_Save.Name = "Btn_Save"
        Me.Btn_Save.Size = New System.Drawing.Size(101, 32)
        Me.Btn_Save.TabIndex = 0
        Me.Btn_Save.Text = "Save"
        Me.Btn_Save.UseVisualStyleBackColor = False
        '
        'Btn_Cancel
        '
        Me.Btn_Cancel.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Btn_Cancel.BackColor = System.Drawing.Color.Green
        Me.Btn_Cancel.FlatAppearance.BorderColor = System.Drawing.Color.White
        Me.Btn_Cancel.FlatAppearance.BorderSize = 2
        Me.Btn_Cancel.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Btn_Cancel.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Btn_Cancel.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Btn_Cancel.ForeColor = System.Drawing.Color.White
        Me.Btn_Cancel.Location = New System.Drawing.Point(328, 3)
        Me.Btn_Cancel.Name = "Btn_Cancel"
        Me.Btn_Cancel.Size = New System.Drawing.Size(101, 32)
        Me.Btn_Cancel.TabIndex = 0
        Me.Btn_Cancel.Text = "Cancel"
        Me.Btn_Cancel.UseVisualStyleBackColor = False
        '
        'FrmQuestionStructure
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 18.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(899, 701)
        Me.Controls.Add(Me.TLP_Main)
        Me.Font = New System.Drawing.Font("Calibri", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.Name = "FrmQuestionStructure"
        Me.Text = "Question Structure"
        Me.TLP_Main.ResumeLayout(False)
        Me.TLP_Header.ResumeLayout(False)
        Me.TLP_Header2.ResumeLayout(False)
        Me.TLP_Header2.PerformLayout()
        Me.TLP_Header1.ResumeLayout(False)
        Me.TLP_Header1.PerformLayout()
        Me.TLP_Body.ResumeLayout(False)
        Me.TableLayoutPanel1.ResumeLayout(False)
        Me.TableLayoutPanel1.PerformLayout()
        Me.TLP_Questions.ResumeLayout(False)
        Me.TLP_Options.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents TLP_Main As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents TLP_Header As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents TLP_Body As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents TableLayoutPanel1 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents DTP_AssignmentDate As System.Windows.Forms.DateTimePicker
    Friend WithEvents Txt_Duration As System.Windows.Forms.TextBox
    Friend WithEvents Txt_TotalMarks As System.Windows.Forms.TextBox
    Friend WithEvents TLP_Questions As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents FLP_Questions As System.Windows.Forms.FlowLayoutPanel
    Friend WithEvents TLP_Header2 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents txtCourseTitle As System.Windows.Forms.TextBox
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents TxtNoOfStudents As System.Windows.Forms.TextBox
    Friend WithEvents TLP_Header1 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents TxtAcademicYear As System.Windows.Forms.TextBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents TxtDept As System.Windows.Forms.TextBox
    Friend WithEvents TxtCourseCode As System.Windows.Forms.TextBox
    Friend WithEvents TxtYear As System.Windows.Forms.TextBox
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents TxtSem As System.Windows.Forms.TextBox
    Friend WithEvents TxtBatch As System.Windows.Forms.TextBox
    Friend WithEvents TLP_Options As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents Btn_Preview As System.Windows.Forms.Button
    Friend WithEvents Btn_Save As System.Windows.Forms.Button
    Friend WithEvents Btn_Cancel As System.Windows.Forms.Button
End Class
