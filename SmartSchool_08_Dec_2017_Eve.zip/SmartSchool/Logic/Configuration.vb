﻿Namespace Logic
    Public Enum EnumRowPosition
        Part
        QuestionNo
        MaxMarks
        Cognitivelevel
        StudentRowStarts
    End Enum
    Public Enum EnumColumnPosition
        Mark
        Total
        Assignment
    End Enum

    Public Class RowConfiguration
        Public Shared Part As Integer = 3
        Public Shared QuestionNo As Integer = 4
        Public Shared MaxMarks As Integer = 5
        Public Shared Cognitivelevel As Integer = 7
        Public Shared StudentStarts As Integer = 9
    End Class
    Public Class ColumnConfiguration
        Public Shared Mark As Integer = 2
        Public Shared Total As Integer = 24
        Public Shared Assignment As Integer = 23
    End Class
End Namespace