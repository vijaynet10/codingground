﻿Imports Microsoft.Office.Interop.Excel

Namespace Logic
    Public Class MasterDataStructure
        Public ReadOnly RollNumber As String = "RollNumber"
        Public ReadOnly Name As String = "Name"
        Public ReadOnly Total As String = "Total"
        Public ReadOnly Total100 As String = "Total100"
        Public ReadOnly Assignment As String = "Assignment"
        Public ReadOnly Avg As String = "Avg"
        Public Property ColumnNameIndexs As New List(Of ColumnNameIndex)
        Public Function ColumnName(_ColumnIndex As Integer) As String
            Try
                Dim Selects = (From CN In ColumnNameIndexs Where CN.ColumnIndex = _ColumnIndex Select CN).ToList
                If Selects.Count <= 0 Then
                    Throw New Exception("ColumnName not found for index " & _ColumnIndex)
                Else
                    Return Selects(0).ColumnName
                End If


            Catch ex As Exception
                Throw
            End Try


        End Function
    End Class
    Public Class ColumnNameIndex
        Public Property ColumnIndex As Integer = 0
        Public Property ColumnName As String = ""
    End Class
    Public Class Excel
        Public MasterDataStructure As New MasterDataStructure
        Dim ExcelApplication As Application
        Dim ExcelWorkbook As Workbook
        Dim ExcelWorksheet As Worksheet
        Dim ExcelValues As New List(Of ExcelRow)
        Friend Property MarkMaster As New Data.DataTable
        Friend Property CopiedMarkMaster As New Data.DataTable





        Friend Function DoWork(_ExcelFile As String) As Boolean
            Try

                If IO.File.Exists(_ExcelFile) = False Then Throw New Exception("File not found")


                ExcelApplication = New Application
                ExcelWorkbook = ExcelApplication.Workbooks.Open(_ExcelFile)
                If ExcelWorkbook.Sheets.Count <= 0 Then Throw New Exception("Sheet Not found in the excel workbook")
                ExcelWorksheet = ExcelWorkbook.Sheets(1)
                Dim MyUsedRange As Range = ExcelWorksheet.UsedRange
                Dim array(,) As Object = MyUsedRange.Value(XlRangeValueDataType.xlRangeValueDefault)



                Dim Bound0 As Integer = array.GetUpperBound(0)
                Dim Bound1 As Integer = array.GetUpperBound(1)
                ExcelValues.Clear()
                ExcelValues.Clear()

                ExcelWorkbook.Close()
                ExcelApplication.Quit()
                releaseObject(ExcelWorksheet)
                releaseObject(ExcelWorkbook)
                releaseObject(ExcelApplication)


                For MyBound0 As Integer = 1 To Bound0
                    Dim MyExcelRow As New ExcelRow
                    MyExcelRow.Row = MyBound0 - 1
                    For MyBound1 As Integer = 1 To Bound1
                        Dim MyExcelColumn As New ExcelColumn
                        MyExcelColumn.Column = MyBound1 - 1
                        MyExcelColumn.Value = array(MyBound0, MyBound1)
                        MyExcelRow.ExcelColumns.Add(MyExcelColumn)
                    Next
                    ExcelValues.Add(MyExcelRow)
                Next
                BuildMarkMaster()
                CopiedMarkMaster = MarkMaster.Copy
                CopiedMarkMaster.Rows.RemoveAt(0)
                Return True
            Catch ex As Exception
                Throw
            Finally
                releaseObject(ExcelWorksheet)
                releaseObject(ExcelWorkbook)
                releaseObject(ExcelApplication)

            End Try
        End Function
        Friend Function BuildMarkMaster() As Boolean
            Try

                MarkMaster = New Data.DataTable
                Dim QuestionRow As ExcelRow = ExcelSpecific.GetRow(EnumRowPosition.QuestionNo, Me.ExcelValues)
                Dim PartRow As ExcelRow = ExcelSpecific.GetRow(EnumRowPosition.Part, Me.ExcelValues)
                Dim MaxMarksRow As ExcelRow = ExcelSpecific.GetRow(EnumRowPosition.MaxMarks, Me.ExcelValues)
                Dim CognitivelevelRow As ExcelRow = ExcelSpecific.GetRow(EnumRowPosition.Cognitivelevel, Me.ExcelValues)


                Dim RollNumberColumn As New Data.DataColumn(Me.MasterDataStructure.RollNumber)
                Dim NameColumn As New Data.DataColumn(Me.MasterDataStructure.Name)


                Me.MasterDataStructure.ColumnNameIndexs.Clear()

                Dim MyColumnNameIndex As New ColumnNameIndex
                With MyColumnNameIndex
                    .ColumnIndex = 0
                    .ColumnName = Me.MasterDataStructure.RollNumber
                End With
                Me.MasterDataStructure.ColumnNameIndexs.Add(MyColumnNameIndex)



                MyColumnNameIndex = New ColumnNameIndex
                With MyColumnNameIndex
                    .ColumnIndex = 1
                    .ColumnName = Me.MasterDataStructure.Name
                End With
                Me.MasterDataStructure.ColumnNameIndexs.Add(MyColumnNameIndex)



                MarkMaster.Columns.Add(RollNumberColumn)
                MarkMaster.Columns.Add(NameColumn)


                For Each Question In QuestionRow.ExcelColumns
                    If Question.Column < ColumnConfiguration.Mark Then Continue For
                    Dim PartColumn = PartRow.ExcelColumns(Question.Column)
                    MyColumnNameIndex = New ColumnNameIndex
                    Dim MyColumn As New Data.DataColumn
                    With MyColumnNameIndex

                        .ColumnIndex = Question.Column
                        If Question.Column = ColumnConfiguration.Total Then
                            .ColumnName = MasterDataStructure.Total
                            MyColumn = New DataColumn(MasterDataStructure.Total, GetType(Integer))

                        ElseIf Question.Column = ColumnConfiguration.Assignment Then
                            .ColumnName = MasterDataStructure.Assignment
                            MyColumn = New DataColumn(MasterDataStructure.Assignment, GetType(Integer))
                        Else
                            .ColumnName = "Col" & Question.Column ''''PartColumn.Value & "_" & Question.Value
                            MyColumn = New Data.DataColumn(MyColumnNameIndex.ColumnName)
                        End If
                    End With
                    MyColumn.AllowDBNull = True
                    Me.MasterDataStructure.ColumnNameIndexs.Add(MyColumnNameIndex)
                    MarkMaster.Columns.Add(MyColumn)
                Next



                Dim MyMaxMarkRow As Data.DataRow = MarkMaster.NewRow

                For Each MaxMarks In MaxMarksRow.ExcelColumns
                    ''If MaxMarks.Column < ColumnConfiguration.Mark Then Continue For
                    '' MyMaxMarkRow(MaxMarks.Column - ColumnConfiguration.Mark) = MaxMarks.Value
                    MyMaxMarkRow(Me.MasterDataStructure.ColumnName(MaxMarks.Column)) = IIf(IsNothing(MaxMarks.Value), DBNull.Value, MaxMarks.Value)
                Next

                MarkMaster.Rows.Add(MyMaxMarkRow)


                For MyStudentIndex As Integer = RowConfiguration.StudentStarts To Me.ExcelValues.Count - 1

                    Dim MyStudentMark = Me.ExcelValues(MyStudentIndex)
                    If Val(MyStudentMark.ExcelColumns(0).Value) <= 0 Then Continue For

                    Dim MyStudentMarkRow As Data.DataRow = MarkMaster.NewRow


                    For Each Marks In MyStudentMark.ExcelColumns
                        ''If MaxMarks.Column < ColumnConfiguration.Mark Then Continue For
                        '' MyMaxMarkRow(MaxMarks.Column - ColumnConfiguration.Mark) = MaxMarks.Value
                        MyStudentMarkRow(Me.MasterDataStructure.ColumnName(Marks.Column)) = IIf(IsNothing(Marks.Value), DBNull.Value, Marks.Value)
                    Next
                    MarkMaster.Rows.Add(MyStudentMarkRow)
                Next

                Dim Total100Column As New Data.DataColumn(Me.MasterDataStructure.Total100, GetType(Double))
                Total100Column.Expression = "[" & MasterDataStructure.Total & "]*2"

                MarkMaster.Columns.Add(Total100Column)


                Dim AvgColumn As New Data.DataColumn(Me.MasterDataStructure.Avg, GetType(String))
                AvgColumn.Expression = "IIF(ISNULL([" & MasterDataStructure.Total100 & "],0) =0,'0', IIF([" & MasterDataStructure.Total100 & "] <40, '< 40', IIF([" & MasterDataStructure.Total100 & "] <= 60,'40 - 60', IIF([" & MasterDataStructure.Total100 & "] <= 80, '61-80','>81'))))"
                MarkMaster.Columns.Add(AvgColumn)

            Catch ex As Exception
                Throw
            End Try

        End Function

        Private Sub releaseObject(ByVal obj As Object)
            Try
                System.Runtime.InteropServices.Marshal.ReleaseComObject(obj)
                obj = Nothing
            Catch ex As Exception
                obj = Nothing
            Finally
                GC.Collect()
            End Try
        End Sub

    End Class
End Namespace