﻿Public Class QuestionBase
    Public Event RemoveMe(sender As Object)
    Public Event AddMore(sender As Object)
    Friend Logic As QuestionStructure.QuestionPatternModel
    Friend ControlRow As RowStyle
    Public Function GetData()
        Try
            With Logic
                .Part = Me.Cbo_Part.Text
                .Mark = Val(Txt_Marks.Text)
            End With

            Return True
        Catch ex As Exception
            Throw
        End Try
    End Function
    Public Function ReAligndata()
        Try
            Me.Txt_QNo.Text = Me.Logic.QuestionNumber
            Return True
        Catch ex As Exception
            Throw
        End Try
    End Function

    Sub Setbackcolor()
        Try

            If Logic.QuestionNumber Mod 2 = 0 Then
                Me.BackColor = Color.Silver
            Else
                Me.BackColor = Color.White
            End If

        Catch ex As Exception
            Throw
        End Try
    End Sub

    Sub New(_Logic As QuestionStructure.QuestionPatternModel, _ControlRow As RowStyle)
        InitializeComponent()
        ControlRow = _ControlRow
        Me.Logic = _Logic
        Txt_QNo.Text = Me.Logic.QuestionNumber
        Txt_QNo.ReadOnly = True




        With Me.CLB_CL
            .DataSource = Me.Logic.Cognizantlevels.Data
            .DisplayMember = TableStructure.Cognizantlevels.Columns.Value
            .ValueMember = TableStructure.Cognizantlevels.Columns.Code
        End With

        With Me.Cbo_Part
            .DataSource = Me.Logic.[Parts].Data
            .DisplayMember = TableStructure.Part.Columns.Value
            .ValueMember = TableStructure.Part.Columns.Code
        End With

        With Me.CLB_COs
            .DataSource = Me.Logic.CourseOutcomes.Data
            .DisplayMember = TableStructure.CourseOutcomes.Columns.Value
            .ValueMember = TableStructure.CourseOutcomes.Columns.Code
        End With
        With Me.CLB_POS
            .DataSource = Me.Logic.ProcessOutcomes.Data
            .DisplayMember = TableStructure.ProcessOutcomes.Columns.Value
            .ValueMember = TableStructure.ProcessOutcomes.Columns.Code
        End With

        With Me.CLB_PSO
            .DataSource = Me.Logic.PSOS.Data
            .DisplayMember = TableStructure.PSOS.Columns.Value
            .ValueMember = TableStructure.PSOS.Columns.Code
        End With


        Setbackcolor()

        Me.DoubleBuffered = True



    End Sub
    Private Sub Btn_Remove_Click(sender As Object, e As EventArgs) Handles Btn_Remove.Click
        Try
            RaiseEvent RemoveMe(Me)
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub
    Private Sub Btn_AddMore_Click(sender As Object, e As EventArgs) Handles Btn_AddMore.Click
        Try
            If Val(Txt_Marks.Text) <= 0 Then
                Txt_Marks.Focus()
                Throw New Exception("Enter the Mark")
            End If
            RaiseEvent AddMore(Me)
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub

    Private Sub QuestionBase_Enter(sender As Object, e As EventArgs) Handles Me.Enter
        Try
            Me.BackColor = Color.Wheat
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub

    Private Sub QuestionBase_GotFocus(sender As Object, e As EventArgs) Handles Me.GotFocus
       
    End Sub

    Private Sub QuestionBase_Leave(sender As Object, e As EventArgs) Handles Me.Leave
        Try
            Setbackcolor()
            GetData()

        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub

    Private Sub QuestionBase_LostFocus(sender As Object, e As EventArgs) Handles Me.LostFocus
    
    End Sub

    Private Sub Txt_Marks_KeyDown(sender As Object, e As KeyEventArgs) Handles Txt_Marks.KeyDown
      
    End Sub

    Private Sub Txt_Marks_KeyPress(sender As Object, e As KeyPressEventArgs) Handles Txt_Marks.KeyPress
        Try

            If AscW(e.KeyChar) = Keys.Back Or AscW(e.KeyChar) = Keys.Delete Then
                Return
            End If
            If IsNumeric(e.KeyChar) = False Then
                e.Handled = True
            End If

        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub

    Private Sub Cb_CL_CheckedChanged(sender As Object, e As EventArgs) Handles Cb_CL.Click
        Try
            Me.CLB_CL.Enabled = Cb_CL.Checked
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub
    Private Sub Cb_COs_CheckedChanged(sender As Object, e As EventArgs) Handles Cb_COs.Click
        Try
            Me.CLB_COs.Enabled = Cb_CL.Checked
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub
    Private Sub Cb_POs_CheckedChanged(sender As Object, e As EventArgs) Handles Cb_POs.Click
        Try
            Me.CLB_POS.Enabled = Cb_POs.Checked
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub
    Private Sub CB_PSO_CheckedChanged(sender As Object, e As EventArgs) Handles CB_PSO.Click
        Try
            Me.CLB_PSO.Enabled = CB_PSO.Checked
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub
    Private Sub Txt_Marks_TextChanged(sender As Object, e As EventArgs) Handles Txt_Marks.TextChanged

    End Sub
    Private Sub Txt_Marks_Validating(sender As Object, e As System.ComponentModel.CancelEventArgs) Handles Txt_Marks.Validating
        Try
            Me.Logic.Mark = Val(Txt_Marks.Text)
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub


End Class
