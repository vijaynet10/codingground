﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class QuestionBase
    Inherits System.Windows.Forms.UserControl

    'UserControl overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.TableLayoutPanel1 = New System.Windows.Forms.TableLayoutPanel()
        Me.Btn_Remove = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Cb_CL = New System.Windows.Forms.CheckBox()
        Me.Cb_COs = New System.Windows.Forms.CheckBox()
        Me.Cb_POs = New System.Windows.Forms.CheckBox()
        Me.CB_PSO = New System.Windows.Forms.CheckBox()
        Me.CLB_CL = New System.Windows.Forms.CheckedListBox()
        Me.CLB_COs = New System.Windows.Forms.CheckedListBox()
        Me.Txt_QNo = New System.Windows.Forms.TextBox()
        Me.Txt_Marks = New System.Windows.Forms.TextBox()
        Me.Cbo_Part = New System.Windows.Forms.ComboBox()
        Me.CLB_POS = New System.Windows.Forms.CheckedListBox()
        Me.CLB_PSO = New System.Windows.Forms.CheckedListBox()
        Me.Btn_AddMore = New System.Windows.Forms.Button()
        Me.Panel_Q = New System.Windows.Forms.Panel()
        Me.TableLayoutPanel1.SuspendLayout()
        Me.Panel_Q.SuspendLayout()
        Me.SuspendLayout()
        '
        'TableLayoutPanel1
        '
        Me.TableLayoutPanel1.ColumnCount = 9
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 5.806145!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 5.225531!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 7.45122!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 7.935065!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 15.47511!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.57014!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 26.33484!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 11.49321!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 5.701357!))
        Me.TableLayoutPanel1.Controls.Add(Me.Btn_Remove, 0, 1)
        Me.TableLayoutPanel1.Controls.Add(Me.Label1, 1, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.Label2, 2, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.Label3, 3, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.Cb_CL, 4, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.Cb_COs, 5, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.Cb_POs, 6, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.CB_PSO, 7, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.CLB_CL, 4, 1)
        Me.TableLayoutPanel1.Controls.Add(Me.CLB_COs, 5, 1)
        Me.TableLayoutPanel1.Controls.Add(Me.Txt_QNo, 1, 1)
        Me.TableLayoutPanel1.Controls.Add(Me.Txt_Marks, 3, 1)
        Me.TableLayoutPanel1.Controls.Add(Me.Cbo_Part, 2, 1)
        Me.TableLayoutPanel1.Controls.Add(Me.CLB_POS, 6, 1)
        Me.TableLayoutPanel1.Controls.Add(Me.CLB_PSO, 7, 1)
        Me.TableLayoutPanel1.Controls.Add(Me.Btn_AddMore, 8, 1)
        Me.TableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel1.Location = New System.Drawing.Point(0, 0)
        Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
        Me.TableLayoutPanel1.RowCount = 2
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 36.64122!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 63.35878!))
        Me.TableLayoutPanel1.Size = New System.Drawing.Size(1105, 96)
        Me.TableLayoutPanel1.TabIndex = 0
        '
        'Btn_Remove
        '
        Me.Btn_Remove.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Btn_Remove.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Btn_Remove.Font = New System.Drawing.Font("Verdana", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_Remove.Location = New System.Drawing.Point(7, 49)
        Me.Btn_Remove.Name = "Btn_Remove"
        Me.Btn_Remove.Size = New System.Drawing.Size(49, 32)
        Me.Btn_Remove.TabIndex = 0
        Me.Btn_Remove.Text = "-"
        Me.Btn_Remove.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(67, 10)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(51, 15)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "Q.No"
        '
        'Label2
        '
        Me.Label2.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(124, 10)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(76, 15)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Part"
        '
        'Label3
        '
        Me.Label3.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(206, 10)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(81, 15)
        Me.Label3.TabIndex = 1
        Me.Label3.Text = "Marks"
        '
        'Cb_CL
        '
        Me.Cb_CL.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Cb_CL.Appearance = System.Windows.Forms.Appearance.Button
        Me.Cb_CL.AutoEllipsis = True
        Me.Cb_CL.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Cb_CL.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Cb_CL.FlatAppearance.BorderSize = 2
        Me.Cb_CL.FlatAppearance.CheckedBackColor = System.Drawing.Color.Lime
        Me.Cb_CL.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Cb_CL.Location = New System.Drawing.Point(348, 5)
        Me.Cb_CL.Name = "Cb_CL"
        Me.Cb_CL.Size = New System.Drawing.Size(55, 25)
        Me.Cb_CL.TabIndex = 3
        Me.Cb_CL.Text = "CL"
        Me.Cb_CL.UseVisualStyleBackColor = False
        '
        'Cb_COs
        '
        Me.Cb_COs.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Cb_COs.Appearance = System.Windows.Forms.Appearance.Button
        Me.Cb_COs.AutoEllipsis = True
        Me.Cb_COs.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Cb_COs.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Cb_COs.FlatAppearance.BorderSize = 2
        Me.Cb_COs.FlatAppearance.CheckedBackColor = System.Drawing.Color.Lime
        Me.Cb_COs.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Cb_COs.Location = New System.Drawing.Point(507, 5)
        Me.Cb_COs.Name = "Cb_COs"
        Me.Cb_COs.Size = New System.Drawing.Size(68, 25)
        Me.Cb_COs.TabIndex = 5
        Me.Cb_COs.Text = "CO's"
        Me.Cb_COs.UseVisualStyleBackColor = False
        '
        'Cb_POs
        '
        Me.Cb_POs.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Cb_POs.Appearance = System.Windows.Forms.Appearance.Button
        Me.Cb_POs.AutoEllipsis = True
        Me.Cb_POs.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Cb_POs.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Cb_POs.FlatAppearance.BorderSize = 2
        Me.Cb_POs.FlatAppearance.CheckedBackColor = System.Drawing.Color.Lime
        Me.Cb_POs.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Cb_POs.Location = New System.Drawing.Point(733, 5)
        Me.Cb_POs.Name = "Cb_POs"
        Me.Cb_POs.Size = New System.Drawing.Size(68, 25)
        Me.Cb_POs.TabIndex = 7
        Me.Cb_POs.Text = "PO's"
        Me.Cb_POs.UseVisualStyleBackColor = False
        '
        'CB_PSO
        '
        Me.CB_PSO.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.CB_PSO.Appearance = System.Windows.Forms.Appearance.Button
        Me.CB_PSO.AutoEllipsis = True
        Me.CB_PSO.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.CB_PSO.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.CB_PSO.FlatAppearance.BorderSize = 2
        Me.CB_PSO.FlatAppearance.CheckedBackColor = System.Drawing.Color.Lime
        Me.CB_PSO.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.CB_PSO.Location = New System.Drawing.Point(944, 5)
        Me.CB_PSO.Name = "CB_PSO"
        Me.CB_PSO.Size = New System.Drawing.Size(65, 25)
        Me.CB_PSO.TabIndex = 9
        Me.CB_PSO.Text = "PSO"
        Me.CB_PSO.UseVisualStyleBackColor = False
        '
        'CLB_CL
        '
        Me.CLB_CL.ColumnWidth = 40
        Me.CLB_CL.Dock = System.Windows.Forms.DockStyle.Fill
        Me.CLB_CL.Enabled = False
        Me.CLB_CL.FormattingEnabled = True
        Me.CLB_CL.Location = New System.Drawing.Point(293, 38)
        Me.CLB_CL.MultiColumn = True
        Me.CLB_CL.Name = "CLB_CL"
        Me.CLB_CL.Size = New System.Drawing.Size(165, 55)
        Me.CLB_CL.TabIndex = 4
        '
        'CLB_COs
        '
        Me.CLB_COs.ColumnWidth = 40
        Me.CLB_COs.Dock = System.Windows.Forms.DockStyle.Fill
        Me.CLB_COs.Enabled = False
        Me.CLB_COs.FormattingEnabled = True
        Me.CLB_COs.Location = New System.Drawing.Point(464, 38)
        Me.CLB_COs.MultiColumn = True
        Me.CLB_COs.Name = "CLB_COs"
        Me.CLB_COs.Size = New System.Drawing.Size(155, 55)
        Me.CLB_COs.TabIndex = 6
        '
        'Txt_QNo
        '
        Me.Txt_QNo.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.Txt_QNo.Location = New System.Drawing.Point(67, 38)
        Me.Txt_QNo.Name = "Txt_QNo"
        Me.Txt_QNo.Size = New System.Drawing.Size(51, 23)
        Me.Txt_QNo.TabIndex = 0
        '
        'Txt_Marks
        '
        Me.Txt_Marks.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.Txt_Marks.Location = New System.Drawing.Point(206, 38)
        Me.Txt_Marks.Name = "Txt_Marks"
        Me.Txt_Marks.Size = New System.Drawing.Size(81, 23)
        Me.Txt_Marks.TabIndex = 2
        '
        'Cbo_Part
        '
        Me.Cbo_Part.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.Cbo_Part.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.Cbo_Part.FormattingEnabled = True
        Me.Cbo_Part.Location = New System.Drawing.Point(124, 38)
        Me.Cbo_Part.Name = "Cbo_Part"
        Me.Cbo_Part.Size = New System.Drawing.Size(76, 23)
        Me.Cbo_Part.TabIndex = 1
        '
        'CLB_POS
        '
        Me.CLB_POS.ColumnWidth = 40
        Me.CLB_POS.Dock = System.Windows.Forms.DockStyle.Fill
        Me.CLB_POS.Enabled = False
        Me.CLB_POS.FormattingEnabled = True
        Me.CLB_POS.Location = New System.Drawing.Point(625, 38)
        Me.CLB_POS.MultiColumn = True
        Me.CLB_POS.Name = "CLB_POS"
        Me.CLB_POS.Size = New System.Drawing.Size(285, 55)
        Me.CLB_POS.TabIndex = 8
        '
        'CLB_PSO
        '
        Me.CLB_PSO.ColumnWidth = 40
        Me.CLB_PSO.Dock = System.Windows.Forms.DockStyle.Fill
        Me.CLB_PSO.Enabled = False
        Me.CLB_PSO.FormattingEnabled = True
        Me.CLB_PSO.Location = New System.Drawing.Point(916, 38)
        Me.CLB_PSO.MultiColumn = True
        Me.CLB_PSO.Name = "CLB_PSO"
        Me.CLB_PSO.Size = New System.Drawing.Size(121, 55)
        Me.CLB_PSO.TabIndex = 10
        '
        'Btn_AddMore
        '
        Me.Btn_AddMore.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Btn_AddMore.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Btn_AddMore.Font = New System.Drawing.Font("Verdana", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_AddMore.Location = New System.Drawing.Point(1048, 49)
        Me.Btn_AddMore.Name = "Btn_AddMore"
        Me.Btn_AddMore.Size = New System.Drawing.Size(49, 32)
        Me.Btn_AddMore.TabIndex = 11
        Me.Btn_AddMore.Text = "+"
        Me.Btn_AddMore.UseVisualStyleBackColor = True
        '
        'Panel_Q
        '
        Me.Panel_Q.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel_Q.Controls.Add(Me.TableLayoutPanel1)
        Me.Panel_Q.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel_Q.Location = New System.Drawing.Point(0, 0)
        Me.Panel_Q.Name = "Panel_Q"
        Me.Panel_Q.Size = New System.Drawing.Size(1107, 98)
        Me.Panel_Q.TabIndex = 0
        '
        'QuestionBase
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.Controls.Add(Me.Panel_Q)
        Me.Font = New System.Drawing.Font("Calibri", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Name = "QuestionBase"
        Me.Size = New System.Drawing.Size(1107, 98)
        Me.TableLayoutPanel1.ResumeLayout(False)
        Me.TableLayoutPanel1.PerformLayout()
        Me.Panel_Q.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents TableLayoutPanel1 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents Btn_Remove As System.Windows.Forms.Button
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Cb_CL As System.Windows.Forms.CheckBox
    Friend WithEvents Cb_COs As System.Windows.Forms.CheckBox
    Friend WithEvents Cb_POs As System.Windows.Forms.CheckBox
    Friend WithEvents CB_PSO As System.Windows.Forms.CheckBox
    Friend WithEvents CLB_CL As System.Windows.Forms.CheckedListBox
    Friend WithEvents CLB_COs As System.Windows.Forms.CheckedListBox
    Friend WithEvents Panel_Q As System.Windows.Forms.Panel
    Friend WithEvents Txt_QNo As System.Windows.Forms.TextBox
    Friend WithEvents Txt_Marks As System.Windows.Forms.TextBox
    Friend WithEvents Cbo_Part As System.Windows.Forms.ComboBox
    Friend WithEvents CLB_POS As System.Windows.Forms.CheckedListBox
    Friend WithEvents CLB_PSO As System.Windows.Forms.CheckedListBox
    Friend WithEvents Btn_AddMore As System.Windows.Forms.Button

End Class
