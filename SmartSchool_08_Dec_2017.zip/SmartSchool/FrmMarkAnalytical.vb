﻿Public Class FrmMarkAnalytical
    Dim Logic As New Logic.Excel
    Private Sub Btn_Process_Click(sender As Object, e As EventArgs) Handles Btn_Process.Click
        Try
            Me.Cursor = Cursors.WaitCursor
            Dim MyOpenFileDialog As New OpenFileDialog
            ReportView_SM.LocalReport.DataSources.Clear()
            ReportView_SM.RefreshReport()


            MyOpenFileDialog.Title = "xlsx Files Only"
            MyOpenFileDialog.Multiselect = False
            MyOpenFileDialog.Filter = "Excel Files|*.xlsx;*.xls"
            Dim DiaResult As DialogResult = MyOpenFileDialog.ShowDialog()
            If DiaResult <> System.Windows.Forms.DialogResult.OK Then Return
            Logic.DoWork(MyOpenFileDialog.FileName)
            With ReportView_SM.LocalReport
                .DataSources.Clear()
                .DataSources.Add(New Microsoft.Reporting.WinForms.ReportDataSource("Student", Me.Logic.CopiedMarkMaster))
                .ReportPath = IO.Path.Combine(Application.StartupPath, "Report_MarkAnalytical.rdlc")
                .ReportEmbeddedResource = "MarkAnalytical"
                .Refresh()
            End With
            ReportView_SM.RefreshReport()
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        Finally
            Me.Cursor = Cursors.Default
        End Try
    End Sub
    Private Sub Btn_ExporttoPDF_Click(sender As Object, e As EventArgs) Handles Btn_ExporttoPDF.Click
        Try

            Me.Cursor = Cursors.WaitCursor

            Dim pdfContent As Byte() = ReportView_SM.LocalReport.Render("PDF", Nothing, Nothing, Nothing, Nothing, Nothing, Nothing)
            Dim MySaveFileDialog As New SaveFileDialog
            MySaveFileDialog.Filter = "PDF File|*.PDF"
            Dim DiaResult As DialogResult = MySaveFileDialog.ShowDialog()
            If DiaResult <> System.Windows.Forms.DialogResult.OK Then Return
            Dim pdfFile As New System.IO.FileStream(MySaveFileDialog.FileName, System.IO.FileMode.Create)
            pdfFile.Write(pdfContent, 0, pdfContent.Length)
            pdfFile.Close()
            MessageBox.Show("PDF File Exported...")
            Me.Btn_Process.Focus()

        Catch ex As Exception
            MessageBox.Show(ex.Message)
        Finally
            Me.Cursor = Cursors.Default
        End Try
    End Sub
End Class
