﻿Imports SmartSchool.QuestionStructure

Namespace Model
    Public Class QuestionStructure
        Private _Questions As New List(Of QuestionPatternModel)
        Public Property Questions As List(Of QuestionPatternModel)
            Get
                Return _Questions
            End Get
            Set(value As List(Of QuestionPatternModel))
                _Questions = value
            End Set
        End Property
        Public Function AddNewQuestion() As QuestionPatternModel
            Try

                Dim MyQuestionPatternModel As New QuestionPatternModel(Questions.Count + 1)
                Me.Questions.Add(MyQuestionPatternModel)
                Return MyQuestionPatternModel
            Catch ex As Exception
                Throw
            End Try
        End Function
        Public Function RemoveQuestion(_QuestionPatternModel As QuestionPatternModel) As Int32
            Try
                If Me.Questions.Count <= 1 Then Throw New Exception("Default one question required")
                Me.Questions.Remove(_QuestionPatternModel)
                Return 0
            Catch ex As Exception
                Throw
            End Try
        End Function




    End Class
End Namespace