﻿Namespace TableStructure
    Public Class Part
        Public Class Columns
            Public Shared ReadOnly Code As String = "Code"
            Public Shared ReadOnly Value As String = "Value"
        End Class
    End Class
    Public Class Cognizantlevels
        Public Class Columns
            Public Shared ReadOnly Code As String = "Code"
            Public Shared ReadOnly Value As String = "Value"
        End Class
    End Class
    Public Class CourseOutcomes
        Public Class Columns
            Public Shared ReadOnly Code As String = "Code"
            Public Shared ReadOnly Value As String = "Value"
        End Class
    End Class
    Public Class ProcessOutcomes
        Public Class Columns
            Public Shared ReadOnly Code As String = "Code"
            Public Shared ReadOnly Value As String = "Value"
        End Class
    End Class
    Public Class PSOS
        Public Class Columns
            Public Shared ReadOnly Code As String = "Code"
            Public Shared ReadOnly Value As String = "Value"
        End Class
    End Class
End Namespace
