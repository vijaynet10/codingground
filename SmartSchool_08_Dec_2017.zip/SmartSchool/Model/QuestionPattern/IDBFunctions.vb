﻿Public Interface IDBFunctions
    Property Data As DataTable
    Function GetData() As Boolean
End Interface
