﻿Namespace QuestionStructure
    Public Class QuestionPatternModel
        Public Property Mark As Integer = 0
        Public Property Part As String = String.Empty
        Private _QuestionNumber As Integer
        Public Property QuestionNumber As Integer
            Get
                Return _QuestionNumber
            End Get
            Private Set(value As Integer)
                _QuestionNumber = value
            End Set
        End Property
        Sub New(_QuestionNumber As Integer)
            Me.QuestionNumber = _QuestionNumber
            Cognizantlevels.GetData()
            CourseOutcomes.GetData()
            ProcessOutcomes.GetData()
            PSOS.GetData()
            Parts.GetData()

        End Sub
        Friend Property Cognizantlevels As New Master.Cognizantlevels
        Friend Property CourseOutcomes As New Master.CourseOutcomes
        Friend Property ProcessOutcomes As New Master.ProcessOutcomes
        Friend Property PSOS As New Master.PSOS
        Friend [Parts] As New Master.Part


    End Class
End Namespace
