﻿Namespace Logic
    Public Class ExcelRow
        Friend Property Row As Integer
        Friend Property ExcelColumns As New List(Of ExcelColumn)
    End Class
    Public Class ExcelColumn
        Friend Property Column As Integer
        Friend Property Value As Object
    End Class
    Public Class ExcelSpecific
        Public Shared Function GetRow(_RowPosition As EnumRowPosition, ExcelRows As List(Of ExcelRow)) As ExcelRow
            Try

                If _RowPosition = EnumRowPosition.Part Then
                    Return ExcelRows(RowConfiguration.Part)
                ElseIf _RowPosition = EnumRowPosition.QuestionNo Then
                    Return ExcelRows(RowConfiguration.QuestionNo)
                ElseIf _RowPosition = EnumRowPosition.MaxMarks Then
                    Return ExcelRows(RowConfiguration.MaxMarks)
                ElseIf _RowPosition = EnumRowPosition.Cognitivelevel Then
                    Return ExcelRows(RowConfiguration.Cognitivelevel)
                ElseIf _RowPosition = EnumRowPosition.StudentRowStarts Then
                    Return ExcelRows(RowConfiguration.StudentStarts)
                Else
                    Return Nothing
                End If
            Catch ex As Exception
                Throw
            End Try

        End Function
    End Class
End Namespace