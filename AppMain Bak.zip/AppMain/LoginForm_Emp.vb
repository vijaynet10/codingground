﻿Public Class LoginForm_Emp
    Private Sub OK_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OK.Click
        Try

            If UsernameTextBox.Text.ToUpper <> "Employee".ToUpper OrElse PasswordTextBox.Text.ToUpper <> "Employee".ToUpper Then
                Throw New Exception("User name  or  password is invalid ")
            End If
            Application_Main.ApplicationSett.CheckExpire()

            Me.DialogResult = Windows.Forms.DialogResult.OK
            Me.Close()


        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try

    End Sub

    Private Sub Cancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cancel.Click
        Try
            Me.DialogResult = Windows.Forms.DialogResult.Cancel
            Me.Close()
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub

    Public Sub New()

        ' This call is required by the designer.
        InitializeComponent()

        With Me
            .ShowInTaskbar = False
            .ShowIcon = False
            .WindowState = FormWindowState.Normal
            .ControlBox = False
            .StartPosition = FormStartPosition.CenterScreen
        End With

    End Sub

    Private Sub LoginForm_Admin_Shown(sender As Object, e As EventArgs) Handles Me.Shown
        Try
            UsernameTextBox.Clear()
            PasswordTextBox.Clear()
            UsernameTextBox.Focus()
        Catch ex As Exception

        End Try

    End Sub
End Class
