﻿Public Class FrmUserTypeSelection

    Sub New()
        InitializeComponent()
        Me.WindowState = FormWindowState.Maximized
    End Sub
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Admin.Click
        Try

            Dim DiaResult As DialogResult = Application_Main.LoginForm_Admin.ShowDialog()
            If DiaResult = Windows.Forms.DialogResult.OK Then
                Application_Main.FrmApplicationSettings.ShowDialog()
            End If



        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub

    Private Sub Employee_Click(sender As Object, e As EventArgs) Handles Employee.Click
        Try

            Dim DiaResult As DialogResult = Application_Main.LoginForm_Emp.ShowDialog()
            If DiaResult = Windows.Forms.DialogResult.OK Then
                Application_Main.FrmMainEntry.Show()
                Me.Close()
            End If



        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub

    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles Label1.Click, PictureBox1.Click
        Try

            Process.Start("http://cinavia.in/")

        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub
End Class