﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FrmMainEntry
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.TabControl_Main = New System.Windows.Forms.TabControl()
        Me.Tab_Entry = New System.Windows.Forms.TabPage()
        Me.TLP_Left = New System.Windows.Forms.TableLayoutPanel()
        Me.TLP_ReservationDet = New System.Windows.Forms.TableLayoutPanel()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.DTP_ResDate = New System.Windows.Forms.DateTimePicker()
        Me.Txt_ResNo = New System.Windows.Forms.TextBox()
        Me.btn_NewForm = New System.Windows.Forms.Button()
        Me.TLP_LeftData = New System.Windows.Forms.TableLayoutPanel()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.TLP_FamilyMembers = New System.Windows.Forms.TableLayoutPanel()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.TLP_FamilyEntry = New System.Windows.Forms.TableLayoutPanel()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Txt_FamilyName = New System.Windows.Forms.TextBox()
        Me.txt_FamilyAge = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Dtp_FamilyDOB = New System.Windows.Forms.DateTimePicker()
        Me.Cbo_RelationShip = New System.Windows.Forms.ComboBox()
        Me.Txt_AhaarNo = New System.Windows.Forms.TextBox()
        Me.Btn_AddFamilyMember = New System.Windows.Forms.Button()
        Me.DGV_FamilymembersData = New System.Windows.Forms.DataGridView()
        Me.TLP_Food = New System.Windows.Forms.TableLayoutPanel()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Txt_NewFoodNo = New System.Windows.Forms.TextBox()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Txt_OldFoodNo = New System.Windows.Forms.TextBox()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Dtp_NewFoodDate = New System.Windows.Forms.DateTimePicker()
        Me.Dtp_OldFoodDate = New System.Windows.Forms.DateTimePicker()
        Me.TLP_VoterID = New System.Windows.Forms.TableLayoutPanel()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Txt_NewVoterIdNo = New System.Windows.Forms.TextBox()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.Dtp_NewVoterIDDate = New System.Windows.Forms.DateTimePicker()
        Me.Dtp_OldVoterIDDate = New System.Windows.Forms.DateTimePicker()
        Me.Txt_OldVoterIdNo = New System.Windows.Forms.TextBox()
        Me.Txt_NewVoterCont = New System.Windows.Forms.TextBox()
        Me.Txt_OldVoterCont = New System.Windows.Forms.TextBox()
        Me.TLP_Head = New System.Windows.Forms.TableLayoutPanel()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.TLP_RightData = New System.Windows.Forms.TableLayoutPanel()
        Me.TLP_FamilyPhoto = New System.Windows.Forms.TableLayoutPanel()
        Me.Btn_FamilyImage = New System.Windows.Forms.Button()
        Me.Pic_FamilyImage = New System.Windows.Forms.PictureBox()
        Me.TableLayoutPanel1 = New System.Windows.Forms.TableLayoutPanel()
        Me.TableLayoutPanel3 = New System.Windows.Forms.TableLayoutPanel()
        Me.Btn_Sign = New System.Windows.Forms.Button()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.Txt_ResAreaName = New System.Windows.Forms.TextBox()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.Txt_ResAreaNo = New System.Windows.Forms.TextBox()
        Me.Txt_ResPerName = New System.Windows.Forms.TextBox()
        Me.Txt_HusbandFatherName = New System.Windows.Forms.TextBox()
        Me.Btn_Finger = New System.Windows.Forms.Button()
        Me.PictureBox_Sign = New System.Windows.Forms.PictureBox()
        Me.PictureBox_Finger = New System.Windows.Forms.PictureBox()
        Me.TableLayoutPanel4 = New System.Windows.Forms.TableLayoutPanel()
        Me.Label27 = New System.Windows.Forms.Label()
        Me.Label28 = New System.Windows.Forms.Label()
        Me.Label29 = New System.Windows.Forms.Label()
        Me.Txt_OutAddress = New System.Windows.Forms.TextBox()
        Me.Txt_OutArea = New System.Windows.Forms.TextBox()
        Me.Txt_OutDoorNo = New System.Windows.Forms.TextBox()
        Me.Btn_Submit = New System.Windows.Forms.Button()
        Me.Label31 = New System.Windows.Forms.Label()
        Me.Txt_OutStreet = New System.Windows.Forms.TextBox()
        Me.Label30 = New System.Windows.Forms.Label()
        Me.Label32 = New System.Windows.Forms.Label()
        Me.Label33 = New System.Windows.Forms.Label()
        Me.Dtp_EntryDate = New System.Windows.Forms.DateTimePicker()
        Me.Txt_OutDistrict = New System.Windows.Forms.TextBox()
        Me.Tab_Print = New System.Windows.Forms.TabPage()
        Me.TableLayoutPanel2 = New System.Windows.Forms.TableLayoutPanel()
        Me.ReportView = New Microsoft.Reporting.WinForms.ReportViewer()
        Me.TabControl_Main.SuspendLayout()
        Me.Tab_Entry.SuspendLayout()
        Me.TLP_Left.SuspendLayout()
        Me.TLP_ReservationDet.SuspendLayout()
        Me.TLP_LeftData.SuspendLayout()
        Me.TLP_FamilyMembers.SuspendLayout()
        Me.TLP_FamilyEntry.SuspendLayout()
        CType(Me.DGV_FamilymembersData, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TLP_Food.SuspendLayout()
        Me.TLP_VoterID.SuspendLayout()
        Me.TLP_Head.SuspendLayout()
        Me.TLP_RightData.SuspendLayout()
        Me.TLP_FamilyPhoto.SuspendLayout()
        CType(Me.Pic_FamilyImage, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TableLayoutPanel1.SuspendLayout()
        Me.TableLayoutPanel3.SuspendLayout()
        CType(Me.PictureBox_Sign, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox_Finger, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TableLayoutPanel4.SuspendLayout()
        Me.Tab_Print.SuspendLayout()
        Me.TableLayoutPanel2.SuspendLayout()
        Me.SuspendLayout()
        '
        'TabControl_Main
        '
        Me.TabControl_Main.Controls.Add(Me.Tab_Entry)
        Me.TabControl_Main.Controls.Add(Me.Tab_Print)
        Me.TabControl_Main.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TabControl_Main.Location = New System.Drawing.Point(0, 0)
        Me.TabControl_Main.Name = "TabControl_Main"
        Me.TabControl_Main.SelectedIndex = 0
        Me.TabControl_Main.Size = New System.Drawing.Size(1202, 658)
        Me.TabControl_Main.TabIndex = 0
        '
        'Tab_Entry
        '
        Me.Tab_Entry.Controls.Add(Me.TLP_Left)
        Me.Tab_Entry.Location = New System.Drawing.Point(4, 24)
        Me.Tab_Entry.Name = "Tab_Entry"
        Me.Tab_Entry.Padding = New System.Windows.Forms.Padding(3)
        Me.Tab_Entry.Size = New System.Drawing.Size(1194, 630)
        Me.Tab_Entry.TabIndex = 0
        Me.Tab_Entry.Text = "Entry"
        Me.Tab_Entry.UseVisualStyleBackColor = True
        '
        'TLP_Left
        '
        Me.TLP_Left.ColumnCount = 2
        Me.TLP_Left.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TLP_Left.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 548.0!))
        Me.TLP_Left.Controls.Add(Me.TLP_ReservationDet, 1, 0)
        Me.TLP_Left.Controls.Add(Me.TLP_LeftData, 0, 1)
        Me.TLP_Left.Controls.Add(Me.TLP_Head, 0, 0)
        Me.TLP_Left.Controls.Add(Me.TLP_RightData, 1, 1)
        Me.TLP_Left.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TLP_Left.Location = New System.Drawing.Point(3, 3)
        Me.TLP_Left.Name = "TLP_Left"
        Me.TLP_Left.RowCount = 2
        Me.TLP_Left.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 13.14103!))
        Me.TLP_Left.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 86.85897!))
        Me.TLP_Left.Size = New System.Drawing.Size(1188, 624)
        Me.TLP_Left.TabIndex = 0
        '
        'TLP_ReservationDet
        '
        Me.TLP_ReservationDet.ColumnCount = 4
        Me.TLP_ReservationDet.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 29.21348!))
        Me.TLP_ReservationDet.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25.09363!))
        Me.TLP_ReservationDet.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 28.27715!))
        Me.TLP_ReservationDet.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 17.41573!))
        Me.TLP_ReservationDet.Controls.Add(Me.Label21, 0, 1)
        Me.TLP_ReservationDet.Controls.Add(Me.Label22, 2, 1)
        Me.TLP_ReservationDet.Controls.Add(Me.DTP_ResDate, 1, 1)
        Me.TLP_ReservationDet.Controls.Add(Me.Txt_ResNo, 3, 1)
        Me.TLP_ReservationDet.Controls.Add(Me.btn_NewForm, 1, 0)
        Me.TLP_ReservationDet.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TLP_ReservationDet.Location = New System.Drawing.Point(640, 0)
        Me.TLP_ReservationDet.Margin = New System.Windows.Forms.Padding(0)
        Me.TLP_ReservationDet.Name = "TLP_ReservationDet"
        Me.TLP_ReservationDet.RowCount = 2
        Me.TLP_ReservationDet.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 38.27161!))
        Me.TLP_ReservationDet.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 61.72839!))
        Me.TLP_ReservationDet.Size = New System.Drawing.Size(548, 82)
        Me.TLP_ReservationDet.TabIndex = 0
        '
        'Label21
        '
        Me.Label21.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label21.AutoSize = True
        Me.Label21.Font = New System.Drawing.Font("Calibri", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label21.Location = New System.Drawing.Point(3, 41)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(154, 30)
        Me.Label21.TabIndex = 0
        Me.Label21.Text = "ஒதுக்கீடு ஆணை மற்றும் நாள்"
        '
        'Label22
        '
        Me.Label22.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label22.AutoSize = True
        Me.Label22.Font = New System.Drawing.Font("Calibri", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label22.Location = New System.Drawing.Point(300, 49)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(148, 15)
        Me.Label22.TabIndex = 0
        Me.Label22.Text = "ஒதுக்கீடு வரிசை எண்"
        '
        'DTP_ResDate
        '
        Me.DTP_ResDate.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.DTP_ResDate.CustomFormat = "dd-MMM-yyyy"
        Me.DTP_ResDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.DTP_ResDate.Location = New System.Drawing.Point(163, 45)
        Me.DTP_ResDate.Name = "DTP_ResDate"
        Me.DTP_ResDate.Size = New System.Drawing.Size(131, 23)
        Me.DTP_ResDate.TabIndex = 2
        '
        'Txt_ResNo
        '
        Me.Txt_ResNo.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Txt_ResNo.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.Txt_ResNo.Location = New System.Drawing.Point(454, 45)
        Me.Txt_ResNo.MaxLength = 16
        Me.Txt_ResNo.Name = "Txt_ResNo"
        Me.Txt_ResNo.Size = New System.Drawing.Size(91, 23)
        Me.Txt_ResNo.TabIndex = 4
        '
        'btn_NewForm
        '
        Me.TLP_ReservationDet.SetColumnSpan(Me.btn_NewForm, 2)
        Me.btn_NewForm.Dock = System.Windows.Forms.DockStyle.Fill
        Me.btn_NewForm.Location = New System.Drawing.Point(163, 3)
        Me.btn_NewForm.Name = "btn_NewForm"
        Me.btn_NewForm.Size = New System.Drawing.Size(285, 25)
        Me.btn_NewForm.TabIndex = 5
        Me.btn_NewForm.Text = "புதிய படிவம் ( Ctrl  +N)"
        Me.btn_NewForm.UseVisualStyleBackColor = True
        '
        'TLP_LeftData
        '
        Me.TLP_LeftData.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.[Single]
        Me.TLP_LeftData.ColumnCount = 1
        Me.TLP_LeftData.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TLP_LeftData.Controls.Add(Me.Label15, 0, 2)
        Me.TLP_LeftData.Controls.Add(Me.TLP_FamilyMembers, 0, 0)
        Me.TLP_LeftData.Controls.Add(Me.TLP_Food, 0, 1)
        Me.TLP_LeftData.Controls.Add(Me.TLP_VoterID, 0, 3)
        Me.TLP_LeftData.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TLP_LeftData.Location = New System.Drawing.Point(3, 85)
        Me.TLP_LeftData.Name = "TLP_LeftData"
        Me.TLP_LeftData.RowCount = 4
        Me.TLP_LeftData.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 56.85185!))
        Me.TLP_LeftData.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 17.59259!))
        Me.TLP_LeftData.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.851852!))
        Me.TLP_LeftData.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 18.51852!))
        Me.TLP_LeftData.Size = New System.Drawing.Size(634, 536)
        Me.TLP_LeftData.TabIndex = 2
        '
        'Label15
        '
        Me.Label15.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label15.AutoSize = True
        Me.Label15.Font = New System.Drawing.Font("Calibri", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label15.Location = New System.Drawing.Point(4, 408)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(626, 15)
        Me.Label15.TabIndex = 0
        Me.Label15.Text = "(குடும்பத் தலைவரின் வாக்காளர் அட்டை விவரங்கள்)"
        Me.Label15.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TLP_FamilyMembers
        '
        Me.TLP_FamilyMembers.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.[Single]
        Me.TLP_FamilyMembers.ColumnCount = 1
        Me.TLP_FamilyMembers.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TLP_FamilyMembers.Controls.Add(Me.Label6, 0, 0)
        Me.TLP_FamilyMembers.Controls.Add(Me.TLP_FamilyEntry, 0, 1)
        Me.TLP_FamilyMembers.Controls.Add(Me.DGV_FamilymembersData, 0, 2)
        Me.TLP_FamilyMembers.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TLP_FamilyMembers.Location = New System.Drawing.Point(1, 1)
        Me.TLP_FamilyMembers.Margin = New System.Windows.Forms.Padding(0)
        Me.TLP_FamilyMembers.Name = "TLP_FamilyMembers"
        Me.TLP_FamilyMembers.RowCount = 3
        Me.TLP_FamilyMembers.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 28.90625!))
        Me.TLP_FamilyMembers.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 71.09375!))
        Me.TLP_FamilyMembers.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 184.0!))
        Me.TLP_FamilyMembers.Size = New System.Drawing.Size(632, 302)
        Me.TLP_FamilyMembers.TabIndex = 1
        '
        'Label6
        '
        Me.Label6.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Calibri", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(4, 7)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(624, 19)
        Me.Label6.TabIndex = 0
        Me.Label6.Text = "குடும்ப  அங்கத்தினர்   மற்றும் ஆதாரங்கள்"
        Me.Label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TLP_FamilyEntry
        '
        Me.TLP_FamilyEntry.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.[Single]
        Me.TLP_FamilyEntry.ColumnCount = 6
        Me.TLP_FamilyEntry.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 22.59036!))
        Me.TLP_FamilyEntry.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 7.790143!))
        Me.TLP_FamilyEntry.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 18.91892!))
        Me.TLP_FamilyEntry.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 15.26232!))
        Me.TLP_FamilyEntry.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 21.62162!))
        Me.TLP_FamilyEntry.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 13.6725!))
        Me.TLP_FamilyEntry.Controls.Add(Me.Label1, 0, 0)
        Me.TLP_FamilyEntry.Controls.Add(Me.Txt_FamilyName, 0, 1)
        Me.TLP_FamilyEntry.Controls.Add(Me.txt_FamilyAge, 1, 1)
        Me.TLP_FamilyEntry.Controls.Add(Me.Label2, 1, 0)
        Me.TLP_FamilyEntry.Controls.Add(Me.Label3, 2, 0)
        Me.TLP_FamilyEntry.Controls.Add(Me.Label4, 3, 0)
        Me.TLP_FamilyEntry.Controls.Add(Me.Label5, 4, 0)
        Me.TLP_FamilyEntry.Controls.Add(Me.Dtp_FamilyDOB, 2, 1)
        Me.TLP_FamilyEntry.Controls.Add(Me.Cbo_RelationShip, 3, 1)
        Me.TLP_FamilyEntry.Controls.Add(Me.Txt_AhaarNo, 4, 1)
        Me.TLP_FamilyEntry.Controls.Add(Me.Btn_AddFamilyMember, 5, 1)
        Me.TLP_FamilyEntry.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TLP_FamilyEntry.Location = New System.Drawing.Point(1, 34)
        Me.TLP_FamilyEntry.Margin = New System.Windows.Forms.Padding(0)
        Me.TLP_FamilyEntry.Name = "TLP_FamilyEntry"
        Me.TLP_FamilyEntry.RowCount = 2
        Me.TLP_FamilyEntry.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 45.58823!))
        Me.TLP_FamilyEntry.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 54.41177!))
        Me.TLP_FamilyEntry.Size = New System.Drawing.Size(630, 81)
        Me.TLP_FamilyEntry.TabIndex = 0
        '
        'Label1
        '
        Me.Label1.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Calibri", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(4, 11)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(134, 15)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "குடும்பத்தினர்"
        '
        'Txt_FamilyName
        '
        Me.Txt_FamilyName.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Txt_FamilyName.Location = New System.Drawing.Point(4, 47)
        Me.Txt_FamilyName.MaxLength = 50
        Me.Txt_FamilyName.Name = "Txt_FamilyName"
        Me.Txt_FamilyName.Size = New System.Drawing.Size(134, 23)
        Me.Txt_FamilyName.TabIndex = 0
        '
        'txt_FamilyAge
        '
        Me.txt_FamilyAge.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txt_FamilyAge.Location = New System.Drawing.Point(145, 47)
        Me.txt_FamilyAge.MaxLength = 3
        Me.txt_FamilyAge.Name = "txt_FamilyAge"
        Me.txt_FamilyAge.Size = New System.Drawing.Size(42, 23)
        Me.txt_FamilyAge.TabIndex = 1
        '
        'Label2
        '
        Me.Label2.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Calibri", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(145, 3)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(42, 30)
        Me.Label2.TabIndex = 0
        Me.Label2.Text = " வயது"
        '
        'Label3
        '
        Me.Label3.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Calibri", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(194, 11)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(112, 15)
        Me.Label3.TabIndex = 0
        Me.Label3.Text = " பிறந்த தேதி"
        '
        'Label4
        '
        Me.Label4.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Calibri", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(313, 11)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(89, 15)
        Me.Label4.TabIndex = 0
        Me.Label4.Text = "உறவு"
        '
        'Label5
        '
        Me.Label5.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Calibri", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(409, 11)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(128, 15)
        Me.Label5.TabIndex = 0
        Me.Label5.Text = "ஆதார் எண்"
        '
        'Dtp_FamilyDOB
        '
        Me.Dtp_FamilyDOB.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Dtp_FamilyDOB.CustomFormat = "dd-MMM-yyyy"
        Me.Dtp_FamilyDOB.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.Dtp_FamilyDOB.Location = New System.Drawing.Point(194, 47)
        Me.Dtp_FamilyDOB.Name = "Dtp_FamilyDOB"
        Me.Dtp_FamilyDOB.Size = New System.Drawing.Size(112, 23)
        Me.Dtp_FamilyDOB.TabIndex = 2
        '
        'Cbo_RelationShip
        '
        Me.Cbo_RelationShip.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Cbo_RelationShip.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.Cbo_RelationShip.FormattingEnabled = True
        Me.Cbo_RelationShip.Location = New System.Drawing.Point(313, 48)
        Me.Cbo_RelationShip.Name = "Cbo_RelationShip"
        Me.Cbo_RelationShip.Size = New System.Drawing.Size(89, 23)
        Me.Cbo_RelationShip.TabIndex = 3
        '
        'Txt_AhaarNo
        '
        Me.Txt_AhaarNo.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Txt_AhaarNo.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.Txt_AhaarNo.Location = New System.Drawing.Point(409, 47)
        Me.Txt_AhaarNo.MaxLength = 12
        Me.Txt_AhaarNo.Name = "Txt_AhaarNo"
        Me.Txt_AhaarNo.Size = New System.Drawing.Size(128, 23)
        Me.Txt_AhaarNo.TabIndex = 4
        '
        'Btn_AddFamilyMember
        '
        Me.Btn_AddFamilyMember.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Btn_AddFamilyMember.Font = New System.Drawing.Font("Calibri", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_AddFamilyMember.Location = New System.Drawing.Point(548, 45)
        Me.Btn_AddFamilyMember.Name = "Btn_AddFamilyMember"
        Me.Btn_AddFamilyMember.Size = New System.Drawing.Size(74, 27)
        Me.Btn_AddFamilyMember.TabIndex = 5
        Me.Btn_AddFamilyMember.Text = "சேர்க்க"
        Me.Btn_AddFamilyMember.UseVisualStyleBackColor = True
        '
        'DGV_FamilymembersData
        '
        Me.DGV_FamilymembersData.AllowUserToAddRows = False
        Me.DGV_FamilymembersData.AllowUserToDeleteRows = False
        Me.DGV_FamilymembersData.BackgroundColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.DGV_FamilymembersData.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DGV_FamilymembersData.Dock = System.Windows.Forms.DockStyle.Fill
        Me.DGV_FamilymembersData.Location = New System.Drawing.Point(1, 116)
        Me.DGV_FamilymembersData.Margin = New System.Windows.Forms.Padding(0)
        Me.DGV_FamilymembersData.Name = "DGV_FamilymembersData"
        Me.DGV_FamilymembersData.ReadOnly = True
        Me.DGV_FamilymembersData.Size = New System.Drawing.Size(630, 185)
        Me.DGV_FamilymembersData.TabIndex = 1
        '
        'TLP_Food
        '
        Me.TLP_Food.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.[Single]
        Me.TLP_Food.ColumnCount = 4
        Me.TLP_Food.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 24.65544!))
        Me.TLP_Food.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 39.20367!))
        Me.TLP_Food.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 11.02603!))
        Me.TLP_Food.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25.0!))
        Me.TLP_Food.Controls.Add(Me.Label10, 0, 0)
        Me.TLP_Food.Controls.Add(Me.Txt_NewFoodNo, 1, 0)
        Me.TLP_Food.Controls.Add(Me.Label11, 0, 1)
        Me.TLP_Food.Controls.Add(Me.Txt_OldFoodNo, 1, 1)
        Me.TLP_Food.Controls.Add(Me.Label12, 2, 0)
        Me.TLP_Food.Controls.Add(Me.Label13, 2, 1)
        Me.TLP_Food.Controls.Add(Me.Dtp_NewFoodDate, 3, 0)
        Me.TLP_Food.Controls.Add(Me.Dtp_OldFoodDate, 3, 1)
        Me.TLP_Food.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TLP_Food.Location = New System.Drawing.Point(1, 304)
        Me.TLP_Food.Margin = New System.Windows.Forms.Padding(0)
        Me.TLP_Food.Name = "TLP_Food"
        Me.TLP_Food.RowCount = 2
        Me.TLP_Food.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TLP_Food.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TLP_Food.Size = New System.Drawing.Size(632, 93)
        Me.TLP_Food.TabIndex = 2
        '
        'Label10
        '
        Me.Label10.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Calibri", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.Location = New System.Drawing.Point(4, 8)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(148, 30)
        Me.Label10.TabIndex = 0
        Me.Label10.Text = "புதிய உணவு பங்கீட்டு அட்டை எண்"
        '
        'Txt_NewFoodNo
        '
        Me.Txt_NewFoodNo.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Txt_NewFoodNo.Location = New System.Drawing.Point(159, 12)
        Me.Txt_NewFoodNo.MaxLength = 50
        Me.Txt_NewFoodNo.Name = "Txt_NewFoodNo"
        Me.Txt_NewFoodNo.Size = New System.Drawing.Size(240, 23)
        Me.Txt_NewFoodNo.TabIndex = 0
        '
        'Label11
        '
        Me.Label11.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label11.AutoSize = True
        Me.Label11.Font = New System.Drawing.Font("Calibri", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.Location = New System.Drawing.Point(4, 54)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(148, 30)
        Me.Label11.TabIndex = 0
        Me.Label11.Text = "பழைய உணவு பங்கீட்டு அட்டை எண்"
        '
        'Txt_OldFoodNo
        '
        Me.Txt_OldFoodNo.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Txt_OldFoodNo.Location = New System.Drawing.Point(159, 58)
        Me.Txt_OldFoodNo.MaxLength = 50
        Me.Txt_OldFoodNo.Name = "Txt_OldFoodNo"
        Me.Txt_OldFoodNo.Size = New System.Drawing.Size(240, 23)
        Me.Txt_OldFoodNo.TabIndex = 2
        '
        'Label12
        '
        Me.Label12.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label12.AutoSize = True
        Me.Label12.Font = New System.Drawing.Font("Calibri", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.Location = New System.Drawing.Point(406, 16)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(63, 15)
        Me.Label12.TabIndex = 0
        Me.Label12.Text = "தேதி"
        '
        'Label13
        '
        Me.Label13.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label13.AutoSize = True
        Me.Label13.Font = New System.Drawing.Font("Calibri", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.Location = New System.Drawing.Point(406, 62)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(63, 15)
        Me.Label13.TabIndex = 0
        Me.Label13.Text = "தேதி"
        '
        'Dtp_NewFoodDate
        '
        Me.Dtp_NewFoodDate.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Dtp_NewFoodDate.CustomFormat = "dd-MMM-yyyy"
        Me.Dtp_NewFoodDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.Dtp_NewFoodDate.Location = New System.Drawing.Point(476, 12)
        Me.Dtp_NewFoodDate.Name = "Dtp_NewFoodDate"
        Me.Dtp_NewFoodDate.Size = New System.Drawing.Size(152, 23)
        Me.Dtp_NewFoodDate.TabIndex = 1
        '
        'Dtp_OldFoodDate
        '
        Me.Dtp_OldFoodDate.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Dtp_OldFoodDate.CustomFormat = "dd-MMM-yyyy"
        Me.Dtp_OldFoodDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.Dtp_OldFoodDate.Location = New System.Drawing.Point(476, 58)
        Me.Dtp_OldFoodDate.Name = "Dtp_OldFoodDate"
        Me.Dtp_OldFoodDate.Size = New System.Drawing.Size(152, 23)
        Me.Dtp_OldFoodDate.TabIndex = 3
        '
        'TLP_VoterID
        '
        Me.TLP_VoterID.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.[Single]
        Me.TLP_VoterID.ColumnCount = 6
        Me.TLP_VoterID.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 19.4487!))
        Me.TLP_VoterID.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 19.29556!))
        Me.TLP_VoterID.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 7.350689!))
        Me.TLP_VoterID.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 17.30475!))
        Me.TLP_VoterID.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 13.78254!))
        Me.TLP_VoterID.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 22.66463!))
        Me.TLP_VoterID.Controls.Add(Me.Label14, 0, 0)
        Me.TLP_VoterID.Controls.Add(Me.Txt_NewVoterIdNo, 1, 0)
        Me.TLP_VoterID.Controls.Add(Me.Label16, 0, 1)
        Me.TLP_VoterID.Controls.Add(Me.Label17, 2, 0)
        Me.TLP_VoterID.Controls.Add(Me.Label18, 2, 1)
        Me.TLP_VoterID.Controls.Add(Me.Label19, 4, 0)
        Me.TLP_VoterID.Controls.Add(Me.Label20, 4, 1)
        Me.TLP_VoterID.Controls.Add(Me.Dtp_NewVoterIDDate, 3, 0)
        Me.TLP_VoterID.Controls.Add(Me.Dtp_OldVoterIDDate, 3, 1)
        Me.TLP_VoterID.Controls.Add(Me.Txt_OldVoterIdNo, 1, 1)
        Me.TLP_VoterID.Controls.Add(Me.Txt_NewVoterCont, 5, 0)
        Me.TLP_VoterID.Controls.Add(Me.Txt_OldVoterCont, 5, 1)
        Me.TLP_VoterID.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TLP_VoterID.Location = New System.Drawing.Point(1, 435)
        Me.TLP_VoterID.Margin = New System.Windows.Forms.Padding(0)
        Me.TLP_VoterID.Name = "TLP_VoterID"
        Me.TLP_VoterID.RowCount = 2
        Me.TLP_VoterID.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TLP_VoterID.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TLP_VoterID.Size = New System.Drawing.Size(632, 100)
        Me.TLP_VoterID.TabIndex = 3
        '
        'Label14
        '
        Me.Label14.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label14.AutoSize = True
        Me.Label14.Font = New System.Drawing.Font("Calibri", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label14.Location = New System.Drawing.Point(4, 10)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(115, 30)
        Me.Label14.TabIndex = 0
        Me.Label14.Text = " புதிய வாக்காளர் அட்டை எண்"
        '
        'Txt_NewVoterIdNo
        '
        Me.Txt_NewVoterIdNo.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Txt_NewVoterIdNo.Location = New System.Drawing.Point(126, 13)
        Me.Txt_NewVoterIdNo.MaxLength = 50
        Me.Txt_NewVoterIdNo.Name = "Txt_NewVoterIdNo"
        Me.Txt_NewVoterIdNo.Size = New System.Drawing.Size(114, 23)
        Me.Txt_NewVoterIdNo.TabIndex = 0
        '
        'Label16
        '
        Me.Label16.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label16.AutoSize = True
        Me.Label16.Font = New System.Drawing.Font("Calibri", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label16.Location = New System.Drawing.Point(4, 52)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(115, 45)
        Me.Label16.TabIndex = 0
        Me.Label16.Text = " பழைய வாக்காளர் அட்டை எண்"
        '
        'Label17
        '
        Me.Label17.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label17.AutoSize = True
        Me.Label17.Font = New System.Drawing.Font("Calibri", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label17.Location = New System.Drawing.Point(247, 17)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(40, 15)
        Me.Label17.TabIndex = 0
        Me.Label17.Text = "தேதி"
        '
        'Label18
        '
        Me.Label18.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label18.AutoSize = True
        Me.Label18.Font = New System.Drawing.Font("Calibri", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label18.Location = New System.Drawing.Point(247, 67)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(40, 15)
        Me.Label18.TabIndex = 0
        Me.Label18.Text = "தேதி"
        '
        'Label19
        '
        Me.Label19.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label19.AutoSize = True
        Me.Label19.Font = New System.Drawing.Font("Calibri", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label19.Location = New System.Drawing.Point(403, 10)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(80, 30)
        Me.Label19.TabIndex = 0
        Me.Label19.Text = "வாக்காளர் தொகுதி"
        '
        'Label20
        '
        Me.Label20.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label20.AutoSize = True
        Me.Label20.Font = New System.Drawing.Font("Calibri", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label20.Location = New System.Drawing.Point(403, 59)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(80, 30)
        Me.Label20.TabIndex = 0
        Me.Label20.Text = "வாக்காளர் தொகுதி"
        '
        'Dtp_NewVoterIDDate
        '
        Me.Dtp_NewVoterIDDate.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Dtp_NewVoterIDDate.CustomFormat = "dd-MMM-yyyy"
        Me.Dtp_NewVoterIDDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.Dtp_NewVoterIDDate.Location = New System.Drawing.Point(294, 13)
        Me.Dtp_NewVoterIDDate.Name = "Dtp_NewVoterIDDate"
        Me.Dtp_NewVoterIDDate.Size = New System.Drawing.Size(102, 23)
        Me.Dtp_NewVoterIDDate.TabIndex = 1
        '
        'Dtp_OldVoterIDDate
        '
        Me.Dtp_OldVoterIDDate.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Dtp_OldVoterIDDate.CustomFormat = "dd-MMM-yyyy"
        Me.Dtp_OldVoterIDDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.Dtp_OldVoterIDDate.Location = New System.Drawing.Point(294, 63)
        Me.Dtp_OldVoterIDDate.Name = "Dtp_OldVoterIDDate"
        Me.Dtp_OldVoterIDDate.Size = New System.Drawing.Size(102, 23)
        Me.Dtp_OldVoterIDDate.TabIndex = 4
        '
        'Txt_OldVoterIdNo
        '
        Me.Txt_OldVoterIdNo.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Txt_OldVoterIdNo.Location = New System.Drawing.Point(126, 63)
        Me.Txt_OldVoterIdNo.MaxLength = 50
        Me.Txt_OldVoterIdNo.Name = "Txt_OldVoterIdNo"
        Me.Txt_OldVoterIdNo.Size = New System.Drawing.Size(114, 23)
        Me.Txt_OldVoterIdNo.TabIndex = 3
        '
        'Txt_NewVoterCont
        '
        Me.Txt_NewVoterCont.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Txt_NewVoterCont.Location = New System.Drawing.Point(490, 13)
        Me.Txt_NewVoterCont.MaxLength = 50
        Me.Txt_NewVoterCont.Name = "Txt_NewVoterCont"
        Me.Txt_NewVoterCont.Size = New System.Drawing.Size(138, 23)
        Me.Txt_NewVoterCont.TabIndex = 2
        '
        'Txt_OldVoterCont
        '
        Me.Txt_OldVoterCont.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Txt_OldVoterCont.Location = New System.Drawing.Point(490, 63)
        Me.Txt_OldVoterCont.MaxLength = 50
        Me.Txt_OldVoterCont.Name = "Txt_OldVoterCont"
        Me.Txt_OldVoterCont.Size = New System.Drawing.Size(138, 23)
        Me.Txt_OldVoterCont.TabIndex = 5
        '
        'TLP_Head
        '
        Me.TLP_Head.ColumnCount = 1
        Me.TLP_Head.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TLP_Head.Controls.Add(Me.Label7, 0, 0)
        Me.TLP_Head.Controls.Add(Me.Label8, 0, 1)
        Me.TLP_Head.Controls.Add(Me.Label9, 0, 2)
        Me.TLP_Head.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TLP_Head.Location = New System.Drawing.Point(3, 3)
        Me.TLP_Head.Name = "TLP_Head"
        Me.TLP_Head.RowCount = 3
        Me.TLP_Head.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333!))
        Me.TLP_Head.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333!))
        Me.TLP_Head.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333!))
        Me.TLP_Head.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        Me.TLP_Head.Size = New System.Drawing.Size(634, 76)
        Me.TLP_Head.TabIndex = 0
        '
        'Label7
        '
        Me.Label7.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Calibri", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(3, 3)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(628, 19)
        Me.Label7.TabIndex = 0
        Me.Label7.Text = "படிவம் - IV A"
        Me.Label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label8
        '
        Me.Label8.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Calibri", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(3, 28)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(628, 19)
        Me.Label8.TabIndex = 0
        Me.Label8.Text = "தமிழ் நாடு குடிசைப்பகுதி மாற்று வாரியம்"
        Me.Label8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label9
        '
        Me.Label9.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Calibri", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.Location = New System.Drawing.Point(3, 53)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(628, 19)
        Me.Label9.TabIndex = 0
        Me.Label9.Text = "ஒதுக்கீடு ஆணை மற்றும் அடையாள அட்டை"
        Me.Label9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TLP_RightData
        '
        Me.TLP_RightData.ColumnCount = 1
        Me.TLP_RightData.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TLP_RightData.Controls.Add(Me.TLP_FamilyPhoto, 0, 0)
        Me.TLP_RightData.Controls.Add(Me.TableLayoutPanel1, 0, 1)
        Me.TLP_RightData.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TLP_RightData.Location = New System.Drawing.Point(640, 82)
        Me.TLP_RightData.Margin = New System.Windows.Forms.Padding(0)
        Me.TLP_RightData.Name = "TLP_RightData"
        Me.TLP_RightData.RowCount = 2
        Me.TLP_RightData.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 36.64825!))
        Me.TLP_RightData.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 63.35175!))
        Me.TLP_RightData.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        Me.TLP_RightData.Size = New System.Drawing.Size(548, 542)
        Me.TLP_RightData.TabIndex = 1
        '
        'TLP_FamilyPhoto
        '
        Me.TLP_FamilyPhoto.ColumnCount = 1
        Me.TLP_FamilyPhoto.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TLP_FamilyPhoto.Controls.Add(Me.Btn_FamilyImage, 0, 0)
        Me.TLP_FamilyPhoto.Controls.Add(Me.Pic_FamilyImage, 0, 1)
        Me.TLP_FamilyPhoto.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TLP_FamilyPhoto.Location = New System.Drawing.Point(0, 0)
        Me.TLP_FamilyPhoto.Margin = New System.Windows.Forms.Padding(0)
        Me.TLP_FamilyPhoto.Name = "TLP_FamilyPhoto"
        Me.TLP_FamilyPhoto.RowCount = 2
        Me.TLP_FamilyPhoto.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 18.09524!))
        Me.TLP_FamilyPhoto.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 81.90476!))
        Me.TLP_FamilyPhoto.Size = New System.Drawing.Size(548, 198)
        Me.TLP_FamilyPhoto.TabIndex = 1
        '
        'Btn_FamilyImage
        '
        Me.Btn_FamilyImage.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Btn_FamilyImage.Font = New System.Drawing.Font("Calibri", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_FamilyImage.Location = New System.Drawing.Point(165, 4)
        Me.Btn_FamilyImage.Name = "Btn_FamilyImage"
        Me.Btn_FamilyImage.Size = New System.Drawing.Size(217, 27)
        Me.Btn_FamilyImage.TabIndex = 5
        Me.Btn_FamilyImage.Text = "குடும்ப புகைப்படம்"
        Me.Btn_FamilyImage.UseVisualStyleBackColor = True
        '
        'Pic_FamilyImage
        '
        Me.Pic_FamilyImage.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Pic_FamilyImage.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Pic_FamilyImage.Location = New System.Drawing.Point(3, 38)
        Me.Pic_FamilyImage.Name = "Pic_FamilyImage"
        Me.Pic_FamilyImage.Size = New System.Drawing.Size(542, 157)
        Me.Pic_FamilyImage.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.Pic_FamilyImage.TabIndex = 6
        Me.Pic_FamilyImage.TabStop = False
        '
        'TableLayoutPanel1
        '
        Me.TableLayoutPanel1.ColumnCount = 2
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 55.41045!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 44.58955!))
        Me.TableLayoutPanel1.Controls.Add(Me.TableLayoutPanel3, 0, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.TableLayoutPanel4, 1, 0)
        Me.TableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel1.Location = New System.Drawing.Point(0, 198)
        Me.TableLayoutPanel1.Margin = New System.Windows.Forms.Padding(0)
        Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
        Me.TableLayoutPanel1.RowCount = 1
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel1.Size = New System.Drawing.Size(548, 344)
        Me.TableLayoutPanel1.TabIndex = 2
        '
        'TableLayoutPanel3
        '
        Me.TableLayoutPanel3.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.[Single]
        Me.TableLayoutPanel3.ColumnCount = 2
        Me.TableLayoutPanel3.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 48.62069!))
        Me.TableLayoutPanel3.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 51.37931!))
        Me.TableLayoutPanel3.Controls.Add(Me.Btn_Sign, 0, 4)
        Me.TableLayoutPanel3.Controls.Add(Me.Label23, 0, 0)
        Me.TableLayoutPanel3.Controls.Add(Me.Label24, 0, 1)
        Me.TableLayoutPanel3.Controls.Add(Me.Label25, 0, 2)
        Me.TableLayoutPanel3.Controls.Add(Me.Txt_ResAreaName, 1, 0)
        Me.TableLayoutPanel3.Controls.Add(Me.Label26, 0, 3)
        Me.TableLayoutPanel3.Controls.Add(Me.Txt_ResAreaNo, 1, 1)
        Me.TableLayoutPanel3.Controls.Add(Me.Txt_ResPerName, 1, 2)
        Me.TableLayoutPanel3.Controls.Add(Me.Txt_HusbandFatherName, 1, 3)
        Me.TableLayoutPanel3.Controls.Add(Me.Btn_Finger, 0, 5)
        Me.TableLayoutPanel3.Controls.Add(Me.PictureBox_Sign, 1, 4)
        Me.TableLayoutPanel3.Controls.Add(Me.PictureBox_Finger, 1, 5)
        Me.TableLayoutPanel3.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel3.Location = New System.Drawing.Point(3, 3)
        Me.TableLayoutPanel3.Name = "TableLayoutPanel3"
        Me.TableLayoutPanel3.RowCount = 6
        Me.TableLayoutPanel3.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20.21277!))
        Me.TableLayoutPanel3.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 13.12057!))
        Me.TableLayoutPanel3.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10.72555!))
        Me.TableLayoutPanel3.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 17.0347!))
        Me.TableLayoutPanel3.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 13.24921!))
        Me.TableLayoutPanel3.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 26.49842!))
        Me.TableLayoutPanel3.Size = New System.Drawing.Size(297, 338)
        Me.TableLayoutPanel3.TabIndex = 0
        '
        'Btn_Sign
        '
        Me.Btn_Sign.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Btn_Sign.Font = New System.Drawing.Font("Calibri", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_Sign.Location = New System.Drawing.Point(4, 207)
        Me.Btn_Sign.Name = "Btn_Sign"
        Me.Btn_Sign.Size = New System.Drawing.Size(136, 37)
        Me.Btn_Sign.TabIndex = 4
        Me.Btn_Sign.Text = "கையொப்பம்"
        Me.Btn_Sign.UseVisualStyleBackColor = True
        '
        'Label23
        '
        Me.Label23.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label23.AutoSize = True
        Me.Label23.Font = New System.Drawing.Font("Calibri", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label23.Location = New System.Drawing.Point(4, 11)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(136, 45)
        Me.Label23.TabIndex = 0
        Me.Label23.Text = "ஒதுக்கீடு  செய்யப்படும் திட்ட பகுதியின் பெயர்"
        '
        'Label24
        '
        Me.Label24.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label24.AutoSize = True
        Me.Label24.Font = New System.Drawing.Font("Calibri", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label24.Location = New System.Drawing.Point(4, 74)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(136, 30)
        Me.Label24.TabIndex = 0
        Me.Label24.Text = "குடியிருப்பு / பகுதி எண்"
        '
        'Label25
        '
        Me.Label25.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label25.AutoSize = True
        Me.Label25.Font = New System.Drawing.Font("Calibri", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label25.Location = New System.Drawing.Point(4, 122)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(136, 15)
        Me.Label25.TabIndex = 0
        Me.Label25.Text = "ஒதுக்கீட்டாளர் பெயர்"
        '
        'Txt_ResAreaName
        '
        Me.Txt_ResAreaName.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Txt_ResAreaName.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.Txt_ResAreaName.Location = New System.Drawing.Point(147, 22)
        Me.Txt_ResAreaName.MaxLength = 16
        Me.Txt_ResAreaName.Name = "Txt_ResAreaName"
        Me.Txt_ResAreaName.Size = New System.Drawing.Size(146, 23)
        Me.Txt_ResAreaName.TabIndex = 0
        '
        'Label26
        '
        Me.Label26.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label26.AutoSize = True
        Me.Label26.Font = New System.Drawing.Font("Calibri", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label26.Location = New System.Drawing.Point(4, 160)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(136, 30)
        Me.Label26.TabIndex = 0
        Me.Label26.Text = "தந்தை / கணவன் பெயர்"
        '
        'Txt_ResAreaNo
        '
        Me.Txt_ResAreaNo.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Txt_ResAreaNo.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.Txt_ResAreaNo.Location = New System.Drawing.Point(147, 78)
        Me.Txt_ResAreaNo.MaxLength = 16
        Me.Txt_ResAreaNo.Name = "Txt_ResAreaNo"
        Me.Txt_ResAreaNo.Size = New System.Drawing.Size(146, 23)
        Me.Txt_ResAreaNo.TabIndex = 1
        '
        'Txt_ResPerName
        '
        Me.Txt_ResPerName.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Txt_ResPerName.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.Txt_ResPerName.Location = New System.Drawing.Point(147, 118)
        Me.Txt_ResPerName.MaxLength = 16
        Me.Txt_ResPerName.Name = "Txt_ResPerName"
        Me.Txt_ResPerName.Size = New System.Drawing.Size(146, 23)
        Me.Txt_ResPerName.TabIndex = 2
        '
        'Txt_HusbandFatherName
        '
        Me.Txt_HusbandFatherName.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Txt_HusbandFatherName.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.Txt_HusbandFatherName.Location = New System.Drawing.Point(147, 164)
        Me.Txt_HusbandFatherName.MaxLength = 16
        Me.Txt_HusbandFatherName.Name = "Txt_HusbandFatherName"
        Me.Txt_HusbandFatherName.Size = New System.Drawing.Size(146, 23)
        Me.Txt_HusbandFatherName.TabIndex = 3
        '
        'Btn_Finger
        '
        Me.Btn_Finger.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Btn_Finger.Font = New System.Drawing.Font("Arial Narrow", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_Finger.Location = New System.Drawing.Point(4, 251)
        Me.Btn_Finger.Name = "Btn_Finger"
        Me.Btn_Finger.Size = New System.Drawing.Size(136, 83)
        Me.Btn_Finger.TabIndex = 5
        Me.Btn_Finger.Text = "ஒதுக்கீட்டாளர் வலது அல்லது இடது கை பெருவிரல் ரேகை"
        Me.Btn_Finger.TextAlign = System.Drawing.ContentAlignment.TopLeft
        Me.Btn_Finger.UseVisualStyleBackColor = True
        '
        'PictureBox_Sign
        '
        Me.PictureBox_Sign.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox_Sign.Dock = System.Windows.Forms.DockStyle.Fill
        Me.PictureBox_Sign.Location = New System.Drawing.Point(144, 204)
        Me.PictureBox_Sign.Margin = New System.Windows.Forms.Padding(0)
        Me.PictureBox_Sign.Name = "PictureBox_Sign"
        Me.PictureBox_Sign.Size = New System.Drawing.Size(152, 43)
        Me.PictureBox_Sign.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox_Sign.TabIndex = 6
        Me.PictureBox_Sign.TabStop = False
        '
        'PictureBox_Finger
        '
        Me.PictureBox_Finger.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox_Finger.Dock = System.Windows.Forms.DockStyle.Fill
        Me.PictureBox_Finger.Location = New System.Drawing.Point(144, 248)
        Me.PictureBox_Finger.Margin = New System.Windows.Forms.Padding(0)
        Me.PictureBox_Finger.Name = "PictureBox_Finger"
        Me.PictureBox_Finger.Size = New System.Drawing.Size(152, 89)
        Me.PictureBox_Finger.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox_Finger.TabIndex = 6
        Me.PictureBox_Finger.TabStop = False
        '
        'TableLayoutPanel4
        '
        Me.TableLayoutPanel4.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.[Single]
        Me.TableLayoutPanel4.ColumnCount = 2
        Me.TableLayoutPanel4.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 55.10204!))
        Me.TableLayoutPanel4.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 44.89796!))
        Me.TableLayoutPanel4.Controls.Add(Me.Label27, 0, 0)
        Me.TableLayoutPanel4.Controls.Add(Me.Label28, 0, 1)
        Me.TableLayoutPanel4.Controls.Add(Me.Label29, 0, 2)
        Me.TableLayoutPanel4.Controls.Add(Me.Txt_OutAddress, 1, 0)
        Me.TableLayoutPanel4.Controls.Add(Me.Txt_OutArea, 1, 1)
        Me.TableLayoutPanel4.Controls.Add(Me.Txt_OutDoorNo, 1, 2)
        Me.TableLayoutPanel4.Controls.Add(Me.Btn_Submit, 0, 7)
        Me.TableLayoutPanel4.Controls.Add(Me.Label31, 0, 3)
        Me.TableLayoutPanel4.Controls.Add(Me.Txt_OutStreet, 1, 3)
        Me.TableLayoutPanel4.Controls.Add(Me.Label30, 0, 4)
        Me.TableLayoutPanel4.Controls.Add(Me.Label32, 0, 5)
        Me.TableLayoutPanel4.Controls.Add(Me.Label33, 0, 6)
        Me.TableLayoutPanel4.Controls.Add(Me.Dtp_EntryDate, 1, 5)
        Me.TableLayoutPanel4.Controls.Add(Me.Txt_OutDistrict, 1, 4)
        Me.TableLayoutPanel4.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel4.Location = New System.Drawing.Point(303, 0)
        Me.TableLayoutPanel4.Margin = New System.Windows.Forms.Padding(0)
        Me.TableLayoutPanel4.Name = "TableLayoutPanel4"
        Me.TableLayoutPanel4.RowCount = 8
        Me.TableLayoutPanel4.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 18.0758!))
        Me.TableLayoutPanel4.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 11.66181!))
        Me.TableLayoutPanel4.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.87172!))
        Me.TableLayoutPanel4.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.746356!))
        Me.TableLayoutPanel4.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 19.82507!))
        Me.TableLayoutPanel4.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.45481!))
        Me.TableLayoutPanel4.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 14.57726!))
        Me.TableLayoutPanel4.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 13.41108!))
        Me.TableLayoutPanel4.Size = New System.Drawing.Size(245, 344)
        Me.TableLayoutPanel4.TabIndex = 1
        '
        'Label27
        '
        Me.Label27.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label27.AutoSize = True
        Me.Label27.Font = New System.Drawing.Font("Calibri", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label27.Location = New System.Drawing.Point(4, 15)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(127, 30)
        Me.Label27.TabIndex = 0
        Me.Label27.Text = "வெளியேற்றப்பட்ட வீட்டின் முகவரி"
        '
        'Label28
        '
        Me.Label28.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label28.AutoSize = True
        Me.Label28.Font = New System.Drawing.Font("Calibri", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label28.Location = New System.Drawing.Point(4, 65)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(127, 30)
        Me.Label28.TabIndex = 0
        Me.Label28.Text = "வெளியேற்றப்பட்ட பகுதியின் பெயர்"
        '
        'Label29
        '
        Me.Label29.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label29.AutoSize = True
        Me.Label29.Font = New System.Drawing.Font("Calibri", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label29.Location = New System.Drawing.Point(4, 105)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(127, 15)
        Me.Label29.TabIndex = 0
        Me.Label29.Text = "கதவு எண்"
        '
        'Txt_OutAddress
        '
        Me.Txt_OutAddress.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Txt_OutAddress.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.Txt_OutAddress.Location = New System.Drawing.Point(138, 19)
        Me.Txt_OutAddress.MaxLength = 16
        Me.Txt_OutAddress.Name = "Txt_OutAddress"
        Me.Txt_OutAddress.Size = New System.Drawing.Size(103, 23)
        Me.Txt_OutAddress.TabIndex = 0
        '
        'Txt_OutArea
        '
        Me.Txt_OutArea.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Txt_OutArea.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.Txt_OutArea.Location = New System.Drawing.Point(138, 68)
        Me.Txt_OutArea.MaxLength = 16
        Me.Txt_OutArea.Name = "Txt_OutArea"
        Me.Txt_OutArea.Size = New System.Drawing.Size(103, 23)
        Me.Txt_OutArea.TabIndex = 1
        '
        'Txt_OutDoorNo
        '
        Me.Txt_OutDoorNo.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Txt_OutDoorNo.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.Txt_OutDoorNo.Location = New System.Drawing.Point(138, 103)
        Me.Txt_OutDoorNo.MaxLength = 16
        Me.Txt_OutDoorNo.Name = "Txt_OutDoorNo"
        Me.Txt_OutDoorNo.Size = New System.Drawing.Size(103, 23)
        Me.Txt_OutDoorNo.TabIndex = 2
        '
        'Btn_Submit
        '
        Me.Btn_Submit.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.TableLayoutPanel4.SetColumnSpan(Me.Btn_Submit, 2)
        Me.Btn_Submit.Font = New System.Drawing.Font("Calibri", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_Submit.Location = New System.Drawing.Point(52, 305)
        Me.Btn_Submit.Name = "Btn_Submit"
        Me.Btn_Submit.Size = New System.Drawing.Size(141, 29)
        Me.Btn_Submit.TabIndex = 6
        Me.Btn_Submit.Text = "சமர்ப்பிக்க"
        Me.Btn_Submit.UseVisualStyleBackColor = True
        '
        'Label31
        '
        Me.Label31.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label31.AutoSize = True
        Me.Label31.Font = New System.Drawing.Font("Calibri", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label31.Location = New System.Drawing.Point(4, 132)
        Me.Label31.Name = "Label31"
        Me.Label31.Size = New System.Drawing.Size(127, 15)
        Me.Label31.TabIndex = 0
        Me.Label31.Text = "தெரு"
        '
        'Txt_OutStreet
        '
        Me.Txt_OutStreet.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Txt_OutStreet.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.Txt_OutStreet.Location = New System.Drawing.Point(138, 129)
        Me.Txt_OutStreet.MaxLength = 16
        Me.Txt_OutStreet.Name = "Txt_OutStreet"
        Me.Txt_OutStreet.Size = New System.Drawing.Size(103, 23)
        Me.Txt_OutStreet.TabIndex = 3
        '
        'Label30
        '
        Me.Label30.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label30.AutoSize = True
        Me.Label30.Font = New System.Drawing.Font("Calibri", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label30.Location = New System.Drawing.Point(4, 155)
        Me.Label30.Name = "Label30"
        Me.Label30.Size = New System.Drawing.Size(127, 64)
        Me.Label30.TabIndex = 0
        Me.Label30.Text = "மாநகராட்சி / நகராட்சி / பேரூராட்சி / பஞ்சாயத்து வட்டம் / கோட்டம்"
        '
        'Label32
        '
        Me.Label32.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label32.AutoSize = True
        Me.Label32.Font = New System.Drawing.Font("Calibri", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label32.Location = New System.Drawing.Point(4, 226)
        Me.Label32.Name = "Label32"
        Me.Label32.Size = New System.Drawing.Size(127, 15)
        Me.Label32.TabIndex = 0
        Me.Label32.Text = "தேதி"
        '
        'Label33
        '
        Me.Label33.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label33.AutoSize = True
        Me.Label33.Font = New System.Drawing.Font("Calibri", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label33.Location = New System.Drawing.Point(4, 249)
        Me.Label33.Name = "Label33"
        Me.Label33.Size = New System.Drawing.Size(127, 45)
        Me.Label33.TabIndex = 0
        Me.Label33.Text = "வழங்கிய அலுவலர் கையொப்பம் வகிக்கும் பதவி"
        '
        'Dtp_EntryDate
        '
        Me.Dtp_EntryDate.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Dtp_EntryDate.CustomFormat = "dd-MMM-yyyy"
        Me.Dtp_EntryDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.Dtp_EntryDate.Location = New System.Drawing.Point(138, 223)
        Me.Dtp_EntryDate.Name = "Dtp_EntryDate"
        Me.Dtp_EntryDate.Size = New System.Drawing.Size(103, 23)
        Me.Dtp_EntryDate.TabIndex = 5
        '
        'Txt_OutDistrict
        '
        Me.Txt_OutDistrict.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Txt_OutDistrict.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.Txt_OutDistrict.Location = New System.Drawing.Point(138, 175)
        Me.Txt_OutDistrict.MaxLength = 16
        Me.Txt_OutDistrict.Name = "Txt_OutDistrict"
        Me.Txt_OutDistrict.Size = New System.Drawing.Size(103, 23)
        Me.Txt_OutDistrict.TabIndex = 4
        '
        'Tab_Print
        '
        Me.Tab_Print.Controls.Add(Me.TableLayoutPanel2)
        Me.Tab_Print.Location = New System.Drawing.Point(4, 24)
        Me.Tab_Print.Name = "Tab_Print"
        Me.Tab_Print.Padding = New System.Windows.Forms.Padding(3)
        Me.Tab_Print.Size = New System.Drawing.Size(1194, 630)
        Me.Tab_Print.TabIndex = 1
        Me.Tab_Print.Text = "Print"
        Me.Tab_Print.UseVisualStyleBackColor = True
        '
        'TableLayoutPanel2
        '
        Me.TableLayoutPanel2.ColumnCount = 1
        Me.TableLayoutPanel2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel2.Controls.Add(Me.ReportView, 0, 0)
        Me.TableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel2.Location = New System.Drawing.Point(3, 3)
        Me.TableLayoutPanel2.Name = "TableLayoutPanel2"
        Me.TableLayoutPanel2.RowCount = 1
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.103638!))
        Me.TableLayoutPanel2.Size = New System.Drawing.Size(1188, 624)
        Me.TableLayoutPanel2.TabIndex = 1
        '
        'ReportView
        '
        Me.ReportView.Dock = System.Windows.Forms.DockStyle.Fill
        Me.ReportView.DocumentMapWidth = 92
        Me.ReportView.Location = New System.Drawing.Point(3, 3)
        Me.ReportView.Name = "ReportView"
        Me.ReportView.Size = New System.Drawing.Size(1182, 618)
        Me.ReportView.TabIndex = 0
        '
        'FrmMainEntry
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1202, 658)
        Me.Controls.Add(Me.TabControl_Main)
        Me.Font = New System.Drawing.Font("Calibri", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Name = "FrmMainEntry"
        Me.Text = "Data"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.TabControl_Main.ResumeLayout(False)
        Me.Tab_Entry.ResumeLayout(False)
        Me.TLP_Left.ResumeLayout(False)
        Me.TLP_ReservationDet.ResumeLayout(False)
        Me.TLP_ReservationDet.PerformLayout()
        Me.TLP_LeftData.ResumeLayout(False)
        Me.TLP_LeftData.PerformLayout()
        Me.TLP_FamilyMembers.ResumeLayout(False)
        Me.TLP_FamilyMembers.PerformLayout()
        Me.TLP_FamilyEntry.ResumeLayout(False)
        Me.TLP_FamilyEntry.PerformLayout()
        CType(Me.DGV_FamilymembersData, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TLP_Food.ResumeLayout(False)
        Me.TLP_Food.PerformLayout()
        Me.TLP_VoterID.ResumeLayout(False)
        Me.TLP_VoterID.PerformLayout()
        Me.TLP_Head.ResumeLayout(False)
        Me.TLP_Head.PerformLayout()
        Me.TLP_RightData.ResumeLayout(False)
        Me.TLP_FamilyPhoto.ResumeLayout(False)
        CType(Me.Pic_FamilyImage, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TableLayoutPanel1.ResumeLayout(False)
        Me.TableLayoutPanel3.ResumeLayout(False)
        Me.TableLayoutPanel3.PerformLayout()
        CType(Me.PictureBox_Sign, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox_Finger, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TableLayoutPanel4.ResumeLayout(False)
        Me.TableLayoutPanel4.PerformLayout()
        Me.Tab_Print.ResumeLayout(False)
        Me.TableLayoutPanel2.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents TabControl_Main As System.Windows.Forms.TabControl
    Friend WithEvents Tab_Entry As System.Windows.Forms.TabPage
    Friend WithEvents Tab_Print As System.Windows.Forms.TabPage
    Friend WithEvents ReportView As Microsoft.Reporting.WinForms.ReportViewer
    Friend WithEvents TableLayoutPanel2 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents TLP_Left As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents TLP_FamilyMembers As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents TLP_FamilyEntry As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Txt_FamilyName As System.Windows.Forms.TextBox
    Friend WithEvents txt_FamilyAge As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Dtp_FamilyDOB As System.Windows.Forms.DateTimePicker
    Friend WithEvents Cbo_RelationShip As System.Windows.Forms.ComboBox
    Friend WithEvents Txt_AhaarNo As System.Windows.Forms.TextBox
    Friend WithEvents Btn_AddFamilyMember As System.Windows.Forms.Button
    Friend WithEvents DGV_FamilymembersData As System.Windows.Forms.DataGridView
    Friend WithEvents TLP_LeftData As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents TLP_Head As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents TLP_Food As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Txt_NewFoodNo As System.Windows.Forms.TextBox
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Txt_OldFoodNo As System.Windows.Forms.TextBox
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents Dtp_NewFoodDate As System.Windows.Forms.DateTimePicker
    Friend WithEvents Dtp_OldFoodDate As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents TLP_VoterID As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents Txt_NewVoterIdNo As System.Windows.Forms.TextBox
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents Dtp_NewVoterIDDate As System.Windows.Forms.DateTimePicker
    Friend WithEvents Dtp_OldVoterIDDate As System.Windows.Forms.DateTimePicker
    Friend WithEvents Txt_OldVoterIdNo As System.Windows.Forms.TextBox
    Friend WithEvents Txt_NewVoterCont As System.Windows.Forms.TextBox
    Friend WithEvents Txt_OldVoterCont As System.Windows.Forms.TextBox
    Friend WithEvents TLP_RightData As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents TLP_ReservationDet As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Friend WithEvents Label22 As System.Windows.Forms.Label
    Friend WithEvents DTP_ResDate As System.Windows.Forms.DateTimePicker
    Friend WithEvents Txt_ResNo As System.Windows.Forms.TextBox
    Friend WithEvents TLP_FamilyPhoto As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents Btn_FamilyImage As System.Windows.Forms.Button
    Friend WithEvents Pic_FamilyImage As System.Windows.Forms.PictureBox
    Friend WithEvents TableLayoutPanel1 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents TableLayoutPanel3 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents Label23 As System.Windows.Forms.Label
    Friend WithEvents Label24 As System.Windows.Forms.Label
    Friend WithEvents Label25 As System.Windows.Forms.Label
    Friend WithEvents Txt_ResAreaName As System.Windows.Forms.TextBox
    Friend WithEvents Label26 As System.Windows.Forms.Label
    Friend WithEvents Txt_ResAreaNo As System.Windows.Forms.TextBox
    Friend WithEvents Txt_ResPerName As System.Windows.Forms.TextBox
    Friend WithEvents Txt_HusbandFatherName As System.Windows.Forms.TextBox
    Friend WithEvents TableLayoutPanel4 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents Label27 As System.Windows.Forms.Label
    Friend WithEvents Label28 As System.Windows.Forms.Label
    Friend WithEvents Label29 As System.Windows.Forms.Label
    Friend WithEvents Label30 As System.Windows.Forms.Label
    Friend WithEvents Btn_Submit As System.Windows.Forms.Button
    Friend WithEvents Txt_OutAddress As System.Windows.Forms.TextBox
    Friend WithEvents Txt_OutArea As System.Windows.Forms.TextBox
    Friend WithEvents Txt_OutDoorNo As System.Windows.Forms.TextBox
    Friend WithEvents Txt_OutDistrict As System.Windows.Forms.TextBox
    Friend WithEvents Label31 As System.Windows.Forms.Label
    Friend WithEvents Txt_OutStreet As System.Windows.Forms.TextBox
    Friend WithEvents Btn_Sign As System.Windows.Forms.Button
    Friend WithEvents Btn_Finger As System.Windows.Forms.Button
    Friend WithEvents PictureBox_Sign As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox_Finger As System.Windows.Forms.PictureBox
    Friend WithEvents btn_NewForm As System.Windows.Forms.Button
    Friend WithEvents Dtp_EntryDate As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label32 As System.Windows.Forms.Label
    Friend WithEvents Label33 As System.Windows.Forms.Label

End Class
