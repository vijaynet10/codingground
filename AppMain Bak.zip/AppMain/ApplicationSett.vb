﻿Public Class ApplicationSett

    Enum ExpireType
        Two_Days
        One_Month
        Three_Month
    End Enum

    Friend MyExpireType As ExpireType


    Public Function ChangeData(_ExpireType As ExpireType) As Int32
        Try
            If IsNothing(My.Settings.ValiDType) OrElse My.Settings.ValiDType = "" Then
                My.Settings.ValiDType = ExpireType.Two_Days
                _ExpireType = ExpireType.Two_Days
            Else
                _ExpireType = My.Settings.ValiDType
            End If




            If IsNothing(My.Settings.StartedDate) OrElse (My.Settings.StartedDate) = "#12:00:00 AM#" Then My.Settings.StartedDate = Now

            If _ExpireType = ExpireType.Two_Days Then
                My.Settings.ExpireDate = DateAdd(DateInterval.Day, 2, My.Settings.StartedDate)
            ElseIf _ExpireType = ExpireType.One_Month Then
                My.Settings.ExpireDate = DateAdd(DateInterval.Day, 30, My.Settings.StartedDate)
            ElseIf _ExpireType = ExpireType.Three_Month Then
                My.Settings.ExpireDate = DateAdd(DateInterval.Day, 90, My.Settings.StartedDate)
            End If

            My.Settings.ValiDType = _ExpireType


            ChangeData = 0
        Catch ex As Exception
            Throw
        Finally
            MyExpireType = My.Settings.ValiDType
            My.Settings.Save()
        End Try

    End Function
    Public Function CheckExpire()
        Try
            Dim DiffDays As Integer = DateDiff(DateInterval.Day, Now.Date, My.Settings.ExpireDate)
            If DiffDays <= 0 Then Throw New Exception("Ypur Application expired....")
            CheckExpire = 0
        Catch ex As Exception
            Throw
        End Try
    End Function


End Class
