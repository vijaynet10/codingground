﻿Public Class FrmMarkAnalytical
    Dim Logic As New Logic.Excel

    Private Sub Btn_Process_Click(sender As Object, e As EventArgs) Handles Btn_Process.Click
        Try


            ReportView_SM.LocalReport.DataSources.Clear()
            ReportView_SM.RefreshReport()


            Dim MyOpenFileDialog As New OpenFileDialog

            MyOpenFileDialog.Title = "xlsx Files Only"
            MyOpenFileDialog.Multiselect = False
            MyOpenFileDialog.Filter = "xlsx|*.xlsx"
            Dim DiaResult As DialogResult = MyOpenFileDialog.ShowDialog()
            If DiaResult <> System.Windows.Forms.DialogResult.OK Then Return
            Logic.DoWork(MyOpenFileDialog.FileName)



            With ReportView_SM.LocalReport
                .DataSources.Clear()
                .DataSources.Add(New Microsoft.Reporting.WinForms.ReportDataSource("Student", Me.Logic.CopiedMarkMaster))
                .ReportPath = IO.Path.Combine(Application.StartupPath, "Report_MarkAnalytical.rdlc")
                .ReportEmbeddedResource = "MarkAnalytical"
                .Refresh()
            End With
            ReportView_SM.RefreshReport()
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub

    
End Class
