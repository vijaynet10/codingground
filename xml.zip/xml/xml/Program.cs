﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Xml.Serialization;

namespace xml
{
    class Program
    {
        static employees data = new employees();
        static  string filename;
        static  ConsoleKeyInfo keyinfo;

        static void Main(string[] args)
        {


            try
            {
                filename = System.IO.Path.Combine(AppDomain.CurrentDomain.BaseDirectory.ToString(), "employeesdata.xml");
               
                
                step1:

               bool isloaded = loaddata();
                
                if  (isloaded==true)
                {
                    displaydata();
                }

                Console.WriteLine("Do you want  to add new  employee ? Y/N");
                keyinfo = Console.ReadKey();
                if (keyinfo.Key.ToString()=="Y") 
                {newemployee();
                goto step1;
                }
                                Console.ReadLine();
                            }


            catch (Exception ex)
            {
                Console.WriteLine("error -" + ex.Message.ToString());
                Console.WriteLine(" stack trace -" + ex.StackTrace.ToString());
                Console.ReadLine();

            }
        }


        static bool  newemployee() {
        try 
        {


            employee emp   = new employee();

            Console.WriteLine(" Employee Name : " );
            emp.name=  Console.ReadLine().ToString();
            Console.WriteLine(" Employee Age : ");
            emp.age =  Int32.Parse( Console.ReadLine());

            Console.WriteLine(" Emplyee Designation : ");
            emp.designation = (Console.ReadLine());

            Console.WriteLine("Employee Address ? Y/N ");
            keyinfo = Console.ReadKey();
            if (keyinfo.Key.ToString() == "Y")
            {
                emp.address = new address();

                Console.WriteLine(" Door No ? ");
                emp.address .doorNo= (Console.ReadLine());
                Console.WriteLine(" street ?  ");
                emp.address.street= (Console.ReadLine());

                Console.WriteLine(" twon?  ");
                emp.address.twon= (Console.ReadLine());

                Console.WriteLine(" state ?  ");
                emp.address.state= (Console.ReadLine());



            }            
            data.value.Add(emp);


            writedata();
            Console.WriteLine(" employee added");
             


             return true;
        }
             catch (Exception ex ) {throw new Exception(ex.Message.ToString());}
        }

        static bool writedata()
        {
            try
            {
                  using (TextWriter reader = new StreamWriter(filename))
                  {
                      XmlSerializer serializer = new XmlSerializer(typeof(employees));
                      serializer.Serialize(reader, data);
                   }
                return true;
            }
            catch (Exception ex) { throw new Exception(ex.Message.ToString()); }


        }

        static bool loaddata() {
            try
            {
                if (System.IO.File.Exists(filename) == false) { Console.WriteLine("data file not found"); return true; }


                using (TextReader reader = new StreamReader(filename))
                {
                    XmlSerializer serializer = new XmlSerializer(typeof(employees));
                    data = (employees)serializer.Deserialize(reader);
                }
                return true;
            }
                catch (Exception ex ) {throw new Exception(ex.Message.ToString());}
                   
    }

        static bool  displaydata()
        {

            try
            {


                

                 Console.WriteLine(" Emp Count  {0}" , data.value.Count() );


                 for (int empindex = 0; empindex < data.value.Count; empindex++)
                 {
                     employee emp  = data.value.ElementAt(empindex);
                     string[] values = new string[] { emp.name, emp.age.ToString(), emp.designation };

                     string address;

                     if  (emp.address!=null)
                     { address = ",Address : Door No " + emp.address.doorNo + ",street" + emp.address.street + ",twon" + emp.address.twon + ",state" + emp.address.state + ""; }
                    else {address = string.Empty;}
                         
                     
                     Console.WriteLine("name : {0} , age {1} ,  designation {2}  "+address   +"" ,  values);

                 }

                
                 

                return true;
            }
            catch (Exception ex) { throw new Exception(ex.Message.ToString()); }

            

        }
            



        
    }
}

