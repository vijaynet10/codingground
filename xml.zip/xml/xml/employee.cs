﻿
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System;
using System.IO;
using System.Collections;
using System.Xml.Serialization;


namespace xml
{


    [XmlRootAttribute("employees", IsNullable = true)]
    public class employees 
    {
        [XmlElement("employee")]
        public List<employee> value = new List<employee>();
        public IEnumerator GetEnumerator()
        {
            return (IEnumerator)this;
        }
    }

 public  class employee
    {
        string _name;
        [XmlElement("name")]
        public string name { get { return _name; } set { _name = value; } }
        int _age;
        [XmlElement("age")]
        public int age { get { return _age; } set { _age = value; } }
        string _designation;
        [XmlElement("designation")]
        public  string designation {get{return _designation;} set {_designation=value;}}

        address _address;
        [XmlElement("address")]
        public address address { get { return _address; } set { _address = value; } }

    }
    public  class address
    {
        string _doorNo;
        [XmlElement("doorno")]
        public string doorNo { get { return _doorNo; } set { _doorNo = value; } }

        string _street;
        [XmlElement("street")]
        public string street { get { return _street; } set { _street = value; } }

        string _twon;
        [XmlElement("twon")]
        public string twon { get { return _twon; } set { _twon  = value; } }

        string _state;
        [XmlElement("state")]
        public string state { get { return _state; } set { _state = value; } }
        
    }

}
