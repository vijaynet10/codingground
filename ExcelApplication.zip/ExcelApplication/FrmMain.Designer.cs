﻿namespace ExcelApplication
{
    partial class FrmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.btn_LoadExcel = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.TxtRowIndex = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            this.openFileDialog1.Filter = "Excel|*.xlsx";
            // 
            // btn_LoadExcel
            // 
            this.btn_LoadExcel.Location = new System.Drawing.Point(12, 72);
            this.btn_LoadExcel.Name = "btn_LoadExcel";
            this.btn_LoadExcel.Size = new System.Drawing.Size(107, 39);
            this.btn_LoadExcel.TabIndex = 0;
            this.btn_LoadExcel.Text = "Load Excel";
            this.btn_LoadExcel.UseVisualStyleBackColor = true;
            this.btn_LoadExcel.Click += new System.EventHandler(this.LaodExcel);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(411, 68);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(98, 47);
            this.button2.TabIndex = 1;
            this.button2.Text = "Remove Row";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // TxtRowIndex
            // 
            this.TxtRowIndex.Location = new System.Drawing.Point(274, 82);
            this.TxtRowIndex.Name = "TxtRowIndex";
            this.TxtRowIndex.Size = new System.Drawing.Size(100, 20);
            this.TxtRowIndex.TabIndex = 2;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(125, 85);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(117, 13);
            this.label1.TabIndex = 3;
            this.label1.Text = "Row Index To Remove";
            // 
            // FrmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(640, 334);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.TxtRowIndex);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.btn_LoadExcel);
            this.Name = "FrmMain";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.Button btn_LoadExcel;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.TextBox TxtRowIndex;
        private System.Windows.Forms.Label label1;
    }
}

