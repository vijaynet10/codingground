﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Microsoft.Office.Interop.Excel;

namespace ExcelApplication
{
    public partial class FrmMain : Form
    {
        public FrmMain()
        {
            InitializeComponent();
        }

        Microsoft.Office.Interop.Excel.Application docExcel  ;
        Microsoft.Office.Interop.Excel.Workbook docExcelWorkBook;
        Microsoft.Office.Interop.Excel.Worksheet docExcelActiveSheet;
        


        private void button1_Click(object sender, EventArgs e)
        {

            
        }

        private void LaodExcel(object sender, EventArgs e)
        {
            try
            {

               DialogResult dresult=  openFileDialog1.ShowDialog();
                if  (dresult!=System.Windows.Forms.DialogResult.OK) {return;}
                docExcel = new Microsoft.Office.Interop.Excel.Application { Visible = false };
                docExcelWorkBook = docExcel.Workbooks.Open(openFileDialog1.FileName);
            }
            catch(Exception ex){
                MessageBox.Show(ex.Message);

            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                if (docExcelWorkBook==null){throw new Exception("Invalid  workbook");}
                int rowindex =  Int32.Parse( TxtRowIndex.Text);
                docExcelActiveSheet = docExcelWorkBook.ActiveSheet();
                Microsoft.Office.Interop.Excel.Range cel = (Range)docExcelActiveSheet.Rows[rowindex,Type.Missing];
                cel.Delete(XlDeleteShiftDirection.xlShiftUp);
                docExcelWorkBook.Save();
                docExcelWorkBook.Close(false);
                docExcel.Quit();
                System.Runtime.InteropServices.Marshal.ReleaseComObject(docExcel);
                
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }
    }
}
