﻿Imports System.Net
Imports System.Runtime.Serialization.Json
Imports System.IO
Imports System.Text
Imports System.ComponentModel
Imports System.Collections.Specialized
Public Class WebHandler
    Friend WithEvents WebClient As New MyWebClient
    Friend MemoryStream As MemoryStream
    Friend ResultMemoryStream As MemoryStream
    Friend MyHttpWebResponse As HttpWebResponse
    Friend Property webHandleValeus As New webHandleValeus
    Private BGWorker As BackgroundWorker
    Public Function SetBGWorker(_BackgroundWorker As BackgroundWorker) As Boolean
        Try
            BGWorker = _BackgroundWorker
            Return True
        Catch ex As Exception
            Throw
        End Try
    End Function
    Public Function GetJsonFormatted(_DataContract As Object) As ReturnStatus
        Try
            Dim MyDataContractJsonSerializer = New DataContractJsonSerializer(_DataContract.GetType)
            Dim JsnoString As Object
            Using MYMemoryStream = New MemoryStream
                MyDataContractJsonSerializer.WriteObject(MYMemoryStream, _DataContract)
                JsnoString = Encoding.UTF8.GetString(MYMemoryStream.ToArray)
            End Using
            Return New ReturnStatus(True, JsnoString)
        Catch ex As Exception
            Return New ReturnStatus(False, ex.Message)
        End Try
    End Function
    Public Function UploadFile(uri As Uri, UploadPostForms As UploadPostForms, _WebHeaders As List(Of WebHeader), _
                               method As String, ContentType As String, FileParamName As String) As ReturnStatus
        Dim MyWebResponse As WebResponse = Nothing
        Try
            Dim boundary As String = "---------------------------" + DateTime.Now.Ticks.ToString("x")
            Dim boundarybytes As Byte() = System.Text.Encoding.ASCII.GetBytes((Convert.ToString(vbCr & vbLf & "--") & boundary) + vbCr & vbLf)

            Dim wr As HttpWebRequest = DirectCast(WebRequest.Create(uri), HttpWebRequest)
            wr.Timeout = 60 * 1000 * 30
            wr.ContentType = Convert.ToString("multipart/form-data; boundary=") & boundary
            wr.Method = "POST"
            wr.KeepAlive = True
            wr.Credentials = System.Net.CredentialCache.DefaultCredentials

            Dim rs As Stream = wr.GetRequestStream()

            Dim formdataTemplate As String = "Content-Disposition: form-data; name=""{0}""" & vbCr & vbLf & vbCr & vbLf & "{1}"
            For Each key As String In UploadPostForms.NameValueCollection.Keys
                rs.Write(boundarybytes, 0, boundarybytes.Length)
                Dim formitem As String = String.Format(formdataTemplate, key, UploadPostForms.NameValueCollection(key))
                Dim formitembytes As Byte() = System.Text.Encoding.UTF8.GetBytes(formitem)
                rs.Write(formitembytes, 0, formitembytes.Length)
            Next
            rs.Write(boundarybytes, 0, boundarybytes.Length)

            Dim headerTemplate As String = "Content-Disposition: form-data; name=""{0}""; filename=""{1}""" & vbCr & vbLf & "Content-Type: {2}" & vbCr & vbLf & vbCr & vbLf
            Dim header As String = String.Format(headerTemplate, FileParamName, UploadPostForms.FileName, ContentType)
            Dim headerbytes As Byte() = System.Text.Encoding.UTF8.GetBytes(header)
            rs.Write(headerbytes, 0, headerbytes.Length)

            Dim fileStream As New FileStream(UploadPostForms.FileName, FileMode.Open, FileAccess.Read)
            Dim buffer As Byte() = New Byte(4095) {}
            Dim bytesRead As Integer = 0
            While (InlineAssignHelper(bytesRead, fileStream.Read(buffer, 0, buffer.Length))) <> 0
                rs.Write(buffer, 0, bytesRead)
            End While
            fileStream.Close()

            Dim trailer As Byte() = System.Text.Encoding.ASCII.GetBytes((Convert.ToString(vbCr & vbLf & "--") & boundary) + "--" & vbCr & vbLf)
            rs.Write(trailer, 0, trailer.Length)
            rs.Close()

            MyWebResponse = wr.GetResponse()
            Dim stream2 As Stream = MyWebResponse.GetResponseStream()
            Dim reader2 As New StreamReader(stream2)
            If MyWebResponse IsNot Nothing Then MyWebResponse.Close() : MyWebResponse = Nothing
            Return New ReturnStatus(True, "Success")
        Catch ex1 As WebException
            Try
                If MyWebResponse IsNot Nothing Then MyWebResponse.Close() : MyWebResponse = Nothing
                If IsNothing(ex1.Response) Then
                    webHandleValeus.IsSucceed = False
                    webHandleValeus.StatusCode = -99
                    webHandleValeus.StatusDesc = "Upload  File -" & ex1.Message
                    Return New ReturnStatus(False, webHandleValeus.StatusDesc)
                End If

                MyHttpWebResponse = ex1.Response
                Dim errorbyte() As Byte = Nothing
                Dim errorStream As System.IO.Stream = MyHttpWebResponse.GetResponseStream()

                ReDim errorbyte(errorStream.Length)

                errorStream.Position = 1
                errorStream.Read(errorbyte, 0, errorStream.Length)

                Dim response As String = Encoding.UTF8.GetString(errorbyte)

                webHandleValeus.IsSucceed = False
                webHandleValeus.StatusCode = MyHttpWebResponse.StatusCode
                webHandleValeus.StatusDesc = response
                Return New ReturnStatus(False, "Upload  Data -" & ex1.Message & "-" & response)
            Catch ex As Exception

                webHandleValeus.IsSucceed = False
                webHandleValeus.StatusCode = -99
                webHandleValeus.StatusDesc = "Not WebException " & ex.Message
                Return New ReturnStatus(False, "Not WebException " & ex.Message)
            End Try
        Catch ex As Exception
            webHandleValeus.IsSucceed = False
            webHandleValeus.StatusCode = -99
            webHandleValeus.StatusDesc = "Not WebException " & ex.Message
            Return New ReturnStatus(False, "Not WebException " & ex.Message)
        End Try
    End Function
    Private Function InlineAssignHelper(Of T)(ByRef target As T, ByVal value As T) As T
        target = value
        Return value
    End Function
    Public Function UploadData(uri As Uri, jsonDataBytes As Byte(), _WebHeaders As List(Of WebHeader), method As String) As ReturnStatus
        Dim MyWebClient As MyWebClient
        MyWebClient = WebClient
        Try
            Dim MyResultMemoryStream() As Byte
            MyWebClient.Headers.Clear()
            With MyWebClient
                For Each WebHeader As WebHeader In _WebHeaders
                    .Headers.Add(WebHeader.Name, WebHeader.Value)
                Next
                MyResultMemoryStream = .UploadData(uri, jsonDataBytes)
            End With
            Dim ResponseString As String = Encoding.UTF8.GetString(MyResultMemoryStream)
            webHandleValeus.IsSucceed = True
            Return New ReturnStatus(True, ResponseString)

        Catch ex1 As WebException
            Try
                If IsNothing(ex1.Response) Then
                    webHandleValeus.IsSucceed = False
                    webHandleValeus.StatusCode = -99
                    webHandleValeus.StatusDesc = "Upload  File -" & ex1.Message
                    Return New ReturnStatus(False, webHandleValeus.StatusDesc)
                End If

                MyHttpWebResponse = ex1.Response
                Dim errorbyte() As Byte = Nothing
                Dim errorStream As System.IO.Stream = MyHttpWebResponse.GetResponseStream()
                ReDim errorbyte(errorStream.Length)

                errorStream.Position = 1
                errorStream.Read(errorbyte, 0, errorStream.Length)

                Dim response As String = Encoding.UTF8.GetString(errorbyte)

                webHandleValeus.IsSucceed = False
                webHandleValeus.StatusCode = MyHttpWebResponse.StatusCode
                webHandleValeus.StatusDesc = response
                Return New ReturnStatus(False, "Upload  Data -" & ex1.Message & "-" & response)
            Catch ex As Exception

                webHandleValeus.IsSucceed = False
                webHandleValeus.StatusCode = -99
                webHandleValeus.StatusDesc = "Not WebException " & ex.Message
                Return New ReturnStatus(False, ex.Message)
            End Try
        Catch ex As Exception
            webHandleValeus.IsSucceed = False
            webHandleValeus.StatusCode = -99
            webHandleValeus.StatusDesc = "Not WebException " & ex.Message
            Return New ReturnStatus(False, ex.Message)
        End Try
    End Function
    Private Sub WebClient_UploadProgressChanged(sender As Object, e As UploadProgressChangedEventArgs) Handles WebClient.UploadProgressChanged

        If IsNothing(Me.BGWorker) = False Then
            Me.BGWorker.ReportProgress("Upload  Progress % : " & e.ProgressPercentage & " Bytes Sent :" & e.BytesSent & "  Total Bytes To Receive :" & e.TotalBytesToReceive & " Total Bytes To Send :" & e.TotalBytesToSend & "")
        End If

    End Sub
    Public Sub New(_BGWorker As BackgroundWorker)
        Me.BGWorker = _BGWorker
        Me.BGWorker.WorkerReportsProgress = True
    End Sub
    Sub New()

    End Sub
End Class
Public Class webHandleValeus
    Private _StatusCode As Integer
    Friend Property StatusCode As Integer
        Get
            Return _StatusCode
        End Get
        Set(value As Integer)
            _StatusCode = value
        End Set
    End Property

    Private _StatusDesc As String
    Friend Property StatusDesc As String
        Get
            Return _StatusDesc
        End Get
        Set(value As String)
            _StatusDesc = value
        End Set
    End Property

    Private _IsSucceed As Boolean
    Friend Property IsSucceed As Boolean
        Get
            Return _IsSucceed
        End Get
        Set(value As Boolean)
            _IsSucceed = value
        End Set
    End Property
End Class
Public Class MyWebClient
    Inherits WebClient
    Protected Overrides Function GetWebRequest(ByVal address As System.Uri) As System.Net.WebRequest
        Dim R = MyBase.GetWebRequest(address)
        R.Timeout = 60 * 1000 * 30
        Return R
    End Function
End Class
Public Class ReturnStatus
    Private mReturnFlag As Boolean = False
    Friend Property Pro_ReturnFlag() As Boolean
        Get
            Return mReturnFlag
        End Get
        Set(value As Boolean)
            mReturnFlag = value
        End Set
    End Property
    Private mReturnDescription As String = String.Empty
    Friend Property Pro_ReturnDescription() As String
        Get
            Return mReturnDescription
        End Get
        Set(ByVal value As String)
            mReturnDescription = value
        End Set
    End Property
    Public Sub New(_ReturnFlag As Boolean, _ReturnDesc As String)
        Try
            Pro_ReturnFlag = _ReturnFlag
            Pro_ReturnDescription = _ReturnDesc
        Catch ex As Exception
            Throw
        End Try
    End Sub
End Class
Public Class WebHeader
    Sub New(m_Name As String, m_Value As String)
        _Name = m_Name : _Value = m_Value
    End Sub
    Friend Property Name As String
    Friend Property Value As String

End Class
Public Class UploadPostForms
    Public Property FileName As String = String.Empty
    Public NameValueCollection As New NameValueCollection
End Class