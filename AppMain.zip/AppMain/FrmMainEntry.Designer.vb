﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FrmMainEntry
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.TabControl_Main = New System.Windows.Forms.TabControl()
        Me.Tab_Entry = New System.Windows.Forms.TabPage()
        Me.TableLayoutPanel1 = New System.Windows.Forms.TableLayoutPanel()
        Me.TableLayoutPanel3 = New System.Windows.Forms.TableLayoutPanel()
        Me.Btn_Submit = New System.Windows.Forms.Button()
        Me.TableLayoutPanel4 = New System.Windows.Forms.TableLayoutPanel()
        Me.TLP_Left = New System.Windows.Forms.TableLayoutPanel()
        Me.TLP_Proof = New System.Windows.Forms.TableLayoutPanel()
        Me.Tab_Print = New System.Windows.Forms.TabPage()
        Me.TableLayoutPanel2 = New System.Windows.Forms.TableLayoutPanel()
        Me.ReportView = New Microsoft.Reporting.WinForms.ReportViewer()
        Me.TableLayoutPanel5 = New System.Windows.Forms.TableLayoutPanel()
        Me.TabControl_Main.SuspendLayout()
        Me.Tab_Entry.SuspendLayout()
        Me.TableLayoutPanel1.SuspendLayout()
        Me.TableLayoutPanel3.SuspendLayout()
        Me.TLP_Left.SuspendLayout()
        Me.Tab_Print.SuspendLayout()
        Me.TableLayoutPanel2.SuspendLayout()
        Me.SuspendLayout()
        '
        'TabControl_Main
        '
        Me.TabControl_Main.Controls.Add(Me.Tab_Entry)
        Me.TabControl_Main.Controls.Add(Me.Tab_Print)
        Me.TabControl_Main.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TabControl_Main.Location = New System.Drawing.Point(0, 0)
        Me.TabControl_Main.Name = "TabControl_Main"
        Me.TabControl_Main.SelectedIndex = 0
        Me.TabControl_Main.Size = New System.Drawing.Size(1202, 658)
        Me.TabControl_Main.TabIndex = 0
        '
        'Tab_Entry
        '
        Me.Tab_Entry.Controls.Add(Me.TableLayoutPanel1)
        Me.Tab_Entry.Location = New System.Drawing.Point(4, 24)
        Me.Tab_Entry.Name = "Tab_Entry"
        Me.Tab_Entry.Padding = New System.Windows.Forms.Padding(3)
        Me.Tab_Entry.Size = New System.Drawing.Size(1194, 630)
        Me.Tab_Entry.TabIndex = 0
        Me.Tab_Entry.Text = "Entry"
        Me.Tab_Entry.UseVisualStyleBackColor = True
        '
        'TableLayoutPanel1
        '
        Me.TableLayoutPanel1.ColumnCount = 2
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.58923!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 49.41077!))
        Me.TableLayoutPanel1.Controls.Add(Me.TableLayoutPanel3, 0, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.TLP_Left, 0, 0)
        Me.TableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel1.Location = New System.Drawing.Point(3, 3)
        Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
        Me.TableLayoutPanel1.RowCount = 1
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 624.0!))
        Me.TableLayoutPanel1.Size = New System.Drawing.Size(1188, 624)
        Me.TableLayoutPanel1.TabIndex = 0
        '
        'TableLayoutPanel3
        '
        Me.TableLayoutPanel3.ColumnCount = 1
        Me.TableLayoutPanel3.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel3.Controls.Add(Me.Btn_Submit, 0, 2)
        Me.TableLayoutPanel3.Controls.Add(Me.TableLayoutPanel4, 0, 0)
        Me.TableLayoutPanel3.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel3.Location = New System.Drawing.Point(604, 3)
        Me.TableLayoutPanel3.Name = "TableLayoutPanel3"
        Me.TableLayoutPanel3.RowCount = 3
        Me.TableLayoutPanel3.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 54.20712!))
        Me.TableLayoutPanel3.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 38.67314!))
        Me.TableLayoutPanel3.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.957929!))
        Me.TableLayoutPanel3.Size = New System.Drawing.Size(581, 618)
        Me.TableLayoutPanel3.TabIndex = 1
        '
        'Btn_Submit
        '
        Me.Btn_Submit.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Btn_Submit.Location = New System.Drawing.Point(247, 579)
        Me.Btn_Submit.Name = "Btn_Submit"
        Me.Btn_Submit.Size = New System.Drawing.Size(87, 34)
        Me.Btn_Submit.TabIndex = 0
        Me.Btn_Submit.Text = "&Submit"
        Me.Btn_Submit.UseVisualStyleBackColor = True
        '
        'TableLayoutPanel4
        '
        Me.TableLayoutPanel4.ColumnCount = 2
        Me.TableLayoutPanel4.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel4.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel4.Location = New System.Drawing.Point(3, 3)
        Me.TableLayoutPanel4.Name = "TableLayoutPanel4"
        Me.TableLayoutPanel4.RowCount = 2
        Me.TableLayoutPanel4.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel4.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel4.Size = New System.Drawing.Size(200, 100)
        Me.TableLayoutPanel4.TabIndex = 1
        '
        'TLP_Left
        '
        Me.TLP_Left.ColumnCount = 1
        Me.TLP_Left.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TLP_Left.Controls.Add(Me.TLP_Proof, 0, 1)
        Me.TLP_Left.Controls.Add(Me.TableLayoutPanel5, 0, 0)
        Me.TLP_Left.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TLP_Left.Location = New System.Drawing.Point(3, 3)
        Me.TLP_Left.Name = "TLP_Left"
        Me.TLP_Left.RowCount = 2
        Me.TLP_Left.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 54.32331!))
        Me.TLP_Left.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 45.67669!))
        Me.TLP_Left.Size = New System.Drawing.Size(595, 618)
        Me.TLP_Left.TabIndex = 0
        '
        'TLP_Proof
        '
        Me.TLP_Proof.ColumnCount = 1
        Me.TLP_Proof.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TLP_Proof.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TLP_Proof.Location = New System.Drawing.Point(3, 338)
        Me.TLP_Proof.Name = "TLP_Proof"
        Me.TLP_Proof.RowCount = 2
        Me.TLP_Proof.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TLP_Proof.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TLP_Proof.Size = New System.Drawing.Size(589, 277)
        Me.TLP_Proof.TabIndex = 0
        '
        'Tab_Print
        '
        Me.Tab_Print.Controls.Add(Me.TableLayoutPanel2)
        Me.Tab_Print.Location = New System.Drawing.Point(4, 24)
        Me.Tab_Print.Name = "Tab_Print"
        Me.Tab_Print.Padding = New System.Windows.Forms.Padding(3)
        Me.Tab_Print.Size = New System.Drawing.Size(1194, 630)
        Me.Tab_Print.TabIndex = 1
        Me.Tab_Print.Text = "Print"
        Me.Tab_Print.UseVisualStyleBackColor = True
        '
        'TableLayoutPanel2
        '
        Me.TableLayoutPanel2.ColumnCount = 1
        Me.TableLayoutPanel2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel2.Controls.Add(Me.ReportView, 0, 1)
        Me.TableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel2.Location = New System.Drawing.Point(3, 3)
        Me.TableLayoutPanel2.Name = "TableLayoutPanel2"
        Me.TableLayoutPanel2.RowCount = 3
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.103638!))
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 85.79272!))
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.103638!))
        Me.TableLayoutPanel2.Size = New System.Drawing.Size(1188, 624)
        Me.TableLayoutPanel2.TabIndex = 1
        '
        'ReportView
        '
        Me.ReportView.Dock = System.Windows.Forms.DockStyle.Fill
        Me.ReportView.DocumentMapWidth = 92
        Me.ReportView.Location = New System.Drawing.Point(3, 47)
        Me.ReportView.Name = "ReportView"
        Me.ReportView.Size = New System.Drawing.Size(1182, 529)
        Me.ReportView.TabIndex = 0
        '
        'TableLayoutPanel5
        '
        Me.TableLayoutPanel5.ColumnCount = 2
        Me.TableLayoutPanel5.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel5.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel5.Location = New System.Drawing.Point(3, 3)
        Me.TableLayoutPanel5.Name = "TableLayoutPanel5"
        Me.TableLayoutPanel5.RowCount = 3
        Me.TableLayoutPanel5.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel5.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel5.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        Me.TableLayoutPanel5.Size = New System.Drawing.Size(200, 100)
        Me.TableLayoutPanel5.TabIndex = 1
        '
        'FrmMainEntry
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1202, 658)
        Me.Controls.Add(Me.TabControl_Main)
        Me.Font = New System.Drawing.Font("Calibri", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Name = "FrmMainEntry"
        Me.Text = "Data"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.TabControl_Main.ResumeLayout(False)
        Me.Tab_Entry.ResumeLayout(False)
        Me.TableLayoutPanel1.ResumeLayout(False)
        Me.TableLayoutPanel3.ResumeLayout(False)
        Me.TLP_Left.ResumeLayout(False)
        Me.Tab_Print.ResumeLayout(False)
        Me.TableLayoutPanel2.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents TabControl_Main As System.Windows.Forms.TabControl
    Friend WithEvents Tab_Entry As System.Windows.Forms.TabPage
    Friend WithEvents Tab_Print As System.Windows.Forms.TabPage
    Friend WithEvents ReportView As Microsoft.Reporting.WinForms.ReportViewer
    Friend WithEvents TableLayoutPanel1 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents TableLayoutPanel2 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents TLP_Left As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents TLP_Proof As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents TableLayoutPanel3 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents Btn_Submit As System.Windows.Forms.Button
    Friend WithEvents TableLayoutPanel4 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents TableLayoutPanel5 As System.Windows.Forms.TableLayoutPanel

End Class
