﻿Public Class DataLogic
    Friend Function SubmitData(ByRef ErrMsg As String) As Int32
        Dim iRc As Integer = 0
        Try

            iRc = 0
        Catch ex As Exception
            iRc = 1
            ErrMsg = ex.Message
        Finally
            SubmitData = iRc
        End Try
    End Function

End Class
