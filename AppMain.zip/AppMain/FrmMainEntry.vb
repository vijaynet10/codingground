﻿Public Class FrmMainEntry
    Private Sub Btn_Submit_Click(sender As Object, e As EventArgs) Handles Btn_Submit.Click
        Try





        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub
End Class
