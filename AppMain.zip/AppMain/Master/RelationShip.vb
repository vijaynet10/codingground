﻿Namespace Master
    Public Class RelationShip

    End Class
End Namespace