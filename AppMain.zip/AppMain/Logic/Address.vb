﻿Namespace DataModel
    Public Class Address
        Private _Data As New Data.AddressDataTable
        Friend ReadOnly Property Data As Data.AddressDataTable
            Get
                Return _Data
            End Get
        End Property
        Private _Address1 As String
        Friend Property Address1 As String
            Get
                Return _Address1
            End Get
            Set(value As String)
                _Address1 = value
            End Set
        End Property


        Private _Area As String
        Friend Property Area As String
            Get
                Return _Area
            End Get
            Set(value As String)
                _Area = value
            End Set
        End Property

    
        Private _DoorNo As String
        Friend Property DoorNo As String
            Get
                Return _DoorNo
            End Get
            Set(value As String)
                _DoorNo = value
            End Set
        End Property
        Private _District As String
        Friend Property District As String
            Get
                Return _District
            End Get
            Set(value As String)
                _District = value
            End Set
        End Property

        Private _Dated As Date
        Friend Property Dated As Date
            Get
                Return _Dated
            End Get
            Set(value As Date)
                _Dated = value
            End Set
        End Property


        Function Add(ByRef ErrMsg As String) As Int32
            Dim iRc As Integer = 0
            Try
                Dim NewRow As DataRow = Data.NewAddressRow
                NewRow(Data.Address1Column.ColumnName) = Me.Address1
                NewRow(Data.AreaColumn.ColumnName) = Me.Area
                NewRow(Data.DoorNoColumn.ColumnName) = Me.DoorNo
                NewRow(Data.DistrictColumn.ColumnName) = Me.District
                NewRow(Data.DateColumn.ColumnName) = Me.Dated
                Data.Rows.Add(NewRow)
                iRc = 0
            Catch ex As Exception
                iRc = 1
                ErrMsg = ex.Message
            Finally
                Add = iRc
            End Try
        End Function
    End Class
End Namespace