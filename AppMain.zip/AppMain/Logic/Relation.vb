﻿Namespace DataModel
    Public Class Relation

        Private _Data As New Data.RelationsDataTable
        Friend ReadOnly Property Data As Data.RelationsDataTable
            Get
                Return _Data
            End Get
        End Property

        Private _Name As String
        Friend Property Name As String
            Get
                Return _Name
            End Get
            Set(value As String)
                _Name = value
            End Set
        End Property


        Private _Age As Integer
        Friend Property Age As Integer
            Get
                Return _Age
            End Get
            Set(value As Integer)
                _Age = value
            End Set
        End Property

        Private _DOB As Date
        Friend Property DOB As Date
            Get
                Return _DOB
            End Get
            Set(value As Date)
                _DOB = value
            End Set
        End Property

        Private _AdhaarID As String
        Friend Property AdhaarID As String
            Get
                Return _AdhaarID
            End Get
            Set(value As String)
                _AdhaarID = value
            End Set
        End Property
        Private _Relationship As String
        Friend Property Relationship As String
            Get
                Return _Relationship
            End Get
            Set(value As String)
                _Relationship = value
            End Set
        End Property

        Function Add(ByRef ErrMsg As String) As Int32
            Dim iRc As Integer = 0
            Try
                Dim NewRow As DataRow = Data.NewRelationsRow
                NewRow(Data.NameColumn.ColumnName) = Me.Name
                NewRow(Data.RelationshipColumn.ColumnName) = Me.Relationship
                NewRow(Data.DateOfBirthColumn.ColumnName) = Me.DOB
                NewRow(Data.AadharNumberColumn.ColumnName) = Me.AdhaarID
                NewRow(Data.AgeColumn.ColumnName) = Me.Age
                Data.Rows.Add(NewRow)
                iRc = 0
            Catch ex As Exception
                iRc = 1
                ErrMsg = ex.Message
            Finally
                Add = iRc
            End Try
        End Function
    End Class
End Namespace