﻿Namespace DataModel
    Public Class FamilyLeader
        Private _Data As New Data.FamilyLeaderDataTable
        Friend ReadOnly Property Data As Data.FamilyLeaderDataTable
            Get
                Return _Data
            End Get
        End Property

        Private _OldVoterData As New VoterData
        Friend ReadOnly Property OldVoterData As VoterData
            Get
                Return _OldVoterData
            End Get
        End Property

        Private _NewVoterData As New VoterData
        Friend ReadOnly Property NewVoterData As VoterData
            Get
                Return _NewVoterData
            End Get
        End Property
        Private _OldFoodCard As New FoodCard
        Friend ReadOnly Property OldFoodCard As FoodCard
            Get
                Return _OldFoodCard
            End Get
        End Property

        Private _NewFoodCard As New FoodCard
        Friend ReadOnly Property NewFoodCard As FoodCard
            Get
                Return _NewFoodCard
            End Get
        End Property




        Function Add(ByRef ErrMsg As String) As Int32
            Dim iRc As Integer = 0
            Try
                Dim NewRow As DataRow = Data.NewFamilyLeaderRow

                NewRow(Data.NewVoterIdNoColumn.ColumnName) = Me.NewVoterData.VoterIdNo
                NewRow(Data.NewConstituencyColumn.ColumnName) = Me.NewVoterData.Constituency
                NewRow(Data.NewVoterIDIssuedDateColumn.ColumnName) = Me.NewVoterData.VoterIDIssuedDate


                NewRow(Data.OldVoterIdNoColumn.ColumnName) = Me.OldVoterData.VoterIdNo
                NewRow(Data.OldConstituencyColumn.ColumnName) = Me.OldVoterData.Constituency
                NewRow(Data.OldVoterIDIssuedDateColumn.ColumnName) = Me.OldVoterData.VoterIDIssuedDate

                
                Data.Rows.Add(NewRow)
                iRc = 0
            Catch ex As Exception
                iRc = 1
                ErrMsg = ex.Message
            Finally
                Add = iRc
            End Try
        End Function
    End Class

    Friend Class VoterData
        Private _VoterIdNo As String
        Friend Property VoterIdNo As String
            Get
                Return _VoterIdNo
            End Get
            Set(value As String)
                _VoterIdNo = value
            End Set
        End Property


        Private _VoterIDIssuedDate As Date
        Friend Property VoterIDIssuedDate As Date
            Get
                Return _VoterIDIssuedDate
            End Get
            Set(value As Date)
                _VoterIDIssuedDate = value
            End Set
        End Property


        Private _Constituency As String
        Friend Property Constituency As String
            Get
                Return _Constituency
            End Get
            Set(value As String)
                _Constituency = value
            End Set
        End Property

    End Class

    Friend Class FoodCard

        Private _ID As String
        Friend Property ID As String
            Get
                Return _ID
            End Get
            Set(value As String)
                _ID = value
            End Set
        End Property

        Private _IssuedDate As Date
        Friend Property IssuedDate As Date
            Get
                Return _IssuedDate
            End Get
            Set(value As Date)
                _IssuedDate = value
            End Set
        End Property

    End Class

End Namespace