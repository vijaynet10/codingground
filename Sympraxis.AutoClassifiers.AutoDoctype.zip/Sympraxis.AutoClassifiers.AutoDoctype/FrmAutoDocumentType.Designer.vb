﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FrmAutoDocumentType
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.TLP_Main = New System.Windows.Forms.TableLayoutPanel()
        Me.TLP_Main1 = New System.Windows.Forms.TableLayoutPanel()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.TLP_Entry = New System.Windows.Forms.TableLayoutPanel()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Txt_XmlPath = New System.Windows.Forms.TextBox()
        Me.Btn_LoadAutoDocType = New System.Windows.Forms.Button()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.TLP_Main.SuspendLayout()
        Me.TLP_Main1.SuspendLayout()
        Me.TLP_Entry.SuspendLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'TLP_Main
        '
        Me.TLP_Main.ColumnCount = 3
        Me.TLP_Main.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20.0!))
        Me.TLP_Main.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 60.0!))
        Me.TLP_Main.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20.0!))
        Me.TLP_Main.Controls.Add(Me.TLP_Main1, 1, 1)
        Me.TLP_Main.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TLP_Main.Location = New System.Drawing.Point(0, 0)
        Me.TLP_Main.Name = "TLP_Main"
        Me.TLP_Main.RowCount = 3
        Me.TLP_Main.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 15.0!))
        Me.TLP_Main.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 70.0!))
        Me.TLP_Main.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 15.0!))
        Me.TLP_Main.Size = New System.Drawing.Size(930, 558)
        Me.TLP_Main.TabIndex = 0
        '
        'TLP_Main1
        '
        Me.TLP_Main1.ColumnCount = 1
        Me.TLP_Main1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TLP_Main1.Controls.Add(Me.Label2, 0, 1)
        Me.TLP_Main1.Controls.Add(Me.TLP_Entry, 0, 0)
        Me.TLP_Main1.Controls.Add(Me.DataGridView1, 0, 2)
        Me.TLP_Main1.Controls.Add(Me.Button2, 0, 3)
        Me.TLP_Main1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TLP_Main1.Location = New System.Drawing.Point(189, 86)
        Me.TLP_Main1.Name = "TLP_Main1"
        Me.TLP_Main1.RowCount = 4
        Me.TLP_Main1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 14.07328!))
        Me.TLP_Main1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333333!))
        Me.TLP_Main1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 68.22916!))
        Me.TLP_Main1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 9.187865!))
        Me.TLP_Main1.Size = New System.Drawing.Size(552, 384)
        Me.TLP_Main1.TabIndex = 1
        '
        'Label2
        '
        Me.Label2.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(3, 62)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(546, 15)
        Me.Label2.TabIndex = 0
        Me.Label2.Text = "Auto Classifers AKA Compreno Page Type | OCR KeyWords"
        Me.Label2.UseMnemonic = False
        '
        'TLP_Entry
        '
        Me.TLP_Entry.ColumnCount = 3
        Me.TLP_Entry.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 11.77536!))
        Me.TLP_Entry.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 55.43478!))
        Me.TLP_Entry.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 32.97102!))
        Me.TLP_Entry.Controls.Add(Me.Label1, 0, 0)
        Me.TLP_Entry.Controls.Add(Me.Txt_XmlPath, 1, 0)
        Me.TLP_Entry.Controls.Add(Me.Btn_LoadAutoDocType, 2, 0)
        Me.TLP_Entry.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TLP_Entry.Location = New System.Drawing.Point(3, 3)
        Me.TLP_Entry.Name = "TLP_Entry"
        Me.TLP_Entry.RowCount = 1
        Me.TLP_Entry.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 15.10417!))
        Me.TLP_Entry.Size = New System.Drawing.Size(546, 48)
        Me.TLP_Entry.TabIndex = 0
        '
        'Label1
        '
        Me.Label1.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(3, 16)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(58, 15)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "File Path"
        '
        'Txt_XmlPath
        '
        Me.Txt_XmlPath.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Txt_XmlPath.Location = New System.Drawing.Point(67, 12)
        Me.Txt_XmlPath.Name = "Txt_XmlPath"
        Me.Txt_XmlPath.Size = New System.Drawing.Size(296, 23)
        Me.Txt_XmlPath.TabIndex = 1
        '
        'Btn_LoadAutoDocType
        '
        Me.Btn_LoadAutoDocType.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Btn_LoadAutoDocType.Location = New System.Drawing.Point(383, 3)
        Me.Btn_LoadAutoDocType.Name = "Btn_LoadAutoDocType"
        Me.Btn_LoadAutoDocType.Size = New System.Drawing.Size(145, 42)
        Me.Btn_LoadAutoDocType.TabIndex = 2
        Me.Btn_LoadAutoDocType.Text = "&Load Auto Doc Type"
        Me.Btn_LoadAutoDocType.UseVisualStyleBackColor = True
        '
        'DataGridView1
        '
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.DataGridView1.Location = New System.Drawing.Point(3, 89)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.Size = New System.Drawing.Size(546, 256)
        Me.DataGridView1.TabIndex = 1
        '
        'Button2
        '
        Me.Button2.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Button2.Location = New System.Drawing.Point(166, 351)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(219, 30)
        Me.Button2.TabIndex = 2
        Me.Button2.Text = "&Find Auto Document Type"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'FrmAutoDocumentType
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(930, 558)
        Me.Controls.Add(Me.TLP_Main)
        Me.Font = New System.Drawing.Font("Calibri", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Name = "FrmAutoDocumentType"
        Me.Text = "Auto Document Type"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.TLP_Main.ResumeLayout(False)
        Me.TLP_Main1.ResumeLayout(False)
        Me.TLP_Main1.PerformLayout()
        Me.TLP_Entry.ResumeLayout(False)
        Me.TLP_Entry.PerformLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents TLP_Main As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents TLP_Entry As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Txt_XmlPath As System.Windows.Forms.TextBox
    Friend WithEvents Btn_LoadAutoDocType As System.Windows.Forms.Button
    Friend WithEvents TLP_Main1 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents DataGridView1 As System.Windows.Forms.DataGridView
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents Label2 As System.Windows.Forms.Label

End Class
