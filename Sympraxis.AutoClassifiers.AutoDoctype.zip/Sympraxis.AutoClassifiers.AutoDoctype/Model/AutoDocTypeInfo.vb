﻿Imports System.Xml.Serialization
<XmlRoot(ElementName:="AutoDocTypeInfo")>
Public Class AutoDocTypeInfo
    <XmlElement(ElementName:="OCRKeyWordsInfo")> Public OCRKeyWordsInfo As New OCRKeyWordsInfo
    <XmlElement(ElementName:="AutoDocType")> Public AutoDocTypes As New List(Of AutoDocType)
End Class
Public Class Data
    Sub New()

    End Sub
    Private m_AutoDocTypes As List(Of AutoDocType)
    Public ReadOnly Property AutoDocTypes As List(Of AutoDocType)
        Get
            Return m_AutoDocTypes
        End Get
    End Property
    Private m_OCRKeyWordsInfo As OCRKeyWordsInfo
    Public ReadOnly Property OCRKeyWordsInfo As OCRKeyWordsInfo
        Get
            Return m_OCRKeyWordsInfo
        End Get
    End Property
    Friend Function BuildData(_OCRKeyWordsInfo As OCRKeyWordsInfo, _AutoDocTypes As List(Of AutoDocType)) As Int32
        Dim iRc As Int32 = 0
        Try
            m_OCRKeyWordsInfo = _OCRKeyWordsInfo : m_AutoDocTypes = _AutoDocTypes
            iRc = 0
        Catch ex As Exception
            iRc = -1
            Throw
        Finally
            BuildData = iRc
        End Try
    End Function
End Class