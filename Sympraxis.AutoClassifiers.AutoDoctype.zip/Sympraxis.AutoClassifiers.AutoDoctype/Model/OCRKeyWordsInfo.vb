﻿Imports System.Xml.Serialization
Public Class OCRKeyWordsInfo
    <XmlElement(ElementName:="OCRKeyWords")> Public OCRKeyWords As New List(Of OCRKeyWords)



End Class
Public Class OCRKeyWords
    <XmlAttribute(AttributeName:="PTR")> Public PTR As String = String.Empty
    <XmlElement(ElementName:="OCRKeyWord")> Public OCRKeyWords As New List(Of OCRKeyWord)
End Class
Public Class OCRKeyWord
    <XmlAttribute(AttributeName:="IgnorePgType")> Public IgnorePgType As String = String.Empty
    Public ReadOnly Property IgnorePgTypeSplitted As List(Of String)
        Get
            Return IgnorePgType.Split("|").ToList
        End Get
    End Property
    <XmlText()> Public Value As String = String.Empty
    Public ReadOnly Property ValueSplitted As List(Of String)
        Get
            Return Value.Split("|").ToList
        End Get
    End Property
End Class
