﻿Imports System.Xml.Serialization
<XmlRoot("AutoDocType")>
Public Class AutoDocType
    <XmlElement(ElementName:="DocType")> Public DocType As New DocType
    <XmlElement(ElementName:="ImgTypeInfo")> Public ImgTypeInfo As New ImgTypeInfo
End Class
Public Class DocType
    <XmlAttribute(AttributeName:="SrcId")> Public SrcId As String = String.Empty
    <XmlAttribute(AttributeName:="CS")> Public CS As String = String.Empty
    <XmlAttribute(AttributeName:="LOBType")> Public LOBType As String = String.Empty
    <XmlAttribute(AttributeName:="OCRPTR")> Public OCRPTR As String = String.Empty
    Public ReadOnly Property OCRPTRSplitted As List(Of String)
        Get
            Return OCRPTR.Split("|").ToList
        End Get
    End Property
    <XmlText()> Public Value As String = String.Empty
End Class
Public Class ImgTypeInfo
    <XmlElement(ElementName:="ImgType")> Public ImgTypes As New List(Of ImgType)
End Class
Public Class ImgType
    <XmlText()> Public Value As String = String.Empty
    Public ReadOnly Property ValueSplitted As List(Of String)
        Get
            Return Value.Split("|").ToList
        End Get
    End Property
    <XmlAttribute(AttributeName:="MinOccurs")> Public MinOccurs As String = "0"
    <XmlAttribute(AttributeName:="MaxOccurs")> Public MaxOccurs As String = "0"
End Class