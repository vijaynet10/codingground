﻿Public Class FrmAutoDocumentType
    Private MyAutoDocTypeInfo As New AutoDocTypeInfo

    Private Sub Btn_LoadAutoDocType_Click(sender As Object, e As EventArgs) Handles Btn_LoadAutoDocType.Click
        Dim FileName As String = String.Empty
        Try

            Using oOpenFileDialog As New OpenFileDialog
                With oOpenFileDialog
                    .InitialDirectory = Application.StartupPath
                    .CheckFileExists = True
                    .Filter = "XML Document|*.xml"
                    .Multiselect = False
                    Dim DialogResult As DialogResult = .ShowDialog(Me)
                    If DialogResult <> Windows.Forms.DialogResult.OK Then Return
                    FileName = .FileName
                End With
            End Using
            Dim StreamReader As New System.IO.StreamReader(FileName)
            'Dim XMLTextReader As Xml.XmlTextReader
            'XMLTextReader = Xml.XmlReader.Create(StreamReader)
            Dim XmlSerializer As New Xml.Serialization.XmlSerializer(GetType(AutoDocTypeInfo))
            MyAutoDocTypeInfo = XmlSerializer.Deserialize(StreamReader)
            Txt_XmlPath.Text = FileName









        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub
End Class
