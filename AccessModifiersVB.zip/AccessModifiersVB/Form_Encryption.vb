﻿Imports System.Text
Imports System.IO

Public Class Form_Encryption

    Dim oEncrypt As New Encrypt
    Dim oDecrypt As New Decrypt

    Dim Dt_Encoder As DataTable

    Public Structure Columns
        Public Structure Encoder
            Public Shared ReadOnly EncoderName As String = "EncoderName"
            Public Shared ReadOnly Encoder As String = "Encoder"
        End Structure
    End Structure
    Function BuildEncoder() As Boolean
        Try
            Dt_Encoder = New DataTable
            Dt_Encoder.Columns.Add(Columns.Encoder.EncoderName, GetType(String))
            Dt_Encoder.Columns.Add(Columns.Encoder.Encoder, GetType(Encoding))

            With Dt_Encoder
                .Rows.Add({"ASCII", UnicodeEncoding.ASCII})
                .Rows.Add({"BigEndianUnicode", UnicodeEncoding.BigEndianUnicode})
                .Rows.Add({"Default", UnicodeEncoding.Default})
                .Rows.Add({"Unicode", UnicodeEncoding.Unicode})
                .Rows.Add({"UTF32", UnicodeEncoding.UTF32})
                .Rows.Add({"UTF7", UnicodeEncoding.UTF7})
                .Rows.Add({"UTF8", UnicodeEncoding.UTF8})
            End With
            With CBO_EncryptEncoder
                .DataSource = Dt_Encoder
                .DisplayMember = Columns.Encoder.EncoderName
                .ValueMember = Columns.Encoder.Encoder
            End With
            With CBO_DecryptEncoder
                .DataSource = Dt_Encoder.Copy
                .DisplayMember = Columns.Encoder.EncoderName
                .ValueMember = Columns.Encoder.Encoder
            End With

            Return True
        Catch ex As Exception
            Throw
        End Try
    End Function

    Private Sub Btn_Encrypt_Click(sender As Object, e As EventArgs) Handles Btn_Encrypt.Click
        Try
            oEncrypt.InputValue = Text_EValue.Text
            Dim oString As String = oEncrypt.Encrypt()
            Text_DValue.Text = oString
            Dim FileName As String = Application.StartupPath & "\Encrypt.txt"
            Using File As IO.StreamWriter = New IO.StreamWriter(FileName, False, CType(CBO_EncryptEncoder.SelectedValue, Encoding))
                File.WriteLine(oString)
                File.Close()
            End Using

            Dim FileEncodingType As Encoding = GetFileEncoding(FileName)


            Select Case FileEncodingType.BodyName
                Case UnicodeEncoding.ASCII.BodyName
                    LblEncodeType.Text = "ASCII"
                Case UnicodeEncoding.BigEndianUnicode.BodyName
                    LblEncodeType.Text = "BigEndianUnicode"
                Case UnicodeEncoding.Default.BodyName
                    LblEncodeType.Text = "default"

                Case UnicodeEncoding.Unicode.BodyName
                    LblEncodeType.Text = "Unicode"
                Case UnicodeEncoding.UTF32.BodyName
                    LblEncodeType.Text = "UTF32"

                Case UnicodeEncoding.UTF7.BodyName
                    LblEncodeType.Text = "UTF7"

                Case UnicodeEncoding.UTF8.BodyName
                    LblEncodeType.Text = "UTF8"

                Case Else
                    LblEncodeType.Text = "none of the Encoding matched"
            End Select



        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub
    Private Sub Btn_Decrypt_Click(sender As Object, e As EventArgs) Handles Btn_Decrypt.Click
        Try
            Dim FileName As String = Application.StartupPath & "\Encrypt.txt"
            If IO.File.Exists(FileName) = False Then Throw New Exception("Input file   not  found " & FileName)
            Using FileReader As IO.StreamReader = New StreamReader(FileName, CType(CBO_DecryptEncoder.SelectedValue, Encoding))
                oDecrypt.InputValue = FileReader.ReadLine()
                FileReader.Close()

            End Using
            Me.Text_Decryptoutput.Text = oDecrypt.Decrypt

        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub
    Public Function GetFileEncoding(filePath As String) As Encoding
        Using sr As StreamReader = New StreamReader(filePath, True)
            sr.Read()
            Return sr.CurrentEncoding
        End Using
    End Function

    Public Sub New()
        InitializeComponent()
        BuildEncoder()
    End Sub
End Class
Class Encrypt
    Public InputValue As String
    Public OutPutValue As String
    Public Function Encrypt() As String
        Try
            OutPutValue = String.Empty
            If InputValue.Length <= 0 Then Throw New Exception("Invalid Input")
            For Each [Char] As Char In InputValue
                Dim ASCII As Integer = Asc([Char])
                OutPutValue &= Chr(Math.Round((ASCII * 5 / 3)))
            Next
            OutPutValue = StrReverse(OutPutValue)
            Return OutPutValue
            Return True
        Catch ex As Exception
            Throw
        End Try
    End Function
End Class
Class Decrypt
    Public InputValue As String
    Public OutPutValue As String
    Public Function Decrypt() As String
        Try
            OutPutValue = String.Empty
            If InputValue.Length <= 0 Then Throw New Exception("Invalid Input")
            For Each [Char] As Char In InputValue
                Dim ASCII As Integer = Asc([Char])
                OutPutValue &= Chr(Math.Round((ASCII * 3 / 5)))
            Next
            OutPutValue = StrReverse(OutPutValue)
            Return OutPutValue
            Return True
        Catch ex As Exception
            Throw
        End Try
    End Function
End Class
