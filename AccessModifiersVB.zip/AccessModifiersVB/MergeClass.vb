﻿Public Class MergeClass
    Dim oHashtable As New Hashtable

    Function HashMe(Key As String, Value As String) As Boolean
        Try

            If oHashtable.ContainsKey(Key) Then
                Dim oValue As Value = oHashtable.Item(Key)
                oValue.Name.Add(Value)

            Else
                Dim oValue As New Value
                oValue.Name.Add(Value)
                oHashtable.Add(Key, oValue)
            End If
            Return True
        Catch ex As Exception
            Throw
        End Try
    End Function
End Class
Class Value
    Public Name As New List(Of String)
    Public ReadOnly Property Count As Integer
        Get
            Return Name.Count
        End Get
    End Property
End Class


