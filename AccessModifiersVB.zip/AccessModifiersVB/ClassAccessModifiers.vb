﻿Public Class ClassAccessModifiers
    ''' <summary>
    ''' Shared Variables
    ''' </summary>
    ''' <remarks></remarks>
    Private Shared vShared_Private_Name As String
    Friend Shared vShared_Friend_Name As String
    Public Shared vShared_Public_Name As String
    Private vprivate_Name As String
    Friend vFriend_Name As String
    Public vPublic_Name As String
    Friend Shared Function ADD()
        vShared_Friend_Name = 0
    End Function



End Class
