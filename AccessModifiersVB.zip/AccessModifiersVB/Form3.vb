﻿Public Class Form3

    Dim oMergeClass As New MergeClass
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Btn_Addme.Click
        Try
            oMergeClass.HashMe(TxtName.Text, TxtTrackID.Text)
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub
End Class