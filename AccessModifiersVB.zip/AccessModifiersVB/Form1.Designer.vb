﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.TLP_main = New System.Windows.Forms.TableLayoutPanel()
        Me.GroupBox4 = New System.Windows.Forms.GroupBox()
        Me.Btn_outB = New System.Windows.Forms.Button()
        Me.GroupBox5 = New System.Windows.Forms.GroupBox()
        Me.txt_B_Out_Shared_Public_Name = New System.Windows.Forms.TextBox()
        Me.txt_B_Out_Public_Name = New System.Windows.Forms.TextBox()
        Me.txt_B_Out_Friend_Name = New System.Windows.Forms.TextBox()
        Me.txt_B_Out_Shared_Friend_Name = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Button_ObjB = New System.Windows.Forms.Button()
        Me.GroupBox6 = New System.Windows.Forms.GroupBox()
        Me.txt_B_In_Shared_Public_Name = New System.Windows.Forms.TextBox()
        Me.txt_B_In_Public_Name = New System.Windows.Forms.TextBox()
        Me.txt_B_In_Shared_Friend_Name = New System.Windows.Forms.TextBox()
        Me.txt_B_In_Friend_Name = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.Button_ObjA_Out = New System.Windows.Forms.Button()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.txt_A_Out_Shared_Public_Name = New System.Windows.Forms.TextBox()
        Me.txt_A_Out_Public_Name = New System.Windows.Forms.TextBox()
        Me.txt_A_Out_Shared_Friend_Name = New System.Windows.Forms.TextBox()
        Me.txt_A_Out_Friend_Name = New System.Windows.Forms.TextBox()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Button_ObjA_In = New System.Windows.Forms.Button()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.txt_A_In_Shared_Public_Name = New System.Windows.Forms.TextBox()
        Me.txt_A_In_Shared_Friend_Name = New System.Windows.Forms.TextBox()
        Me.txt_A_In_Public_Name = New System.Windows.Forms.TextBox()
        Me.txt_A_In_Friend_Name = New System.Windows.Forms.TextBox()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.TLP_main.SuspendLayout()
        Me.GroupBox4.SuspendLayout()
        Me.GroupBox5.SuspendLayout()
        Me.GroupBox6.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.SuspendLayout()
        '
        'TLP_main
        '
        Me.TLP_main.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.[Single]
        Me.TLP_main.ColumnCount = 1
        Me.TLP_main.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TLP_main.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        Me.TLP_main.Controls.Add(Me.GroupBox4, 0, 1)
        Me.TLP_main.Controls.Add(Me.GroupBox1, 0, 0)
        Me.TLP_main.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TLP_main.Location = New System.Drawing.Point(0, 0)
        Me.TLP_main.Name = "TLP_main"
        Me.TLP_main.Padding = New System.Windows.Forms.Padding(25)
        Me.TLP_main.RowCount = 2
        Me.TLP_main.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TLP_main.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TLP_main.Size = New System.Drawing.Size(876, 525)
        Me.TLP_main.TabIndex = 0
        '
        'GroupBox4
        '
        Me.GroupBox4.Controls.Add(Me.Btn_outB)
        Me.GroupBox4.Controls.Add(Me.GroupBox5)
        Me.GroupBox4.Controls.Add(Me.Button_ObjB)
        Me.GroupBox4.Controls.Add(Me.GroupBox6)
        Me.GroupBox4.Dock = System.Windows.Forms.DockStyle.Fill
        Me.GroupBox4.Location = New System.Drawing.Point(41, 278)
        Me.GroupBox4.Margin = New System.Windows.Forms.Padding(15)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Size = New System.Drawing.Size(794, 206)
        Me.GroupBox4.TabIndex = 1
        Me.GroupBox4.TabStop = False
        Me.GroupBox4.Text = "Object B"
        '
        'Btn_outB
        '
        Me.Btn_outB.Location = New System.Drawing.Point(342, 110)
        Me.Btn_outB.Name = "Btn_outB"
        Me.Btn_outB.Size = New System.Drawing.Size(68, 32)
        Me.Btn_outB.TabIndex = 3
        Me.Btn_outB.Text = "Out B"
        Me.Btn_outB.UseVisualStyleBackColor = True
        '
        'GroupBox5
        '
        Me.GroupBox5.Controls.Add(Me.txt_B_Out_Shared_Public_Name)
        Me.GroupBox5.Controls.Add(Me.txt_B_Out_Public_Name)
        Me.GroupBox5.Controls.Add(Me.txt_B_Out_Friend_Name)
        Me.GroupBox5.Controls.Add(Me.txt_B_Out_Shared_Friend_Name)
        Me.GroupBox5.Controls.Add(Me.Label5)
        Me.GroupBox5.Controls.Add(Me.Label6)
        Me.GroupBox5.Controls.Add(Me.Label16)
        Me.GroupBox5.Controls.Add(Me.Label15)
        Me.GroupBox5.Location = New System.Drawing.Point(446, 19)
        Me.GroupBox5.Name = "GroupBox5"
        Me.GroupBox5.Size = New System.Drawing.Size(313, 169)
        Me.GroupBox5.TabIndex = 2
        Me.GroupBox5.TabStop = False
        Me.GroupBox5.Text = "Output"
        '
        'txt_B_Out_Shared_Public_Name
        '
        Me.txt_B_Out_Shared_Public_Name.Location = New System.Drawing.Point(155, 138)
        Me.txt_B_Out_Shared_Public_Name.Name = "txt_B_Out_Shared_Public_Name"
        Me.txt_B_Out_Shared_Public_Name.Size = New System.Drawing.Size(117, 20)
        Me.txt_B_Out_Shared_Public_Name.TabIndex = 1
        '
        'txt_B_Out_Public_Name
        '
        Me.txt_B_Out_Public_Name.Location = New System.Drawing.Point(155, 75)
        Me.txt_B_Out_Public_Name.Name = "txt_B_Out_Public_Name"
        Me.txt_B_Out_Public_Name.Size = New System.Drawing.Size(117, 20)
        Me.txt_B_Out_Public_Name.TabIndex = 1
        '
        'txt_B_Out_Friend_Name
        '
        Me.txt_B_Out_Friend_Name.Location = New System.Drawing.Point(155, 36)
        Me.txt_B_Out_Friend_Name.Name = "txt_B_Out_Friend_Name"
        Me.txt_B_Out_Friend_Name.Size = New System.Drawing.Size(117, 20)
        Me.txt_B_Out_Friend_Name.TabIndex = 1
        '
        'txt_B_Out_Shared_Friend_Name
        '
        Me.txt_B_Out_Shared_Friend_Name.Location = New System.Drawing.Point(155, 107)
        Me.txt_B_Out_Shared_Friend_Name.Name = "txt_B_Out_Shared_Friend_Name"
        Me.txt_B_Out_Shared_Friend_Name.Size = New System.Drawing.Size(117, 20)
        Me.txt_B_Out_Shared_Friend_Name.TabIndex = 1
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(17, 75)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(76, 13)
        Me.Label5.TabIndex = 0
        Me.Label5.Text = "vPublic_Name"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(17, 43)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(76, 13)
        Me.Label6.TabIndex = 0
        Me.Label6.Text = "vFriend_Name"
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(17, 145)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(110, 13)
        Me.Label16.TabIndex = 0
        Me.Label16.Text = "vSharedPublic_Name"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(17, 114)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(110, 13)
        Me.Label15.TabIndex = 0
        Me.Label15.Text = "vSharedFriend_Name"
        '
        'Button_ObjB
        '
        Me.Button_ObjB.Location = New System.Drawing.Point(341, 55)
        Me.Button_ObjB.Name = "Button_ObjB"
        Me.Button_ObjB.Size = New System.Drawing.Size(69, 29)
        Me.Button_ObjB.TabIndex = 1
        Me.Button_ObjB.Text = "In B"
        Me.Button_ObjB.UseVisualStyleBackColor = True
        '
        'GroupBox6
        '
        Me.GroupBox6.Controls.Add(Me.txt_B_In_Shared_Public_Name)
        Me.GroupBox6.Controls.Add(Me.txt_B_In_Public_Name)
        Me.GroupBox6.Controls.Add(Me.txt_B_In_Shared_Friend_Name)
        Me.GroupBox6.Controls.Add(Me.txt_B_In_Friend_Name)
        Me.GroupBox6.Controls.Add(Me.Label7)
        Me.GroupBox6.Controls.Add(Me.Label8)
        Me.GroupBox6.Controls.Add(Me.Label14)
        Me.GroupBox6.Controls.Add(Me.Label13)
        Me.GroupBox6.Location = New System.Drawing.Point(18, 22)
        Me.GroupBox6.Name = "GroupBox6"
        Me.GroupBox6.Size = New System.Drawing.Size(294, 166)
        Me.GroupBox6.TabIndex = 0
        Me.GroupBox6.TabStop = False
        Me.GroupBox6.Text = "Input"
        '
        'txt_B_In_Shared_Public_Name
        '
        Me.txt_B_In_Shared_Public_Name.Location = New System.Drawing.Point(161, 130)
        Me.txt_B_In_Shared_Public_Name.Name = "txt_B_In_Shared_Public_Name"
        Me.txt_B_In_Shared_Public_Name.Size = New System.Drawing.Size(120, 20)
        Me.txt_B_In_Shared_Public_Name.TabIndex = 1
        '
        'txt_B_In_Public_Name
        '
        Me.txt_B_In_Public_Name.Location = New System.Drawing.Point(160, 56)
        Me.txt_B_In_Public_Name.Name = "txt_B_In_Public_Name"
        Me.txt_B_In_Public_Name.Size = New System.Drawing.Size(116, 20)
        Me.txt_B_In_Public_Name.TabIndex = 1
        '
        'txt_B_In_Shared_Friend_Name
        '
        Me.txt_B_In_Shared_Friend_Name.Location = New System.Drawing.Point(160, 92)
        Me.txt_B_In_Shared_Friend_Name.Name = "txt_B_In_Shared_Friend_Name"
        Me.txt_B_In_Shared_Friend_Name.Size = New System.Drawing.Size(120, 20)
        Me.txt_B_In_Shared_Friend_Name.TabIndex = 1
        '
        'txt_B_In_Friend_Name
        '
        Me.txt_B_In_Friend_Name.Location = New System.Drawing.Point(160, 28)
        Me.txt_B_In_Friend_Name.Name = "txt_B_In_Friend_Name"
        Me.txt_B_In_Friend_Name.Size = New System.Drawing.Size(116, 20)
        Me.txt_B_In_Friend_Name.TabIndex = 1
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(14, 62)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(76, 13)
        Me.Label7.TabIndex = 0
        Me.Label7.Text = "vPublic_Name"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(14, 31)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(76, 13)
        Me.Label8.TabIndex = 0
        Me.Label8.Text = "vFriend_Name"
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(15, 130)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(116, 13)
        Me.Label14.TabIndex = 0
        Me.Label14.Text = "vShared_Public_Name"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(15, 95)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(116, 13)
        Me.Label13.TabIndex = 0
        Me.Label13.Text = "vShared_Friend_Name"
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.Button_ObjA_Out)
        Me.GroupBox1.Controls.Add(Me.GroupBox2)
        Me.GroupBox1.Controls.Add(Me.Button_ObjA_In)
        Me.GroupBox1.Controls.Add(Me.GroupBox3)
        Me.GroupBox1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.GroupBox1.Location = New System.Drawing.Point(41, 41)
        Me.GroupBox1.Margin = New System.Windows.Forms.Padding(15)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(794, 206)
        Me.GroupBox1.TabIndex = 0
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Object A"
        '
        'Button_ObjA_Out
        '
        Me.Button_ObjA_Out.Location = New System.Drawing.Point(341, 112)
        Me.Button_ObjA_Out.Name = "Button_ObjA_Out"
        Me.Button_ObjA_Out.Size = New System.Drawing.Size(77, 30)
        Me.Button_ObjA_Out.TabIndex = 3
        Me.Button_ObjA_Out.Text = "Out A"
        Me.Button_ObjA_Out.UseVisualStyleBackColor = True
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.txt_A_Out_Shared_Public_Name)
        Me.GroupBox2.Controls.Add(Me.txt_A_Out_Public_Name)
        Me.GroupBox2.Controls.Add(Me.txt_A_Out_Shared_Friend_Name)
        Me.GroupBox2.Controls.Add(Me.txt_A_Out_Friend_Name)
        Me.GroupBox2.Controls.Add(Me.Label12)
        Me.GroupBox2.Controls.Add(Me.Label3)
        Me.GroupBox2.Controls.Add(Me.Label11)
        Me.GroupBox2.Controls.Add(Me.Label4)
        Me.GroupBox2.Location = New System.Drawing.Point(446, 19)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(313, 183)
        Me.GroupBox2.TabIndex = 2
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Output"
        '
        'txt_A_Out_Shared_Public_Name
        '
        Me.txt_A_Out_Shared_Public_Name.Location = New System.Drawing.Point(155, 126)
        Me.txt_A_Out_Shared_Public_Name.Name = "txt_A_Out_Shared_Public_Name"
        Me.txt_A_Out_Shared_Public_Name.Size = New System.Drawing.Size(117, 20)
        Me.txt_A_Out_Shared_Public_Name.TabIndex = 1
        '
        'txt_A_Out_Public_Name
        '
        Me.txt_A_Out_Public_Name.Location = New System.Drawing.Point(155, 64)
        Me.txt_A_Out_Public_Name.Name = "txt_A_Out_Public_Name"
        Me.txt_A_Out_Public_Name.Size = New System.Drawing.Size(117, 20)
        Me.txt_A_Out_Public_Name.TabIndex = 1
        '
        'txt_A_Out_Shared_Friend_Name
        '
        Me.txt_A_Out_Shared_Friend_Name.Location = New System.Drawing.Point(155, 95)
        Me.txt_A_Out_Shared_Friend_Name.Name = "txt_A_Out_Shared_Friend_Name"
        Me.txt_A_Out_Shared_Friend_Name.Size = New System.Drawing.Size(117, 20)
        Me.txt_A_Out_Shared_Friend_Name.TabIndex = 1
        '
        'txt_A_Out_Friend_Name
        '
        Me.txt_A_Out_Friend_Name.Location = New System.Drawing.Point(155, 31)
        Me.txt_A_Out_Friend_Name.Name = "txt_A_Out_Friend_Name"
        Me.txt_A_Out_Friend_Name.Size = New System.Drawing.Size(117, 20)
        Me.txt_A_Out_Friend_Name.TabIndex = 1
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(17, 133)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(110, 13)
        Me.Label12.TabIndex = 0
        Me.Label12.Text = "vSharedPublic_Name"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(17, 67)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(76, 13)
        Me.Label3.TabIndex = 0
        Me.Label3.Text = "vPublic_Name"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(17, 102)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(110, 13)
        Me.Label11.TabIndex = 0
        Me.Label11.Text = "vSharedFriend_Name"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(17, 31)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(76, 13)
        Me.Label4.TabIndex = 0
        Me.Label4.Text = "vFriend_Name"
        '
        'Button_ObjA_In
        '
        Me.Button_ObjA_In.Location = New System.Drawing.Point(340, 63)
        Me.Button_ObjA_In.Name = "Button_ObjA_In"
        Me.Button_ObjA_In.Size = New System.Drawing.Size(78, 34)
        Me.Button_ObjA_In.TabIndex = 1
        Me.Button_ObjA_In.Text = "In A"
        Me.Button_ObjA_In.UseVisualStyleBackColor = True
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.txt_A_In_Shared_Public_Name)
        Me.GroupBox3.Controls.Add(Me.txt_A_In_Shared_Friend_Name)
        Me.GroupBox3.Controls.Add(Me.txt_A_In_Public_Name)
        Me.GroupBox3.Controls.Add(Me.txt_A_In_Friend_Name)
        Me.GroupBox3.Controls.Add(Me.Label10)
        Me.GroupBox3.Controls.Add(Me.Label9)
        Me.GroupBox3.Controls.Add(Me.Label2)
        Me.GroupBox3.Controls.Add(Me.Label1)
        Me.GroupBox3.Location = New System.Drawing.Point(18, 19)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(294, 183)
        Me.GroupBox3.TabIndex = 0
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Input"
        '
        'txt_A_In_Shared_Public_Name
        '
        Me.txt_A_In_Shared_Public_Name.Location = New System.Drawing.Point(128, 133)
        Me.txt_A_In_Shared_Public_Name.Name = "txt_A_In_Shared_Public_Name"
        Me.txt_A_In_Shared_Public_Name.Size = New System.Drawing.Size(120, 20)
        Me.txt_A_In_Shared_Public_Name.TabIndex = 1
        '
        'txt_A_In_Shared_Friend_Name
        '
        Me.txt_A_In_Shared_Friend_Name.Location = New System.Drawing.Point(127, 95)
        Me.txt_A_In_Shared_Friend_Name.Name = "txt_A_In_Shared_Friend_Name"
        Me.txt_A_In_Shared_Friend_Name.Size = New System.Drawing.Size(120, 20)
        Me.txt_A_In_Shared_Friend_Name.TabIndex = 1
        '
        'txt_A_In_Public_Name
        '
        Me.txt_A_In_Public_Name.Location = New System.Drawing.Point(128, 60)
        Me.txt_A_In_Public_Name.Name = "txt_A_In_Public_Name"
        Me.txt_A_In_Public_Name.Size = New System.Drawing.Size(120, 20)
        Me.txt_A_In_Public_Name.TabIndex = 1
        '
        'txt_A_In_Friend_Name
        '
        Me.txt_A_In_Friend_Name.Location = New System.Drawing.Point(128, 24)
        Me.txt_A_In_Friend_Name.Name = "txt_A_In_Friend_Name"
        Me.txt_A_In_Friend_Name.Size = New System.Drawing.Size(120, 20)
        Me.txt_A_In_Friend_Name.TabIndex = 1
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(6, 133)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(116, 13)
        Me.Label10.TabIndex = 0
        Me.Label10.Text = "vShared_Public_Name"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(6, 98)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(116, 13)
        Me.Label9.TabIndex = 0
        Me.Label9.Text = "vShared_Friend_Name"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(6, 63)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(76, 13)
        Me.Label2.TabIndex = 0
        Me.Label2.Text = "vPublic_Name"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(6, 27)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(76, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "vFriend_Name"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(876, 525)
        Me.Controls.Add(Me.TLP_main)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.TLP_main.ResumeLayout(False)
        Me.GroupBox4.ResumeLayout(False)
        Me.GroupBox5.ResumeLayout(False)
        Me.GroupBox5.PerformLayout()
        Me.GroupBox6.ResumeLayout(False)
        Me.GroupBox6.PerformLayout()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents TLP_main As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents Button_ObjA_In As System.Windows.Forms.Button
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents GroupBox4 As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox5 As System.Windows.Forms.GroupBox
    Friend WithEvents txt_B_Out_Public_Name As System.Windows.Forms.TextBox
    Friend WithEvents txt_B_Out_Friend_Name As System.Windows.Forms.TextBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Button_ObjB As System.Windows.Forms.Button
    Friend WithEvents GroupBox6 As System.Windows.Forms.GroupBox
    Friend WithEvents txt_B_In_Public_Name As System.Windows.Forms.TextBox
    Friend WithEvents txt_B_In_Friend_Name As System.Windows.Forms.TextBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents txt_A_Out_Public_Name As System.Windows.Forms.TextBox
    Friend WithEvents txt_A_Out_Friend_Name As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents txt_A_In_Public_Name As System.Windows.Forms.TextBox
    Friend WithEvents txt_A_In_Friend_Name As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents txt_A_In_Shared_Public_Name As System.Windows.Forms.TextBox
    Friend WithEvents txt_A_In_Shared_Friend_Name As System.Windows.Forms.TextBox
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents txt_A_Out_Shared_Public_Name As System.Windows.Forms.TextBox
    Friend WithEvents txt_A_Out_Shared_Friend_Name As System.Windows.Forms.TextBox
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents txt_B_Out_Shared_Public_Name As System.Windows.Forms.TextBox
    Friend WithEvents txt_B_Out_Shared_Friend_Name As System.Windows.Forms.TextBox
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents txt_B_In_Shared_Public_Name As System.Windows.Forms.TextBox
    Friend WithEvents txt_B_In_Shared_Friend_Name As System.Windows.Forms.TextBox
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents Button_ObjA_Out As System.Windows.Forms.Button
    Friend WithEvents Btn_outB As System.Windows.Forms.Button

End Class
