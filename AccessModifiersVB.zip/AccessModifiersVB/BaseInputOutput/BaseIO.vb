﻿Namespace BaseIOs
    Public Class BaseIO
        Sub New()

        End Sub
    End Class
End Namespace