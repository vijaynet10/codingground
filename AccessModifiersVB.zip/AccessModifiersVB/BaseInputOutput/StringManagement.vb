﻿Namespace BaseIOs
    Public Class StringManagement
        Implements IBaseIO
        Private _IOs As New List(Of BaseIO)
        Public ReadOnly Property IOs As List(Of BaseIO) Implements IBaseIO.IOs
            Get
                Return _IOs
            End Get
        End Property
        Public Function Initialize() As Result Implements IBaseIO.Initialize

        End Function


    End Class
End Namespace