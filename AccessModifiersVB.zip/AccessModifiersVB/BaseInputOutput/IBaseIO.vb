﻿Namespace BaseIOs
    Public Interface IBaseIO
        ReadOnly Property IOs As List(Of BaseIO)
        Function Initialize() As Result
    End Interface
End Namespace