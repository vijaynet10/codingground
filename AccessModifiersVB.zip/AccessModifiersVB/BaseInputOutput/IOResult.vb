﻿Namespace BaseIOs
    Public Enum EnumResut
        Succeeded = 1
        Failed = 0
    End Enum
    Public NotInheritable Class Result
        Private _ex As Exception
        Private _Error As [Error]
        Public ReadOnly Property [Error] As [Error]
            Get
                Return _Error
            End Get
        End Property
        Private [_Result] As EnumResut = EnumResut.Failed
        Public ReadOnly Property [Result] As EnumResut
            Get
                Return [_Result]
            End Get
        End Property

        Private [_Value] As Object
        Public ReadOnly Property Value As Object
            Get
                Return [_Value]
            End Get
        End Property
        Sub New(aResult As EnumResut, aValue As Object)
            [_Result] = aResult : [_Value] = aValue
        End Sub
        Sub New(aEx As Exception)
            [_Result] = EnumResut.Failed
            _ex = aEx
            _Error = New [Error](_ex)
        End Sub
    End Class
    Public NotInheritable Class [Error]
        Private [_InnerError] As [Error]
        Public ReadOnly Property [InnerError] As [Error]
            Get
                Return [_InnerError]
            End Get
        End Property
        Private _Ex As Exception
        Public ReadOnly Property Message As String
            Get
                If IsNothing(_Ex) Then Return ""
                Return _Ex.Message
            End Get
        End Property
        Public ReadOnly Property StackTrace As String
            Get
                If IsNothing(_Ex) Then Return ""
                If IsNothing(_Ex.StackTrace) Then Return ""
                Return _Ex.Message
            End Get
        End Property
        Public ReadOnly Property Source As String
            Get
                If IsNothing(_Ex) Then Return ""
                If IsNothing(_Ex.Source) Then Return ""
                Return _Ex.Source
            End Get
        End Property
        Public ReadOnly Property HelpLink As String
            Get
                If IsNothing(_Ex) Then Return ""
                If IsNothing(_Ex.HelpLink) Then Return ""
                Return _Ex.HelpLink
            End Get
        End Property
        Sub New(aEx As Exception)
            _Ex = aEx
            If IsNothing(_Ex) Then
                [_InnerError] = New [Error](Nothing)
            Else
                [_InnerError] = New [Error](_Ex.InnerException)
            End If
        End Sub
    End Class
End Namespace