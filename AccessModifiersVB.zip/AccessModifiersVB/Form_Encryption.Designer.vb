﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form_Encryption
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.TLP_Main = New System.Windows.Forms.TableLayoutPanel()
        Me.Text_Decryptoutput = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Text_EValue = New System.Windows.Forms.TextBox()
        Me.Btn_Encrypt = New System.Windows.Forms.Button()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Text_DValue = New System.Windows.Forms.TextBox()
        Me.Btn_Decrypt = New System.Windows.Forms.Button()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.CBO_EncryptEncoder = New System.Windows.Forms.ComboBox()
        Me.CBO_DecryptEncoder = New System.Windows.Forms.ComboBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.LblEncodeType = New System.Windows.Forms.Label()
        Me.TLP_Main.SuspendLayout()
        Me.SuspendLayout()
        '
        'TLP_Main
        '
        Me.TLP_Main.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.TLP_Main.ColumnCount = 4
        Me.TLP_Main.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 13.86431!))
        Me.TLP_Main.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 27.53196!))
        Me.TLP_Main.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.43166!))
        Me.TLP_Main.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25.04924!))
        Me.TLP_Main.Controls.Add(Me.Label1, 0, 0)
        Me.TLP_Main.Controls.Add(Me.Text_EValue, 2, 0)
        Me.TLP_Main.Controls.Add(Me.Btn_Encrypt, 3, 0)
        Me.TLP_Main.Controls.Add(Me.Label2, 0, 2)
        Me.TLP_Main.Controls.Add(Me.Text_DValue, 2, 2)
        Me.TLP_Main.Controls.Add(Me.Btn_Decrypt, 3, 2)
        Me.TLP_Main.Controls.Add(Me.Label3, 0, 3)
        Me.TLP_Main.Controls.Add(Me.CBO_EncryptEncoder, 1, 0)
        Me.TLP_Main.Controls.Add(Me.CBO_DecryptEncoder, 1, 2)
        Me.TLP_Main.Controls.Add(Me.Label4, 1, 1)
        Me.TLP_Main.Controls.Add(Me.LblEncodeType, 2, 1)
        Me.TLP_Main.Controls.Add(Me.Text_Decryptoutput, 2, 3)
        Me.TLP_Main.Location = New System.Drawing.Point(103, 140)
        Me.TLP_Main.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.TLP_Main.Name = "TLP_Main"
        Me.TLP_Main.RowCount = 4
        Me.TLP_Main.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20.0!))
        Me.TLP_Main.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20.0!))
        Me.TLP_Main.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20.0!))
        Me.TLP_Main.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20.0!))
        Me.TLP_Main.Size = New System.Drawing.Size(1017, 260)
        Me.TLP_Main.TabIndex = 0
        '
        'Text_Decryptoutput
        '
        Me.Text_Decryptoutput.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Text_Decryptoutput.Location = New System.Drawing.Point(425, 214)
        Me.Text_Decryptoutput.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.Text_Decryptoutput.Name = "Text_Decryptoutput"
        Me.Text_Decryptoutput.Size = New System.Drawing.Size(332, 27)
        Me.Text_Decryptoutput.TabIndex = 1
        '
        'Label1
        '
        Me.Label1.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(4, 23)
        Me.Label1.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(133, 19)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "To Encrypt"
        '
        'Text_EValue
        '
        Me.Text_EValue.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Text_EValue.Location = New System.Drawing.Point(425, 19)
        Me.Text_EValue.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.Text_EValue.Name = "Text_EValue"
        Me.Text_EValue.Size = New System.Drawing.Size(332, 27)
        Me.Text_EValue.TabIndex = 1
        '
        'Btn_Encrypt
        '
        Me.Btn_Encrypt.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Btn_Encrypt.Location = New System.Drawing.Point(833, 9)
        Me.Btn_Encrypt.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.Btn_Encrypt.Name = "Btn_Encrypt"
        Me.Btn_Encrypt.Size = New System.Drawing.Size(111, 47)
        Me.Btn_Encrypt.TabIndex = 2
        Me.Btn_Encrypt.Text = "&Encrypt"
        Me.Btn_Encrypt.UseVisualStyleBackColor = True
        '
        'Label2
        '
        Me.Label2.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(4, 153)
        Me.Label2.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(133, 19)
        Me.Label2.TabIndex = 0
        Me.Label2.Text = "To Decrypt"
        '
        'Text_DValue
        '
        Me.Text_DValue.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Text_DValue.Location = New System.Drawing.Point(425, 149)
        Me.Text_DValue.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.Text_DValue.Name = "Text_DValue"
        Me.Text_DValue.Size = New System.Drawing.Size(332, 27)
        Me.Text_DValue.TabIndex = 1
        '
        'Btn_Decrypt
        '
        Me.Btn_Decrypt.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Btn_Decrypt.Location = New System.Drawing.Point(833, 139)
        Me.Btn_Decrypt.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.Btn_Decrypt.Name = "Btn_Decrypt"
        Me.Btn_Decrypt.Size = New System.Drawing.Size(111, 47)
        Me.Btn_Decrypt.TabIndex = 2
        Me.Btn_Decrypt.Text = "&Decrypt"
        Me.Btn_Decrypt.UseVisualStyleBackColor = True
        '
        'Label3
        '
        Me.Label3.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(4, 218)
        Me.Label3.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(133, 19)
        Me.Label3.TabIndex = 0
        Me.Label3.Text = "Decrypt Output"
        '
        'CBO_EncryptEncoder
        '
        Me.CBO_EncryptEncoder.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.CBO_EncryptEncoder.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.CBO_EncryptEncoder.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.CBO_EncryptEncoder.FormattingEnabled = True
        Me.CBO_EncryptEncoder.Location = New System.Drawing.Point(145, 19)
        Me.CBO_EncryptEncoder.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.CBO_EncryptEncoder.Name = "CBO_EncryptEncoder"
        Me.CBO_EncryptEncoder.Size = New System.Drawing.Size(272, 27)
        Me.CBO_EncryptEncoder.TabIndex = 3
        '
        'CBO_DecryptEncoder
        '
        Me.CBO_DecryptEncoder.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.CBO_DecryptEncoder.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.CBO_DecryptEncoder.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.CBO_DecryptEncoder.FormattingEnabled = True
        Me.CBO_DecryptEncoder.Location = New System.Drawing.Point(145, 149)
        Me.CBO_DecryptEncoder.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.CBO_DecryptEncoder.Name = "CBO_DecryptEncoder"
        Me.CBO_DecryptEncoder.Size = New System.Drawing.Size(272, 27)
        Me.CBO_DecryptEncoder.TabIndex = 3
        '
        'Label4
        '
        Me.Label4.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(145, 88)
        Me.Label4.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(272, 19)
        Me.Label4.TabIndex = 0
        Me.Label4.Text = "File Written  Encoder"
        '
        'LblEncodeType
        '
        Me.LblEncodeType.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.LblEncodeType.AutoSize = True
        Me.LblEncodeType.Location = New System.Drawing.Point(425, 88)
        Me.LblEncodeType.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.LblEncodeType.Name = "LblEncodeType"
        Me.LblEncodeType.Size = New System.Drawing.Size(332, 19)
        Me.LblEncodeType.TabIndex = 0
        Me.LblEncodeType.Text = "Encode Type"
        '
        'Form_Encryption
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 19.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1435, 882)
        Me.Controls.Add(Me.TLP_Main)
        Me.Font = New System.Drawing.Font("Calibri", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.Name = "Form_Encryption"
        Me.Text = "Form_Encryption"
        Me.TLP_Main.ResumeLayout(False)
        Me.TLP_Main.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents TLP_Main As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Text_EValue As System.Windows.Forms.TextBox
    Friend WithEvents Btn_Encrypt As System.Windows.Forms.Button
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Text_DValue As System.Windows.Forms.TextBox
    Friend WithEvents Btn_Decrypt As System.Windows.Forms.Button
    Friend WithEvents Text_Decryptoutput As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents CBO_EncryptEncoder As System.Windows.Forms.ComboBox
    Friend WithEvents CBO_DecryptEncoder As System.Windows.Forms.ComboBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents LblEncodeType As System.Windows.Forms.Label
End Class
