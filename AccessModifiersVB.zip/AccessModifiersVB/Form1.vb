﻿Public Class Form1
    Private mClassAccessModifiers_A As New ClassAccessModifiers
    Private mClassAccessModifiers_B As New ClassAccessModifiers



    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button_ObjA_In.Click
        Try
            With mClassAccessModifiers_A
                .vFriend_Name = txt_A_In_Friend_Name.Text
                .vPublic_Name = txt_A_In_Public_Name.Text
                ClassAccessModifiers.vShared_Friend_Name = txt_A_In_Shared_Friend_Name.Text
                ClassAccessModifiers.vShared_Public_Name = txt_A_In_Shared_Public_Name.Text
            End With
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub

    Private Sub Button_ObjB_Click(sender As Object, e As EventArgs) Handles Button_ObjB.Click
        Try
            With mClassAccessModifiers_B
                .vFriend_Name = txt_B_In_Friend_Name.Text
                .vPublic_Name = txt_B_In_Public_Name.Text
                ClassAccessModifiers.vShared_Friend_Name = txt_B_In_Shared_Friend_Name.Text
                ClassAccessModifiers.vShared_Public_Name = txt_B_In_Shared_Public_Name.Text


                txt_B_Out_Friend_Name.Text = .vFriend_Name
                txt_B_Out_Public_Name.Text = .vPublic_Name
                txt_B_Out_Shared_Friend_Name.Text = ClassAccessModifiers.vShared_Friend_Name
                txt_B_Out_Shared_Public_Name.Text = ClassAccessModifiers.vShared_Public_Name

            End With

        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub

    Private Sub Button_ObjA_Out_Click(sender As Object, e As EventArgs) Handles Button_ObjA_Out.Click
        Try
            With mClassAccessModifiers_A
                txt_A_Out_Friend_Name.Text = .vFriend_Name
                txt_A_Out_Public_Name.Text = .vPublic_Name
                txt_A_Out_Shared_Friend_Name.Text = ClassAccessModifiers.vShared_Friend_Name
                txt_A_Out_Shared_Public_Name.Text = ClassAccessModifiers.vShared_Public_Name

            End With
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try

    End Sub

    Private Sub Button1_Click_1(sender As Object, e As EventArgs) Handles Btn_outB.Click
        Try
            With mClassAccessModifiers_B
                txt_B_Out_Friend_Name.Text = .vFriend_Name
                txt_B_Out_Public_Name.Text = .vPublic_Name
                txt_B_Out_Shared_Friend_Name.Text = ClassAccessModifiers.vShared_Friend_Name
                txt_B_Out_Shared_Public_Name.Text = ClassAccessModifiers.vShared_Public_Name
            End With
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub
End Class
