﻿Imports System.IO

Public Class Form2
    Private Sub Form2_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Try

            Dim oDirectoryInfo As New IO.DirectoryInfo("C:\Program Files\BlueZone\6.1")
            Dim List_FileInfo As List(Of FileInfo) = oDirectoryInfo.GetFiles("*.dll").ToList()

            With ListView1
                .Columns.Clear()
                .Columns.Add("Name")
                .Columns.Add("Compnay Name")
                .Columns.Add("Product Name")
                .Columns.Add("Version")
                .Columns.Add("file desc")

            End With



            For Each myFileInfo As FileInfo In List_FileInfo
                Dim oDllData As DllData = New DllData(myFileInfo)
                Dim _ListViewItem As New ListViewItem(myFileInfo.Name)
                ListView1.Items.Add(_ListViewItem)
                Dim Sys As System.Diagnostics.FileVersionInfo = FileVersionInfo.GetVersionInfo(myFileInfo.FullName)
                _ListViewItem.SubItems.Add(Sys.CompanyName)
                _ListViewItem.SubItems.Add(Sys.ProductName)
                _ListViewItem.SubItems.Add(Sys.ProductVersion)
                _ListViewItem.SubItems.Add(Sys.FileDescription)

                _ListViewItem.Tag = oDllData
            Next
        Catch ex As Exception
            MessageBox.Show(ex.Message)

        End Try

    End Sub

    Private Sub TableLayoutPanel1_Paint(sender As Object, e As PaintEventArgs) Handles TableLayoutPanel1.Paint

    End Sub

    Private Sub Btn_Register_Click(sender As Object, e As EventArgs) Handles Btn_Register.Click
        Try

            


            'If ListView1.SelectedItems.Count <= 0 Then Return
            'Dim oDllData As DllData = ListView1.SelectedItems(0).Tag
            'oDllData.register()


        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub

    Private Sub ListView1_KeyDown(sender As Object, e As KeyEventArgs) Handles ListView1.KeyDown
        Try
            If e.KeyCode = Keys.R Then Btn_Register.PerformClick()
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try

    End Sub
End Class
Class DllData
    Private FileInfo As FileInfo
    Sub New(_FileInfo As FileInfo)
        FileInfo = _FileInfo
    End Sub
    Sub register()
        Try

            Using OI As New IO.StreamWriter(Application.StartupPath & "\Reg.Bat", False)
                OI.WriteLine("regsvr32 """ & FileInfo.FullName & """")
                OI.Close()
            End Using
            Shell(Application.StartupPath & "\Reg.Bat", AppWinStyle.Hide, True, 100)
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub
End Class