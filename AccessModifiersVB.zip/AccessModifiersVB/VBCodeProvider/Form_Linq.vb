﻿Public Class Form_Linq
    Dim oLinQ As New LinQ
    Private Sub btn_Linq_Click(sender As Object, e As EventArgs) Handles btn_Linq.Click
        Try
            Dim Obj As Object = oLinQ.GetStringValues()
            Dim o As New SqlClient.SqlConnection
            NotifyIcon1.Visible = True

            NotifyIcon1.ShowBalloonTip(120, "Hai", "Hai", ToolTipIcon.Info)
        Catch ex As Exception
            Throw
        End Try
    End Sub

    Private Sub NotifyIcon1_BalloonTipClicked(sender As Object, e As EventArgs) Handles NotifyIcon1.BalloonTipClicked
        Me.BringToFront()
        Me.Show()
    End Sub
    Private Sub Btn_Lambda_Click(sender As Object, e As EventArgs) Handles Btn_Lambda.Click
        Try
            Dim oLambda As New LambdaExpression
            Dim LambdaList = oLambda.LambdaWhere()
            Dim oLambdaList = oLambda.BaseLambda()
            Dim oLambdaSelfCall = oLambda.LambdaSelfCall()
            Dim IntS As Integer = oLambdaSelfCall
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub
End Class