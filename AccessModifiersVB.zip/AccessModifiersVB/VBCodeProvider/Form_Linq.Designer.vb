﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form_Linq
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.btn_Linq = New System.Windows.Forms.Button()
        Me.NotifyIcon1 = New System.Windows.Forms.NotifyIcon(Me.components)
        Me.Btn_Lambda = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'btn_Linq
        '
        Me.btn_Linq.Location = New System.Drawing.Point(77, 60)
        Me.btn_Linq.Name = "btn_Linq"
        Me.btn_Linq.Size = New System.Drawing.Size(73, 38)
        Me.btn_Linq.TabIndex = 0
        Me.btn_Linq.Text = "Linq"
        Me.btn_Linq.UseVisualStyleBackColor = True
        '
        'NotifyIcon1
        '
        Me.NotifyIcon1.Text = "NotifyIcon1"
        Me.NotifyIcon1.Visible = True
        '
        'Btn_Lambda
        '
        Me.Btn_Lambda.Location = New System.Drawing.Point(170, 60)
        Me.Btn_Lambda.Name = "Btn_Lambda"
        Me.Btn_Lambda.Size = New System.Drawing.Size(70, 38)
        Me.Btn_Lambda.TabIndex = 1
        Me.Btn_Lambda.Text = "Lambda"
        Me.Btn_Lambda.UseVisualStyleBackColor = True
        '
        'Form_Linq
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(607, 346)
        Me.Controls.Add(Me.Btn_Lambda)
        Me.Controls.Add(Me.btn_Linq)
        Me.Name = "Form_Linq"
        Me.Text = "Form_Linq"
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents btn_Linq As System.Windows.Forms.Button
    Friend WithEvents NotifyIcon1 As System.Windows.Forms.NotifyIcon
    Friend WithEvents Btn_Lambda As System.Windows.Forms.Button
End Class
