﻿Public Class LinQ
    Public ReadOnly Property StringValues As String()
        Get
            Return {"A", "AQB", "C", "D", "E"}
        End Get
    End Property
    Public Function GetStringValues() As Object
        Try
            Dim StringVals = From ArrayValues In StringValues Select ArrayValues Where (ArrayValues = "A" OrElse ArrayValues.Length > 1 OrElse ArrayValues.Length = 1)
            Dim aVal = Function(x) x + 1
            Return StringVals
        Catch ex As Exception
            Throw
        End Try
    End Function
End Class
Public MustInherit Class ASSS
    Public Function Area() As Double
        Try
            Return 0
        Catch ex As Exception
            Throw
        End Try
    End Function
End Class
Class LambdaExpression
    Function BaseLambda() As Integer
        Try
            Dim Lambda = Function(x) x + 1
            Dim bol As Boolean = False
            Return Lambda(1)
        Catch ex As Exception
            Throw
        End Try
    End Function
    Function LambdaSelfCall() As Integer
        Return (Function(a As Integer, b As Integer) a + b)(a:=5, b:=10)
    End Function
    Function LambdaWhere() As List(Of Integer)
        Try
            Dim List_Integer As New List(Of Integer)
            List_Integer.AddRange({1, 2, 3, 4, 5, 6, 7, 8, 9, 10})
            Return List_Integer.Where(Function(n) n Mod 2 = 1).ToList()
        Catch ex As Exception
            Throw
        End Try
    End Function
End Class

