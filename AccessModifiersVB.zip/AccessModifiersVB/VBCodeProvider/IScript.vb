﻿Public Interface IScript

End Interface
Class TestSorting



End Class

