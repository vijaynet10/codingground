﻿Public Class InheritableClass
    Private vprivate_Name As String
    Friend vFriend_Name As String
    Public vPublic_Name As String
    Protected vProtected_Name As String
    Protected Friend vProtectedFriend_Name As String
End Class